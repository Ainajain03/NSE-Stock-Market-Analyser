import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Navbar } from "@/components/Navbar";
import { GlobalChatbot } from "@/components/GlobalChatbot";

import Dashboard   from "@/pages/dashboard";
import Technical   from "@/pages/technical";
import Fundamental from "@/pages/fundamental";
import Sentiment   from "@/pages/sentiment";
import Experts     from "@/pages/experts";
import ExpertChat  from "@/pages/expert-chat";
import Portfolio   from "@/pages/portfolio";
import Watchlist   from "@/pages/watchlist";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } },
});

function Router() {
  return (
    <div className="flex flex-col min-h-screen relative w-full overflow-x-hidden text-sm">
      <Navbar />
      <main className="flex-1 flex flex-col relative">
        <Switch>
          <Route path="/" component={() => { window.location.href = "/dashboard"; return null; }} />
          <Route path="/dashboard"   component={Dashboard} />
          <Route path="/technical"   component={Technical} />
          <Route path="/fundamental" component={Fundamental} />
          <Route path="/sentiment"   component={Sentiment} />
          <Route path="/experts"     component={Experts} />
          <Route path="/experts/:id" component={ExpertChat} />
          <Route path="/portfolio"   component={Portfolio} />
          <Route path="/watchlist"   component={Watchlist} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <GlobalChatbot />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

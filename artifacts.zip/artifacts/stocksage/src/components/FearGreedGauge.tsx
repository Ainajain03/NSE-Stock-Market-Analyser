import React from 'react';
import { motion } from 'framer-motion';

interface FearGreedGaugeProps {
  value: number;
}

export function FearGreedGauge({ value }: FearGreedGaugeProps) {
  // value is 0-100
  // rotation from -90 to 90 degrees
  const rotation = -90 + (value / 100) * 180;
  
  let color = 'var(--signal-neutral)';
  let label = 'NEUTRAL';
  if (value <= 25) { color = 'var(--signal-strong-sell)'; label = 'EXTREME FEAR'; }
  else if (value <= 45) { color = 'var(--signal-sell)'; label = 'FEAR'; }
  else if (value >= 75) { color = 'var(--signal-strong-buy)'; label = 'EXTREME GREED'; }
  else if (value >= 55) { color = 'var(--signal-buy)'; label = 'GREED'; }

  return (
    <div className="flex flex-col items-center relative w-full max-w-[300px] mx-auto">
      <svg viewBox="0 0 200 120" className="w-full overflow-visible">
        <defs>
          <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="var(--signal-strong-sell)" />
            <stop offset="25%" stopColor="var(--signal-sell)" />
            <stop offset="50%" stopColor="var(--signal-neutral)" />
            <stop offset="75%" stopColor="var(--signal-buy)" />
            <stop offset="100%" stopColor="var(--signal-strong-buy)" />
          </linearGradient>
        </defs>
        
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke="url(#gaugeGradient)"
          strokeWidth="16"
          strokeLinecap="round"
          className="opacity-80"
        />
        
        <motion.g
          initial={{ rotate: -90 }}
          animate={{ rotate: rotation }}
          transition={{ type: "spring", stiffness: 50, damping: 15 }}
          style={{ originX: "100px", originY: "100px" }}
        >
          <polygon points="95,100 105,100 100,20" fill="var(--text-primary)" />
          <circle cx="100" cy="100" r="8" fill="var(--text-primary)" />
        </motion.g>
      </svg>
      
      <div className="absolute bottom-0 flex flex-col items-center">
        <div className="text-3xl font-bold font-mono" style={{ color }}>{value}</div>
        <div className="text-xs font-bold tracking-widest text-muted-foreground mt-1">{label}</div>
      </div>
    </div>
  );
}

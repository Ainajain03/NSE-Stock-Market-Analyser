import React, { useEffect, useState } from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface SignalCardProps {
  indicator: string;
  value: number | null | undefined;
  signal: 'BUY' | 'SELL' | 'NEUTRAL' | string;
  strength: 'STRONG' | 'MODERATE' | 'WEAK' | string;
  reason: string;
  category?: string;
  isAnimated?: boolean;
}

export function SignalCard({ indicator, value, signal, strength, reason, category, isAnimated = true }: SignalCardProps) {
  const signalColor = 
    signal.includes('BUY') ? 'bg-[var(--signal-buy)] text-[var(--signal-buy)]' :
    signal.includes('SELL') ? 'bg-[var(--signal-sell)] text-[var(--signal-sell)]' :
    'bg-[var(--signal-neutral)] text-[var(--signal-neutral)]';

  const [hasAnimated, setHasAnimated] = useState(false);
  const springValue = useSpring(0, { stiffness: 50, damping: 20 });
  const displayValue = useTransform(springValue, Math.round);

  useEffect(() => {
    if (value !== null && value !== undefined && isAnimated) {
      springValue.set(value);
      setHasAnimated(true);
    }
  }, [value, springValue, isAnimated]);

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <motion.div
          whileHover={{ y: -4, transition: { duration: 0.2 } }}
          className="h-full"
        >
          <Card className="h-full border-primary/10 bg-card hover:bg-card-hover transition-colors overflow-hidden relative group">
            <div className={`absolute top-0 left-0 w-1 h-full ${signalColor.split(' ')[0]} opacity-50 group-hover:opacity-100 transition-opacity`} />
            <CardContent className="p-4 flex flex-col h-full justify-between gap-4">
              <div className="flex justify-between items-start">
                <div>
                  {category && <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">{category}</div>}
                  <div className="font-medium text-sm text-foreground">{indicator}</div>
                </div>
                <div className={`px-2 py-1 rounded text-[10px] font-bold border ${signalColor.split(' ')[0]}/20 border-${signalColor.split(' ')[0].replace('bg-', '')}/30 ${signalColor.split(' ')[1]}`}>
                  {signal} {strength !== 'MODERATE' && strength !== 'NEUTRAL' ? `(${strength})` : ''}
                </div>
              </div>
              
              <div className="flex items-end justify-between">
                <div className="text-2xl font-mono font-bold">
                  {value !== null && value !== undefined ? (
                    isAnimated ? <motion.span>{displayValue}</motion.span> : value.toFixed(2)
                  ) : '-'}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </TooltipTrigger>
      <TooltipContent className="bg-popover border-primary/20 text-popover-foreground max-w-xs">
        <p className="text-sm">{reason}</p>
      </TooltipContent>
    </Tooltip>
  );
}

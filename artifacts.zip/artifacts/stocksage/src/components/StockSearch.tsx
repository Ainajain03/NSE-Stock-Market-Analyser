import React, { useState, useEffect } from 'react';
import { useSearchStocks, useGetStockQuote } from '@workspace/api-client-react';
import { useStockStore } from '@/store/stockStore';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Search, X, ChevronDown } from 'lucide-react';
import { useDebounce } from '@/hooks/use-debounce';

export function StockSearch() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const debouncedQuery = useDebounce(query, 300);
  const setSelectedStock = useStockStore(state => state.setSelectedStock);
  const clearStock = useStockStore(state => state.clearStock);
  const selectedStock = useStockStore(state => state.selectedStock);
  const selectedSymbol = useStockStore(state => state.selectedSymbol);

  const [fetchSymbol, setFetchSymbol] = useState<string | null>(null);

  const { data: searchResults, isLoading } = useSearchStocks(
    { q: debouncedQuery },
    { query: { enabled: debouncedQuery.length > 0 } }
  );

  const { data: quoteData } = useGetStockQuote(fetchSymbol || '', {
    query: { enabled: !!fetchSymbol }
  });

  useEffect(() => {
    if (quoteData && fetchSymbol) {
      setSelectedStock(quoteData);
      setFetchSymbol(null);
    }
  }, [quoteData, fetchSymbol, setSelectedStock]);

  const handleSelect = (symbol: string) => {
    setFetchSymbol(symbol);
    setOpen(false);
    setQuery('');
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    clearStock();
    setFetchSymbol(null);
    setQuery('');
  };

  const isPositive = selectedStock ? selectedStock.changePercent >= 0 : true;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          className="flex items-center gap-2 px-3 py-2 text-sm border rounded-md border-primary/20 bg-secondary/50 hover:bg-secondary transition-colors font-mono min-w-[200px] group"
          data-testid="button-stock-search"
        >
          {selectedStock ? (
            <>
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <span className="text-primary font-bold">{selectedStock.symbol}</span>
                <span className={`text-xs ${isPositive ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}`}>
                  {isPositive ? '+' : ''}{selectedStock.changePercent.toFixed(2)}%
                </span>
              </div>
              <span
                role="button"
                tabIndex={0}
                onClick={handleClear}
                onKeyDown={(e) => e.key === 'Enter' && handleClear(e as any)}
                className="text-muted-foreground hover:text-foreground transition-colors ml-auto"
                aria-label="Clear stock selection"
              >
                <X className="w-3 h-3" />
              </span>
            </>
          ) : (
            <>
              <Search className="w-4 h-4 text-muted-foreground shrink-0" />
              <span className="text-muted-foreground flex-1 text-left">Search NSE stocks...</span>
              <ChevronDown className="w-3 h-3 text-muted-foreground" />
            </>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-80 bg-card border-primary/20" align="start">
        <Command shouldFilter={false}>
          <CommandInput
            placeholder="Search by symbol or company..."
            value={query}
            onValueChange={setQuery}
            className="font-mono text-sm"
          />
          <CommandList>
            <CommandEmpty>{isLoading ? 'Searching...' : 'No stocks found.'}</CommandEmpty>
            <CommandGroup>
              {searchResults?.map((stock) => (
                <CommandItem
                  key={stock.symbol}
                  value={stock.symbol}
                  onSelect={() => handleSelect(stock.symbol)}
                  className="flex items-center justify-between px-4 py-2 cursor-pointer font-mono hover:bg-secondary aria-selected:bg-secondary"
                  data-testid={`item-stock-${stock.symbol}`}
                >
                  <div>
                    <div className="font-semibold text-primary">{stock.symbol}</div>
                    <div className="text-xs text-muted-foreground truncate w-48">{stock.name}</div>
                  </div>
                  <div className="text-xs px-2 py-1 bg-secondary rounded text-muted-foreground">{stock.sector}</div>
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

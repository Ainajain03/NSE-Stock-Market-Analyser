import React, { useState, useRef, useEffect } from 'react';
import { useGlobalChat } from '@workspace/api-client-react';
import { useStockStore } from '@/store/stockStore';
import { useStrategyStore } from '@/store/strategyStore';
import type { GlobalChatMessage } from '@workspace/api-client-react';
import { MessageSquare, X, Send, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export function GlobalChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [history, setHistory] = useState<GlobalChatMessage[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const selectedStock = useStockStore(state => state.selectedStock);
  const activeStrategy = useStrategyStore(state => state.activeStrategy);

  const chatMutation = useGlobalChat();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, chatMutation.isPending]);

  const handleSend = () => {
    if (!message.trim() || chatMutation.isPending) return;

    const userMessage: GlobalChatMessage = { role: 'user', content: message };
    setHistory(prev => [...prev, userMessage]);
    setMessage('');

    const contextStock = selectedStock ? {
      symbol: selectedStock.symbol,
      price: selectedStock.price,
      pe: selectedStock.pe,
      marketCap: selectedStock.marketCap,
      sector: selectedStock.sector,
      technicalSignal: 'NEUTRAL',
      fundamentalSignal: 'AVERAGE'
    } : undefined;

    chatMutation.mutate({
      data: {
        message: message,
        conversationHistory: history,
        activeStrategy: activeStrategy,
        selectedStock: contextStock
      }
    }, {
      onSuccess: (data) => {
        setHistory(prev => [...prev, { role: 'assistant', content: data.reply }]);
      }
    });
  };

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-lg shadow-primary/20 flex items-center justify-center hover:scale-105 transition-transform z-50"
            data-testid="button-open-chat"
          >
            <MessageSquare className="w-6 h-6" />
          </motion.button>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 w-80 sm:w-96 h-[500px] bg-card border border-primary/20 rounded-xl shadow-2xl flex flex-col z-50 overflow-hidden"
          >
            <div className="p-4 border-b border-primary/10 bg-secondary/50 flex justify-between items-center">
              <div>
                <h3 className="font-bold text-sm">StockSage AI</h3>
                <div className="text-xs text-muted-foreground mt-1 flex gap-2">
                  {selectedStock && <span className="bg-primary/10 text-primary px-1.5 rounded">{selectedStock.symbol}</span>}
                  {activeStrategy && <span className="bg-accent/10 text-accent px-1.5 rounded">{activeStrategy}</span>}
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-muted-foreground hover:text-foreground p-1" data-testid="button-close-chat">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
              {history.length === 0 && (
                <div className="text-center text-muted-foreground text-sm mt-10">
                  How can I help you analyze the market today?
                </div>
              )}
              {history.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded-lg p-3 text-sm ${msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground border border-primary/10'}`}>
                    {msg.content}
                  </div>
                </div>
              ))}
              {chatMutation.isPending && (
                <div className="flex justify-start">
                  <div className="max-w-[85%] rounded-lg p-3 text-sm bg-secondary text-secondary-foreground border border-primary/10 flex items-center">
                    <Loader2 className="w-4 h-4 animate-spin mr-2" /> Thinking...
                  </div>
                </div>
              )}
            </div>

            <div className="p-3 border-t border-primary/10 bg-background">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Ask about a stock or strategy..."
                  className="flex-1 bg-secondary border border-primary/20 rounded-md px-3 py-2 text-sm focus:outline-none focus:border-primary/50 text-foreground"
                  disabled={chatMutation.isPending}
                  data-testid="input-chat-message"
                />
                <button
                  type="submit"
                  disabled={!message.trim() || chatMutation.isPending}
                  className="p-2 bg-primary text-primary-foreground rounded-md disabled:opacity-50"
                  data-testid="button-send-chat"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

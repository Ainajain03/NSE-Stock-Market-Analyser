import React from 'react';
import { Link, useLocation } from 'wouter';
import { StockSearch } from './StockSearch';
import { useGetMarketOverview } from '@workspace/api-client-react';
import { useStrategyStore } from '@/store/strategyStore';
import { formatPercent } from '@/lib/format';

export function Navbar() {
  const [location] = useLocation();
  const activeExpert = useStrategyStore(state => state.activeExpert);
  const { data: marketData } = useGetMarketOverview({ query: { refetchInterval: 60000 } });

  const navItems = [
    { href: '/dashboard',   label: 'Command Center' },
    { href: '/technical',   label: 'Technical' },
    { href: '/fundamental', label: 'Fundamental' },
    { href: '/sentiment',   label: 'Sentiment' },
    { href: '/experts',     label: 'Experts' },
    { href: '/portfolio',   label: 'Portfolio', badge: 'AI' },
    { href: '/watchlist',   label: 'Watchlist' },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-primary/20 bg-background/80 backdrop-blur-md">
      <div className="flex h-16 items-center px-4 gap-4">
        <Link href="/dashboard" className="flex items-center gap-2 shrink-0">
          <span className="text-lg font-bold font-[family-name:var(--app-font-display)] tracking-tight">
            STOCKSAGE<span className="text-primary glow-text">AI</span>
          </span>
        </Link>

        <div className="flex gap-4 flex-1 items-center overflow-x-auto scrollbar-none">
          {navItems.map(item => {
            const isActive = location.startsWith(item.href);
            return (
              <Link key={item.href} href={item.href} className="relative group shrink-0">
                <span className={`text-sm font-medium transition-colors whitespace-nowrap ${isActive ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                  {item.label}
                  {item.badge && (
                    <span className="ml-1 text-[9px] font-bold uppercase tracking-wider text-primary bg-primary/10 px-1 py-0.5 rounded">{item.badge}</span>
                  )}
                </span>
                {isActive && (
                  <span className="absolute -bottom-5 left-0 w-full h-0.5 bg-primary shadow-[0_0_8px_var(--color-primary)]" />
                )}
              </Link>
            );
          })}
        </div>

        <StockSearch />

        {marketData && (
          <div className="hidden lg:flex items-center gap-3 text-xs font-mono border-l border-primary/20 pl-4 ml-2 shrink-0">
            {[marketData.nifty50, marketData.bankNifty, marketData.sensex].map((idx) => {
              if (!idx) return null;
              const isPos = idx.change >= 0;
              return (
                <div key={idx.name} className="flex flex-col items-end">
                  <span className="text-muted-foreground text-[10px]">{idx.name}</span>
                  <span className={`text-xs ${isPos ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}`}>
                    {idx.value.toFixed(2)} ({formatPercent(idx.changePercent)})
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {activeExpert && (
          <div className="ml-2 px-2 py-1 border border-[var(--accent-primary)] rounded bg-[var(--accent-primary)]/10 text-xs font-medium font-mono text-[var(--accent-primary)] flex items-center gap-1.5 shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-primary)] animate-pulse" />
            <span className="hidden xl:inline">{activeExpert.name}</span>
            <span className="xl:hidden">Strategy ✓</span>
          </div>
        )}
      </div>
      <style>{`
        .glow-text { text-shadow: 0 0 10px var(--color-primary); }
        .scrollbar-none { scrollbar-width: none; }
        .scrollbar-none::-webkit-scrollbar { display: none; }
      `}</style>
    </nav>
  );
}

import React, { useEffect, useRef } from 'react';
import {
  createChart,
  ColorType,
  CrosshairMode,
  CandlestickSeries,
  HistogramSeries,
  type IChartApi,
  type ISeriesApi,
  type CandlestickData,
  type HistogramData,
  type Time,
} from 'lightweight-charts';

interface Candle {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface CandlestickChartProps {
  data: Candle[];
  height?: number;
  showVolume?: boolean;
}

const COLORS = {
  bg:         '#080c14',
  grid:       'rgba(255,255,255,0.04)',
  text:       'rgba(255,255,255,0.45)',
  border:     'rgba(255,255,255,0.08)',
  bullCandle: '#22c55e',
  bearCandle: '#ef4444',
  bullVol:    'rgba(34,197,94,0.35)',
  bearVol:    'rgba(239,68,68,0.35)',
  crosshair:  'rgba(255,255,255,0.25)',
};

function fmt(n: number) {
  return n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function CandlestickChart({ data, height = 420, showVolume = true }: CandlestickChartProps) {
  const containerRef    = useRef<HTMLDivElement>(null);
  const chartRef        = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);

  // Chart initialisation
  useEffect(() => {
    if (!containerRef.current) return;

    const chart = createChart(containerRef.current, {
      width: containerRef.current.clientWidth,
      height,
      layout: {
        background: { type: ColorType.Solid, color: COLORS.bg },
        textColor: COLORS.text,
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: COLORS.grid },
        horzLines: { color: COLORS.grid },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: { color: COLORS.crosshair, width: 1, style: 1, labelBackgroundColor: '#1a2535' },
        horzLine: { color: COLORS.crosshair, width: 1, style: 1, labelBackgroundColor: '#1a2535' },
      },
      rightPriceScale: {
        borderColor: COLORS.border,
        scaleMargins: showVolume ? { top: 0.08, bottom: 0.26 } : { top: 0.08, bottom: 0.05 },
      },
      timeScale: {
        borderColor: COLORS.border,
        timeVisible: true,
        secondsVisible: false,
        fixLeftEdge: false,
        fixRightEdge: false,
      },
      handleScroll: true,
      handleScale: true,
    });

    chartRef.current = chart;

    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor:        COLORS.bullCandle,
      downColor:      COLORS.bearCandle,
      borderUpColor:  COLORS.bullCandle,
      borderDownColor: COLORS.bearCandle,
      wickUpColor:    COLORS.bullCandle,
      wickDownColor:  COLORS.bearCandle,
    });
    candleSeriesRef.current = candleSeries;

    if (showVolume) {
      const volumeSeries = chart.addSeries(HistogramSeries, {
        priceFormat: { type: 'volume' },
        priceScaleId: 'volume',
      });
      chart.priceScale('volume').applyOptions({
        scaleMargins: { top: 0.8, bottom: 0 },
        borderVisible: false,
      });
      volumeSeriesRef.current = volumeSeries;
    }

    // ── OHLC Tooltip overlay ───────────────────────────────────────
    const tooltip = document.createElement('div');
    tooltip.style.cssText = [
      'position:absolute',
      'top:10px',
      'left:10px',
      'z-index:20',
      'background:rgba(8,12,20,0.92)',
      'border:1px solid rgba(99,179,237,0.22)',
      'border-radius:6px',
      'padding:8px 12px',
      `font-family:'JetBrains Mono',monospace`,
      'font-size:11px',
      'color:rgba(255,255,255,0.85)',
      'pointer-events:none',
      'display:none',
      'min-width:190px',
      'line-height:1.9',
      'backdrop-filter:blur(4px)',
    ].join(';');
    containerRef.current.appendChild(tooltip);

    chart.subscribeCrosshairMove((param) => {
      if (!param.time || !param.point) {
        tooltip.style.display = 'none';
        return;
      }
      const d = param.seriesData.get(candleSeries) as CandlestickData | undefined;
      if (!d) {
        tooltip.style.display = 'none';
        return;
      }
      const isUp  = d.close >= d.open;
      const col   = isUp ? '#22c55e' : '#ef4444';
      const chg   = ((d.close - d.open) / d.open * 100).toFixed(2);
      const sign  = isUp ? '+' : '';
      const timeStr = String(param.time);
      tooltip.style.display = 'block';
      tooltip.innerHTML = `
        <div style="color:rgba(255,255,255,0.4);font-size:10px;margin-bottom:5px;letter-spacing:0.05em">${timeStr}</div>
        <div style="display:grid;grid-template-columns:auto 1fr;gap:2px 10px">
          <span style="color:rgba(255,255,255,0.45)">O</span><span style="color:#e2e8f0">₹${fmt(d.open)}</span>
          <span style="color:rgba(255,255,255,0.45)">H</span><span style="color:#22c55e">₹${fmt(d.high)}</span>
          <span style="color:rgba(255,255,255,0.45)">L</span><span style="color:#ef4444">₹${fmt(d.low)}</span>
          <span style="color:rgba(255,255,255,0.45)">C</span><span style="color:${col};font-weight:700">₹${fmt(d.close)}</span>
        </div>
        <div style="margin-top:5px;color:${col};font-size:10px;border-top:1px solid rgba(255,255,255,0.06);padding-top:4px">${sign}${chg}%</div>
      `;
    });

    // Resize observer
    const ro = new ResizeObserver(() => {
      if (containerRef.current) {
        chart.applyOptions({ width: containerRef.current.clientWidth });
      }
    });
    ro.observe(containerRef.current);

    return () => {
      ro.disconnect();
      tooltip.remove();
      chart.remove();
      chartRef.current        = null;
      candleSeriesRef.current = null;
      volumeSeriesRef.current = null;
    };
  }, [height, showVolume]);

  // Data update
  useEffect(() => {
    if (!candleSeriesRef.current || !data.length) return;

    const seen        = new Set<string>();
    const candleData: CandlestickData<Time>[] = [];
    const volumeData: HistogramData<Time>[]   = [];

    for (const c of data) {
      // lightweight-charts needs either "yyyy-mm-dd" or Unix seconds (number)
      const t: Time = c.time.length > 10
        ? Math.floor(new Date(c.time).getTime() / 1000) as Time  // intraday → Unix seconds
        : c.time as Time;                                          // daily    → "yyyy-mm-dd"
      const key = String(t);
      if (seen.has(key)) continue;
      seen.add(key);
      candleData.push({ time: t, open: c.open, high: c.high, low: c.low, close: c.close });
      volumeData.push({ time: t, value: c.volume, color: c.close >= c.open ? COLORS.bullVol : COLORS.bearVol });
    }

    candleData.sort((a, b) => String(a.time).localeCompare(String(b.time)));
    volumeData.sort((a, b) => String(a.time).localeCompare(String(b.time)));

    candleSeriesRef.current.setData(candleData);
    if (volumeSeriesRef.current && volumeData.length) {
      volumeSeriesRef.current.setData(volumeData);
    }

    chartRef.current?.timeScale().fitContent();
  }, [data]);

  return (
    <div
      ref={containerRef}
      className="w-full rounded-b-lg overflow-hidden"
      style={{ height, position: 'relative' }}
    />
  );
}

export const formatIndianNumber = (num: number): string => {
  if (num === null || num === undefined) return "-";
  return new Intl.NumberFormat("en-IN").format(num);
};

export const formatCurrency = (num: number, maximumFractionDigits = 2): string => {
  if (num === null || num === undefined) return "-";
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits,
  }).format(num);
};

export const formatCompactNumber = (num: number): string => {
  if (num === null || num === undefined) return "-";
  if (Math.abs(num) >= 1e7) {
    return `₹${(num / 1e7).toFixed(2)}Cr`;
  }
  if (Math.abs(num) >= 1e5) {
    return `₹${(num / 1e5).toFixed(2)}L`;
  }
  return formatCurrency(num, 0);
};

export const formatPercent = (num: number): string => {
  if (num === null || num === undefined) return "-";
  return `${num > 0 ? "+" : ""}${num.toFixed(2)}%`;
};

import { create } from 'zustand';
import { StockQuote } from '@workspace/api-client-react';

interface StockState {
  selectedSymbol: string | null;
  selectedStock: StockQuote | null;
  setSelectedStock: (quote: StockQuote) => void;
  clearStock: () => void;
}

export const useStockStore = create<StockState>((set) => ({
  selectedSymbol: null,
  selectedStock: null,
  setSelectedStock: (quote) => set({ selectedSymbol: quote.symbol, selectedStock: quote }),
  clearStock: () => set({ selectedSymbol: null, selectedStock: null }),
}));

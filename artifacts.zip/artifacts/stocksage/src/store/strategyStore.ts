import { create } from 'zustand';
import { ExpertProfile } from '@workspace/api-client-react';

interface StrategyState {
  activeStrategy: string | null;
  activeExpert: ExpertProfile | null;
  setActiveStrategy: (id: string, expert: ExpertProfile) => void;
  clearStrategy: () => void;
}

export const useStrategyStore = create<StrategyState>((set) => ({
  activeStrategy: null,
  activeExpert: null,
  setActiveStrategy: (id, expert) => {
    set({ activeStrategy: id, activeExpert: expert });
    document.body.className = `strategy-${id}`;
  },
  clearStrategy: () => {
    set({ activeStrategy: null, activeExpert: null });
    document.body.className = '';
  },
}));

import React from 'react';
import { useStockStore } from '@/store/stockStore';
import { useStrategyStore } from '@/store/strategyStore';
import { 
  useGetMarketSentiment,
  getGetMarketSentimentQueryKey,
  useGetSentimentAnalysis,
  getGetSentimentAnalysisQueryKey,
  useGetSentimentAiSummary
} from '@workspace/api-client-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { FearGreedGauge } from '@/components/FearGreedGauge';
import { Loader2, BrainCircuit, ExternalLink } from 'lucide-react';
import { formatCompactNumber } from '@/lib/format';

export default function Sentiment() {
  const selectedSymbol = useStockStore(state => state.selectedSymbol);
  const activeStrategy = useStrategyStore(state => state.activeStrategy);

  const { data: marketData, isLoading: marketLoading } = useGetMarketSentiment({ 
    query: { queryKey: getGetMarketSentimentQueryKey() } 
  });

  const { data: stockData, isLoading: stockLoading } = useGetSentimentAnalysis(
    selectedSymbol || '',
    { query: { enabled: !!selectedSymbol, queryKey: getGetSentimentAnalysisQueryKey(selectedSymbol || '') } }
  );

  const aiSummaryMutation = useGetSentimentAiSummary();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="p-6 max-w-[1400px] mx-auto w-full space-y-6">
      <div className="flex flex-col justify-between gap-2">
        <h1 className="text-3xl font-bold font-[family-name:var(--app-font-display)] text-primary glow-text-sm">Market Sentiment</h1>
        <p className="text-muted-foreground text-sm">Real-time emotional indicators and institutional flows.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Col - Global Market */}
        <div className="space-y-6">
          <Card className="bg-card border-primary/20">
            <CardHeader className="bg-secondary/30 pb-4">
              <CardTitle className="text-sm font-[family-name:var(--app-font-display)] text-center">Fear & Greed Index</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {marketLoading ? (
                <div className="flex justify-center py-10"><Skeleton className="h-40 w-40 rounded-full bg-secondary" /></div>
              ) : marketData ? (
                <FearGreedGauge value={marketData.fearGreedIndex} />
              ) : null}
            </CardContent>
          </Card>

          <Card className="bg-card border-primary/20">
            <CardHeader className="bg-secondary/30 pb-4">
              <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">Institutional Flow</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {marketLoading ? (
                <Skeleton className="h-40 w-full bg-secondary" />
              ) : marketData ? (
                <div className="divide-y divide-primary/10">
                  <div className="p-4 flex items-center justify-between">
                    <span className="text-sm font-bold text-muted-foreground">FII Net</span>
                    <span className={`font-mono font-bold ${marketData.fiiNetFlow >= 0 ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}`}>
                      {marketData.fiiNetFlow > 0 ? '+' : ''}{formatCompactNumber(marketData.fiiNetFlow)}
                    </span>
                  </div>
                  <div className="p-4 flex items-center justify-between">
                    <span className="text-sm font-bold text-muted-foreground">DII Net</span>
                    <span className={`font-mono font-bold ${marketData.diiNetFlow >= 0 ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}`}>
                      {marketData.diiNetFlow > 0 ? '+' : ''}{formatCompactNumber(marketData.diiNetFlow)}
                    </span>
                  </div>
                  <div className="p-4 bg-secondary/20 flex flex-col gap-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Adv: {marketData.advanceDeclineRatio.toFixed(2)}</span>
                      <span>India VIX: {marketData.indiaVix.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>

        {/* Middle/Right Col - Stock Specific */}
        <div className="lg:col-span-2 space-y-6">
          {!selectedSymbol ? (
            <Card className="bg-card border-primary/20 h-full flex items-center justify-center min-h-[400px]">
              <div className="text-muted-foreground text-center">
                Select a stock to view its specific sentiment analysis
              </div>
            </Card>
          ) : stockLoading ? (
             <div className="space-y-6">
               <Skeleton className="h-40 w-full bg-secondary" />
               <Skeleton className="h-64 w-full bg-secondary" />
             </div>
          ) : stockData ? (
            <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
              
              <Card className="bg-card border-primary/20 relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-1 h-full ${stockData.signal.includes('BULLISH') ? 'bg-[var(--signal-buy)]' : stockData.signal.includes('BEARISH') ? 'bg-[var(--signal-sell)]' : 'bg-[var(--signal-neutral)]'}`} />
                <CardHeader className="bg-secondary/30 pb-4 flex flex-row items-center justify-between">
                  <CardTitle className="text-sm font-[family-name:var(--app-font-display)] flex items-center gap-2">
                    {selectedSymbol} Sentiment Score
                  </CardTitle>
                  <div className={`px-3 py-1 rounded text-xs font-bold border ${stockData.signal.includes('BULLISH') ? 'bg-[var(--signal-buy)]/10 text-[var(--signal-buy)] border-[var(--signal-buy)]/30' : stockData.signal.includes('BEARISH') ? 'bg-[var(--signal-sell)]/10 text-[var(--signal-sell)] border-[var(--signal-sell)]/30' : 'bg-[var(--signal-neutral)]/10 text-[var(--signal-neutral)] border-[var(--signal-neutral)]/30'}`}>
                    {stockData.signal.replace('_', ' ')}
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                   <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-xs text-muted-foreground uppercase mb-1">Overall</div>
                        <div className="text-2xl font-mono font-bold text-primary">{stockData.overallScore}/100</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-muted-foreground uppercase mb-1">News</div>
                        <div className="text-2xl font-mono font-bold text-primary">{stockData.newsSentimentScore}/100</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-muted-foreground uppercase mb-1">Social</div>
                        <div className="text-2xl font-mono font-bold text-primary">{stockData.socialSentimentScore}/100</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-muted-foreground uppercase mb-1">PCR</div>
                        <div className="text-2xl font-mono font-bold text-primary">{stockData.putCallRatio?.toFixed(2) || '-'}</div>
                      </div>
                   </div>
                </CardContent>
              </Card>

              <Card className="bg-card border-primary/20">
                  <CardHeader className="bg-secondary/30 pb-4 flex flex-row items-center justify-between">
                    <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">AI News Synthesis</CardTitle>
                    <button
                      onClick={() => aiSummaryMutation.mutate({ symbol: selectedSymbol, data: { strategy: activeStrategy || undefined } })}
                      disabled={aiSummaryMutation.isPending}
                      className="px-3 py-1.5 bg-primary/20 text-primary hover:bg-primary hover:text-primary-foreground rounded text-xs font-medium border border-primary/30 flex items-center gap-2 transition-all active:scale-95"
                    >
                      {aiSummaryMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <BrainCircuit className="w-3 h-3" />}
                      Synthesize
                    </button>
                  </CardHeader>
                  <CardContent className="p-6">
                    <AnimatePresence mode="wait">
                      {aiSummaryMutation.data ? (
                        <motion.div
                          key="summary"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-sm leading-relaxed whitespace-pre-wrap"
                        >
                          {aiSummaryMutation.data.summary}
                        </motion.div>
                      ) : (
                        <motion.div key="empty" className="text-muted-foreground text-sm py-4 text-center">
                          Generate AI synthesis of recent news and social chatter.
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardContent>
                </Card>

              <div className="space-y-3">
                <h3 className="text-sm font-bold font-[family-name:var(--app-font-display)]">Recent News Signals</h3>
                <div className="grid gap-3">
                  {stockData.recentNews.map((news, i) => (
                    <motion.div key={i} variants={itemVariants} className="p-4 bg-secondary/30 border border-primary/10 rounded-lg flex flex-col gap-2 hover:bg-secondary/50 transition-colors">
                      <div className="flex justify-between items-start gap-4">
                        <div className="font-medium text-sm text-foreground/90">{news.headline}</div>
                        <div className={`shrink-0 px-2 py-1 rounded text-[10px] font-bold ${news.sentimentScore > 60 ? 'bg-[var(--signal-buy)]/10 text-[var(--signal-buy)]' : news.sentimentScore < 40 ? 'bg-[var(--signal-sell)]/10 text-[var(--signal-sell)]' : 'bg-[var(--signal-neutral)]/10 text-[var(--signal-neutral)]'}`}>
                          {news.sentimentScore > 60 ? 'POSITIVE' : news.sentimentScore < 40 ? 'NEGATIVE' : 'NEUTRAL'}
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-xs text-muted-foreground mt-1">
                        <span>{news.source} • {new Date(news.timestamp).toLocaleDateString()}</span>
                        {news.url && (
                          <a href={news.url} target="_blank" rel="noreferrer" className="text-primary hover:underline flex items-center gap-1">
                            Read <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </motion.div>
                  ))}
                  {stockData.recentNews.length === 0 && (
                    <div className="p-6 text-center text-muted-foreground text-sm border border-primary/10 rounded-lg border-dashed">
                      No recent significant news found.
                    </div>
                  )}
                </div>
              </div>

            </motion.div>
          ) : null}
        </div>

      </div>
    </div>
  );
}

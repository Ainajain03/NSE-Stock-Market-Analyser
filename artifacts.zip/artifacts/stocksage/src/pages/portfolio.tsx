import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Plus, Trash2, RefreshCw, Brain, Send, Upload, X, TrendingUp,
  TrendingDown, BarChart3, Wallet, FileText, ImageIcon, Loader2,
  ChevronDown, MessageSquare, AlertCircle, CheckCircle2, Filter,
  ArrowUpRight, ArrowDownRight, Search as SearchIcon, Star
} from 'lucide-react';

const BASE = import.meta.env.BASE_URL.replace(/\/$/, '');
const api  = (path: string) => `${BASE}${path}`;

interface Holding {
  symbol: string;
  name: string;
  quantity: number;
  buyPrice: number;
  currentPrice?: number;
  currentValue?: number;
  investedValue?: number;
  pnl?: number;
  pnlPercent?: number;
  change?: number;
  changePercent?: number;
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  ts: number;
  isError?: boolean;
}

const fmt = (n: number) =>
  n.toLocaleString('en-IN', { maximumFractionDigits: 2 });

const fmtCur = (n: number) =>
  '₹' + Math.abs(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });

function StatCard({ label, value, sub, positive }: { label: string; value: string; sub?: string; positive?: boolean }) {
  return (
    <div className="bg-secondary/50 border border-primary/10 rounded-xl p-4">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">{label}</div>
      <div className={`text-xl font-bold font-mono ${positive === true ? 'text-green-400' : positive === false ? 'text-red-400' : 'text-foreground'}`}>{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

const STORAGE_KEY = 'stocksage_portfolio_v1';
const CHAT_KEY    = 'stocksage_portfolio_chat_v1';

export default function Portfolio() {
  /* ─── state ─────────────────────────────────────────────── */
  const [holdings, setHoldings]     = useState<Holding[]>([]);
  const [enriched, setEnriched]     = useState<Holding[]>([]);
  const [loading, setLoading]       = useState(false);
  const [addOpen, setAddOpen]       = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [tab, setTab]               = useState<'holdings' | 'thesis' | 'screener'>('holdings');

  // screener
  const [screenerFilter, setScreenerFilter]   = useState<string>('gainers');
  const [screenerData, setScreenerData]       = useState<any[]>([]);
  const [screenerLoading, setScreenerLoading] = useState(false);

  // add form
  const [search, setSearch]         = useState('');
  const [results, setResults]       = useState<{symbol:string;name:string;sector:string}[]>([]);
  const [selected, setSelected]     = useState<{symbol:string;name:string}|null>(null);
  const [qty, setQty]               = useState('');
  const [buyPx, setBuyPx]           = useState('');
  const [searching, setSearching]   = useState(false);

  // thesis
  const [thesis, setThesis]         = useState('');
  const [thesisPending, setThesisPending] = useState(false);

  // chatbot
  const [chatMsg, setChatMsg]       = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [chatPending, setChatPending] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // image import
  const [imgPreview, setImgPreview] = useState<string | null>(null);
  const [imgMime, setImgMime]       = useState('image/jpeg');
  const [imgParsing, setImgParsing] = useState(false);
  const [imgError, setImgError]     = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  /* ─── persistence ──────────────────────────────────────── */
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) { try { setHoldings(JSON.parse(saved)); } catch {} }
    const savedChat = localStorage.getItem(CHAT_KEY);
    if (savedChat) { try { setChatHistory(JSON.parse(savedChat)); } catch {} }
  }, []);

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(holdings)); }, [holdings]);
  useEffect(() => { localStorage.setItem(CHAT_KEY, JSON.stringify(chatHistory)); }, [chatHistory]);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [chatHistory, chatPending]);

  /* ─── enrich with live prices ───────────────────────────── */
  const fetchPrices = useCallback(async (list: Holding[]) => {
    if (!list.length) { setEnriched([]); return; }
    setLoading(true);
    try {
      const res  = await fetch(api('/api/portfolio/analyze'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ holdings: list }),
      });
      const data = await res.json();
      if (data.enrichedHoldings) setEnriched(data.enrichedHoldings);
    } catch {
      setEnriched(list.map(h => ({ ...h, pnl: 0, pnlPercent: 0, currentPrice: h.buyPrice, currentValue: h.buyPrice * h.quantity, investedValue: h.buyPrice * h.quantity })));
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchPrices(holdings); }, [holdings]);

  /* ─── stock search ─────────────────────────────────────── */
  useEffect(() => {
    if (!search || search.length < 1) { setResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(api(`/api/stocks/search?q=${encodeURIComponent(search)}`));
        setResults(await r.json());
      } catch { setResults([]); }
      setSearching(false);
    }, 300);
    return () => clearTimeout(t);
  }, [search]);

  /* ─── add holding ──────────────────────────────────────── */
  const addHolding = () => {
    if (!selected || !qty || !buyPx) return;
    const q = parseFloat(qty);
    const b = parseFloat(buyPx);
    if (isNaN(q) || isNaN(b) || q <= 0 || b <= 0) return;
    setHoldings(prev => {
      const exists = prev.findIndex(h => h.symbol === selected.symbol);
      if (exists >= 0) {
        const copy = [...prev];
        const old  = copy[exists];
        const newQty  = old.quantity + q;
        const newAvg  = (old.buyPrice * old.quantity + b * q) / newQty;
        copy[exists]  = { ...old, quantity: newQty, buyPrice: Math.round(newAvg * 100) / 100 };
        return copy;
      }
      return [...prev, { symbol: selected.symbol, name: selected.name, quantity: q, buyPrice: b }];
    });
    setSelected(null); setSearch(''); setQty(''); setBuyPx(''); setAddOpen(false);
  };

  const removeHolding = (sym: string) => setHoldings(prev => prev.filter(h => h.symbol !== sym));

  /* ─── portfolio stats ──────────────────────────────────── */
  const totalInvested = enriched.reduce((s, h) => s + (h.investedValue ?? h.buyPrice * h.quantity), 0);
  const totalValue    = enriched.reduce((s, h) => s + (h.currentValue  ?? h.buyPrice * h.quantity), 0);
  const totalPnl      = totalValue - totalInvested;
  const totalReturn   = totalInvested ? (totalPnl / totalInvested) * 100 : 0;
  const dayChange     = enriched.reduce((s, h) => s + (h.change ?? 0) * (h.quantity), 0);

  /* ─── screener ─────────────────────────────────────────── */
  const fetchScreener = useCallback(async (filter: string) => {
    setScreenerLoading(true);
    try {
      const res  = await fetch(api(`/api/stocks/screener?filter=${filter}&limit=30`));
      const data = await res.json();
      setScreenerData(data);
    } catch { setScreenerData([]); }
    setScreenerLoading(false);
  }, []);

  useEffect(() => {
    if (tab === 'screener') fetchScreener(screenerFilter);
  }, [tab, screenerFilter, fetchScreener]);

  /* ─── generate thesis ───────────────────────────────────── */
  const generateThesis = async () => {
    if (!holdings.length) return;
    setThesisPending(true); setTab('thesis');
    try {
      const res  = await fetch(api('/api/portfolio/analyze'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ holdings }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setThesis(data.userMessage ?? 'AI analysis is currently unavailable. Please try again later.');
      } else {
        setThesis(data.thesis ?? '');
        if (data.enrichedHoldings) setEnriched(data.enrichedHoldings);
      }
    } catch { setThesis('Failed to generate thesis. Please try again.'); }
    setThesisPending(false);
  };

  /* ─── image import ──────────────────────────────────────── */
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImgMime(file.type || 'image/jpeg');
    const reader = new FileReader();
    reader.onload = (ev) => setImgPreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const parseImage = async () => {
    if (!imgPreview) return;
    setImgParsing(true); setImgError('');
    try {
      const base64 = imgPreview.split(',')[1];
      const res    = await fetch(api('/api/portfolio/parse-image'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64, mimeType: imgMime }),
      });
      const data   = await res.json();
      if (data.error) { setImgError(data.error); setImgParsing(false); return; }
      const parsed: Holding[] = (data.holdings ?? []).filter((h: any) => h.symbol && h.quantity > 0);
      if (!parsed.length) { setImgError('No holdings found in this image. Try a clearer screenshot.'); setImgParsing(false); return; }
      setHoldings(prev => {
        const copy = [...prev];
        for (const h of parsed) {
          const idx = copy.findIndex(x => x.symbol === h.symbol);
          if (idx >= 0) {
            const old    = copy[idx];
            const newQty = old.quantity + h.quantity;
            const newAvg = (old.buyPrice * old.quantity + h.buyPrice * h.quantity) / newQty;
            copy[idx]    = { ...old, quantity: newQty, buyPrice: Math.round(newAvg * 100) / 100 };
          } else { copy.push(h); }
        }
        return copy;
      });
      setImgPreview(null); setImportOpen(false);
    } catch { setImgError('Failed to parse image. Please try again.'); }
    setImgParsing(false);
  };

  /* ─── chatbot ───────────────────────────────────────────── */
  const sendChat = async () => {
    if (!chatMsg.trim() || chatPending) return;
    const msg = chatMsg.trim();
    setChatMsg('');
    const userMsg: ChatMessage = { role: 'user', content: msg, ts: Date.now() };
    setChatHistory(prev => [...prev, userMsg]);
    setChatPending(true);
    try {
      const res  = await fetch(api('/api/portfolio/chat'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ holdings, message: msg, history: chatHistory.slice(-10) }),
      });
      const data = await res.json();
      const reply = data.reply || data.userMessage || 'Sorry, I ran into an issue. Please try again.';
      setChatHistory(prev => [...prev, { role: 'assistant', content: reply, ts: Date.now(), isError: !!data.error }]);
    } catch {
      setChatHistory(prev => [...prev, { role: 'assistant', content: 'Could not reach the server. Please check your connection and try again.', ts: Date.now(), isError: true }]);
    }
    setChatPending(false);
  };

  /* ─── render ─────────────────────────────────────────────── */
  return (
    <div className="flex flex-col min-h-[calc(100vh-64px)] p-4 md:p-6 max-w-[1600px] mx-auto w-full gap-6">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold font-[family-name:var(--app-font-display)] glow-text">My Portfolio</h1>
          <p className="text-muted-foreground text-sm mt-1">Track holdings · AI thesis · Portfolio advisor chatbot</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setImportOpen(true)}
            className="px-3 py-2 bg-secondary border border-primary/20 text-foreground rounded-lg text-sm flex items-center gap-1.5 hover:bg-secondary/80 transition-colors">
            <ImageIcon className="w-4 h-4" /> Import Screenshot
          </button>
          <button onClick={() => setAddOpen(true)}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold flex items-center gap-2 hover:bg-primary/90 transition-colors">
            <Plus className="w-4 h-4" /> Add Stock
          </button>
        </div>
      </div>

      {/* Stats */}
      {holdings.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard label="Total Invested"  value={fmtCur(totalInvested)} />
          <StatCard label="Current Value"   value={fmtCur(totalValue)} />
          <StatCard label="Total P&L"       value={`${totalPnl >= 0 ? '+' : ''}${fmtCur(totalPnl)}`} sub={`${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`} positive={totalPnl >= 0} />
          <StatCard label="Today's Change"  value={`${dayChange >= 0 ? '+' : ''}${fmtCur(dayChange)}`} positive={dayChange >= 0} />
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-6 flex-1">

        {/* ── Left Panel ───────────────────────────────────────── */}
        <div className="flex-1 min-w-0 space-y-4">

          {/* Tab switcher */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex gap-1 bg-secondary/50 p-1 rounded-lg border border-primary/10 w-fit">
              {([
                { key: 'holdings', label: '📊 Holdings' },
                { key: 'thesis',   label: '🧠 AI Thesis' },
                { key: 'screener', label: '🔍 Market Screener' },
              ] as const).map(({ key, label }) => (
                <button key={key} onClick={() => setTab(key as any)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold uppercase tracking-wider transition-all ${tab === key ? 'bg-primary text-primary-foreground shadow' : 'text-muted-foreground hover:text-foreground'}`}>
                  {label}
                </button>
              ))}
            </div>
            {holdings.length > 0 && (
              <div className="flex gap-2">
                <button onClick={() => fetchPrices(holdings)} disabled={loading}
                  className="p-2 bg-secondary rounded-lg border border-primary/10 hover:bg-secondary/80 transition-colors disabled:opacity-50">
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                </button>
                <button onClick={generateThesis} disabled={thesisPending || !holdings.length}
                  className="px-3 py-2 bg-primary/10 border border-primary/20 text-primary rounded-lg text-xs font-semibold flex items-center gap-1.5 hover:bg-primary/20 transition-colors disabled:opacity-50">
                  {thesisPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Brain className="w-3.5 h-3.5" />}
                  {thesisPending ? 'Analysing…' : 'Generate AI Thesis'}
                </button>
              </div>
            )}
          </div>

          {/* ── HOLDINGS TAB ── */}
          <AnimatePresence mode="wait">
            {tab === 'holdings' && (
              <motion.div key="holdings" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                {holdings.length === 0 ? (
                  <Card className="bg-card border-primary/20">
                    <CardContent className="flex flex-col items-center justify-center py-20 gap-4 text-muted-foreground">
                      <div className="w-16 h-16 rounded-full bg-primary/5 border border-primary/10 flex items-center justify-center">
                        <Wallet className="w-7 h-7 opacity-30" />
                      </div>
                      <div className="text-center">
                        <p className="font-medium text-foreground">Your portfolio is empty</p>
                        <p className="text-sm mt-1">Add stocks manually or import a broker screenshot to get started.</p>
                      </div>
                      <div className="flex gap-3">
                        <button onClick={() => setAddOpen(true)}
                          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold flex items-center gap-2">
                          <Plus className="w-4 h-4" /> Add Stock
                        </button>
                        <button onClick={() => setImportOpen(true)}
                          className="px-4 py-2 bg-secondary border border-primary/20 rounded-lg text-sm flex items-center gap-2">
                          <ImageIcon className="w-4 h-4" /> Import Screenshot
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="bg-card border-primary/20 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-primary/10 bg-secondary/40">
                            {['Stock', 'Qty', 'Avg Price', 'LTP', 'Invested', 'Value', 'P&L', 'Return', ''].map(h => (
                              <th key={h} className="px-4 py-3 text-left text-[10px] uppercase tracking-wider text-muted-foreground font-semibold whitespace-nowrap">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {(enriched.length ? enriched : holdings).map((h, i) => {
                            const pnl    = h.pnl ?? 0;
                            const pnlPct = h.pnlPercent ?? 0;
                            const isPos  = pnl >= 0;
                            const invested = h.investedValue ?? h.buyPrice * h.quantity;
                            const value    = h.currentValue  ?? h.buyPrice * h.quantity;
                            return (
                              <motion.tr key={h.symbol} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}
                                className="border-b border-primary/5 hover:bg-secondary/20 transition-colors">
                                <td className="px-4 py-3">
                                  <div className="font-bold text-foreground font-mono text-xs">{h.symbol}</div>
                                  <div className="text-[10px] text-muted-foreground truncate max-w-[140px]">{h.name}</div>
                                </td>
                                <td className="px-4 py-3 font-mono text-foreground">{h.quantity}</td>
                                <td className="px-4 py-3 font-mono text-muted-foreground">₹{fmt(h.buyPrice)}</td>
                                <td className="px-4 py-3 font-mono">
                                  <div className="text-foreground">₹{fmt(h.currentPrice ?? h.buyPrice)}</div>
                                  {h.changePercent !== undefined && (
                                    <div className={`text-[10px] ${h.changePercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                      {h.changePercent >= 0 ? '▲' : '▼'} {Math.abs(h.changePercent).toFixed(2)}%
                                    </div>
                                  )}
                                </td>
                                <td className="px-4 py-3 font-mono text-muted-foreground">₹{fmt(invested)}</td>
                                <td className="px-4 py-3 font-mono text-foreground">₹{fmt(value)}</td>
                                <td className={`px-4 py-3 font-mono font-semibold ${isPos ? 'text-green-400' : 'text-red-400'}`}>
                                  {isPos ? '+' : ''}₹{fmt(Math.abs(pnl))}
                                </td>
                                <td className={`px-4 py-3 font-mono text-sm font-semibold ${isPos ? 'text-green-400' : 'text-red-400'}`}>
                                  <span className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded text-[11px] ${isPos ? 'bg-green-400/10' : 'bg-red-400/10'}`}>
                                    {isPos ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                                    {isPos ? '+' : ''}{pnlPct.toFixed(2)}%
                                  </span>
                                </td>
                                <td className="px-4 py-3">
                                  <button onClick={() => removeHolding(h.symbol)} className="p-1.5 hover:bg-red-400/10 rounded-lg transition-colors text-muted-foreground hover:text-red-400">
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </motion.tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </Card>
                )}
              </motion.div>
            )}

            {/* ── THESIS TAB ── */}
            {tab === 'thesis' && (
              <motion.div key="thesis" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <Card className="bg-card border-primary/20">
                  <CardContent className="p-6">
                    {thesisPending ? (
                      <div className="flex flex-col items-center justify-center py-16 gap-4 text-muted-foreground">
                        <div className="relative">
                          <div className="w-16 h-16 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                            <Brain className="w-7 h-7 text-primary animate-pulse" />
                          </div>
                          <div className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping" />
                        </div>
                        <div className="text-sm font-mono animate-pulse">Analysing your portfolio with Claude AI…</div>
                      </div>
                    ) : thesis ? (
                      <div className="prose prose-invert prose-sm max-w-none">
                        {thesis.split('\n').map((line, i) => {
                          if (line.startsWith('## ')) return <h3 key={i} className="text-primary font-bold text-base mt-6 mb-3 border-b border-primary/20 pb-2">{line.slice(3)}</h3>;
                          if (line.startsWith('# '))  return <h2 key={i} className="text-foreground font-bold text-lg mt-4 mb-2">{line.slice(2)}</h2>;
                          if (line.startsWith('**') && line.endsWith('**')) return <p key={i} className="font-bold text-foreground">{line.slice(2, -2)}</p>;
                          if (line.startsWith('• ') || line.startsWith('- ')) return <p key={i} className="flex gap-2 text-foreground/85"><span className="text-primary mt-0.5 shrink-0">▸</span><span>{line.slice(2)}</span></p>;
                          if (!line.trim()) return <div key={i} className="h-2" />;
                          return <p key={i} className="text-foreground/80 leading-relaxed">{line}</p>;
                        })}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-16 gap-4 text-muted-foreground">
                        <FileText className="w-12 h-12 opacity-20" />
                        <div className="text-center">
                          <p className="text-sm">No thesis generated yet.</p>
                          <p className="text-xs mt-1">Click "Generate AI Thesis" to get a comprehensive portfolio analysis.</p>
                        </div>
                        <button onClick={generateThesis} disabled={!holdings.length}
                          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold flex items-center gap-2">
                          <Brain className="w-4 h-4" /> Generate AI Thesis
                        </button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}
            {/* ── SCREENER TAB ── */}
            {tab === 'screener' && (
              <motion.div key="screener" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
                {/* Filter buttons */}
                <div className="flex flex-wrap gap-2">
                  {[
                    { key: 'gainers',    label: '📈 Top Gainers',       desc: 'Highest % rise today' },
                    { key: 'losers',     label: '📉 Top Losers',        desc: 'Biggest falls today' },
                    { key: 'volume',     label: '🔥 Volume Leaders',    desc: 'Highest trading volume' },
                    { key: '52week_high',label: '🏔️ Near 52W High',     desc: 'Approaching 52-week high' },
                    { key: 'pe_low',     label: '💎 Value Stocks',      desc: 'Lowest P/E ratio' },
                    { key: 'revenue',    label: '🚀 Revenue Growth',    desc: 'Best quarterly profit growth' },
                  ].map(f => (
                    <button key={f.key}
                      onClick={() => setScreenerFilter(f.key)}
                      className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all border ${screenerFilter === f.key ? 'bg-primary text-primary-foreground border-transparent shadow-lg' : 'bg-secondary/50 text-muted-foreground border-primary/10 hover:border-primary/30 hover:text-foreground'}`}
                      title={f.desc}>
                      {f.label}
                    </button>
                  ))}
                </div>

                {screenerLoading ? (
                  <div className="flex items-center justify-center py-16 text-muted-foreground gap-3">
                    <Loader2 className="w-5 h-5 animate-spin text-primary" />
                    <span className="text-sm font-mono">Loading market data…</span>
                  </div>
                ) : (
                  <Card className="bg-card border-primary/20 overflow-hidden">
                    <div className="px-4 py-3 bg-secondary/30 border-b border-primary/10 flex items-center justify-between">
                      <span className="text-xs font-semibold text-foreground font-[family-name:var(--app-font-display)]">
                        {screenerFilter === 'gainers'     ? 'Top Gainers — Highest % Rise Today'           :
                         screenerFilter === 'losers'      ? 'Top Losers — Biggest Declines Today'           :
                         screenerFilter === 'volume'      ? 'Volume Leaders — Most Active Stocks'           :
                         screenerFilter === '52week_high' ? 'Near 52-Week High — Momentum Stocks'          :
                         screenerFilter === 'pe_low'      ? 'Value Stocks — Lowest P/E Ratio'               :
                                                           'Revenue Growth — Best Quarterly Profits'}
                      </span>
                      <button onClick={() => fetchScreener(screenerFilter)} className="p-1 hover:bg-secondary rounded transition-colors">
                        <RefreshCw className="w-3 h-3 text-muted-foreground" />
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-primary/10 bg-secondary/20">
                            {['#','Stock','Sector','Price','Change',
                              screenerFilter === 'volume'      ? 'Volume'   :
                              screenerFilter === 'pe_low'      ? 'P/E'      :
                              screenerFilter === 'revenue'     ? 'Rev Grow%':
                              screenerFilter === '52week_high' ? 'Near High':
                              'Volume',
                              'Mkt Cap','Add'
                            ].map(h => (
                              <th key={h} className="px-3 py-2.5 text-left text-[10px] uppercase tracking-wider text-muted-foreground font-semibold whitespace-nowrap">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {screenerData.map((s: any, i: number) => {
                            const isPos = s.changePercent >= 0;
                            const inPortfolio = holdings.some(h => h.symbol === s.symbol);
                            return (
                              <motion.tr key={s.symbol} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }}
                                className="border-b border-primary/5 hover:bg-secondary/20 transition-colors">
                                <td className="px-3 py-2.5 text-xs text-muted-foreground font-mono">{i + 1}</td>
                                <td className="px-3 py-2.5">
                                  <div className="font-bold font-mono text-xs text-primary">{s.symbol}</div>
                                  <div className="text-[10px] text-muted-foreground truncate max-w-[150px]">{s.name}</div>
                                </td>
                                <td className="px-3 py-2.5">
                                  <span className="text-[9px] px-1.5 py-0.5 bg-secondary rounded text-muted-foreground">{s.sector}</span>
                                </td>
                                <td className="px-3 py-2.5 font-mono text-xs text-foreground">₹{s.price.toLocaleString('en-IN', { maximumFractionDigits: 1 })}</td>
                                <td className="px-3 py-2.5">
                                  <span className={`inline-flex items-center gap-0.5 text-xs font-mono font-semibold ${isPos ? 'text-green-400' : 'text-red-400'}`}>
                                    {isPos ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                                    {isPos ? '+' : ''}{s.changePercent}%
                                  </span>
                                </td>
                                <td className="px-3 py-2.5 font-mono text-xs text-muted-foreground">
                                  {screenerFilter === 'pe_low'      ? <span className={s.pe < 15 ? 'text-green-400' : s.pe > 40 ? 'text-red-400' : 'text-foreground'}>{s.pe}x</span>        :
                                   screenerFilter === 'revenue'     ? <span className={s.revenueGrowth > 30 ? 'text-green-400' : s.revenueGrowth < 0 ? 'text-red-400' : 'text-foreground'}>{s.revenueGrowth > 0 ? '+' : ''}{s.revenueGrowth}%</span> :
                                   screenerFilter === '52week_high' ? <span className={s.nearHighPct > 80 ? 'text-green-400' : 'text-foreground'}>{s.nearHighPct}%</span>                :
                                   <span>{(s.volume / 1_000_000).toFixed(1)}M</span>}
                                </td>
                                <td className="px-3 py-2.5 font-mono text-[10px] text-muted-foreground">
                                  ₹{s.marketCap >= 1e12 ? (s.marketCap / 1e12).toFixed(1) + 'T' : s.marketCap >= 1e9 ? (s.marketCap / 1e9).toFixed(0) + 'B' : (s.marketCap / 1e6).toFixed(0) + 'M'}
                                </td>
                                <td className="px-3 py-2.5">
                                  {inPortfolio ? (
                                    <span className="text-[9px] px-1.5 py-0.5 bg-green-400/10 text-green-400 rounded">In Portfolio</span>
                                  ) : (
                                    <button
                                      onClick={() => { setSelected({ symbol: s.symbol, name: s.name }); setAddOpen(true); }}
                                      className="text-[9px] px-2 py-1 bg-primary/10 border border-primary/20 text-primary rounded hover:bg-primary/20 transition-colors font-semibold">
                                      + Add
                                    </button>
                                  )}
                                </td>
                              </motion.tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </Card>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ── Right Panel: Portfolio Chatbot ─────────────────── */}
        <div className="w-full lg:w-[380px] shrink-0 flex flex-col" style={{ height: 'calc(100vh - 200px)', minHeight: 520 }}>
          <Card className="bg-card border-primary/20 flex flex-col h-full overflow-hidden">
            <CardHeader className="pb-3 bg-secondary/20 border-b border-primary/10 shrink-0">
              <CardTitle className="text-sm font-[family-name:var(--app-font-display)] flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <MessageSquare className="w-3.5 h-3.5 text-primary" />
                </div>
                Portfolio Advisor AI
                <span className="ml-auto text-[10px] font-normal text-muted-foreground">Powered by Claude</span>
              </CardTitle>
              {holdings.length > 0 && (
                <p className="text-[10px] text-muted-foreground mt-1">
                  Advising on {holdings.length} stock{holdings.length !== 1 ? 's' : ''} · ₹{fmt(totalInvested)} invested
                </p>
              )}
            </CardHeader>

            {/* Chat messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
              {chatHistory.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full gap-3 text-muted-foreground">
                  <Brain className="w-10 h-10 opacity-20" />
                  <div className="text-center text-sm">
                    <p className="font-medium text-foreground text-xs">Portfolio Advisor AI</p>
                    <p className="text-xs mt-1">Ask me anything about your portfolio — rebalancing, risk, stock picks, market outlook.</p>
                  </div>
                  {holdings.length === 0 && (
                    <div className="flex flex-wrap gap-1.5 justify-center mt-2">
                      {["What stocks should I buy?", "How to build an NSE portfolio?", "Explain SIP strategy"].map(q => (
                        <button key={q} onClick={() => { setChatMsg(q); }} className="text-[10px] px-2 py-1 bg-secondary rounded border border-primary/10 hover:border-primary/30 text-muted-foreground hover:text-foreground transition-colors">
                          {q}
                        </button>
                      ))}
                    </div>
                  )}
                  {holdings.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 justify-center mt-2">
                      {["Should I rebalance now?", "What are my biggest risks?", "Which stock should I sell?"].map(q => (
                        <button key={q} onClick={() => { setChatMsg(q); }} className="text-[10px] px-2 py-1 bg-secondary rounded border border-primary/10 hover:border-primary/30 text-muted-foreground hover:text-foreground transition-colors">
                          {q}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
              {chatHistory.map((m, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded-2xl px-3 py-2.5 text-xs leading-relaxed whitespace-pre-wrap ${
                    m.role === 'user'
                      ? 'bg-primary text-primary-foreground rounded-br-sm'
                      : m.isError
                        ? 'bg-amber-950/40 text-amber-200 border border-amber-500/30 rounded-bl-sm'
                        : 'bg-secondary/80 text-foreground border border-primary/10 rounded-bl-sm'
                  }`}>
                    {m.content.split('\n').map((line, j) => {
                      if (line.startsWith('**') && line.endsWith('**')) {
                        return <p key={j} className="font-bold mb-1">{line.slice(2, -2)}</p>;
                      }
                      if (line.startsWith('⚠️ **') ) {
                        const rest = line.replace('⚠️ **', '').replace('**', '');
                        return <p key={j} className="font-bold flex items-center gap-1 mb-1"><span>⚠️</span>{rest}</p>;
                      }
                      if (!line.trim()) return <div key={j} className="h-1" />;
                      return <span key={j}>{line}<br/></span>;
                    })}
                  </div>
                </motion.div>
              ))}
              {chatPending && (
                <div className="flex justify-start">
                  <div className="bg-secondary/80 border border-primary/10 rounded-2xl rounded-bl-sm px-3 py-2.5">
                    <div className="flex gap-1 items-center h-4">
                      {[0,1,2].map(i => <span key={i} className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />)}
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Chat input */}
            <div className="p-3 border-t border-primary/10 shrink-0">
              {chatHistory.length > 0 && (
                <button onClick={() => { setChatHistory([]); localStorage.removeItem(CHAT_KEY); }} className="text-[10px] text-muted-foreground hover:text-foreground mb-2 flex items-center gap-1 transition-colors">
                  <X className="w-3 h-3" /> Clear chat
                </button>
              )}
              <div className="flex gap-2">
                <input
                  value={chatMsg} onChange={e => setChatMsg(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendChat()}
                  placeholder="Ask about your portfolio…"
                  className="flex-1 bg-secondary/60 border border-primary/20 rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
                />
                <button onClick={sendChat} disabled={chatPending || !chatMsg.trim()}
                  className="p-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50 transition-colors">
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* ── Add Stock Modal ───────────────────────────────────── */}
      <AnimatePresence>
        {addOpen && (
          <motion.div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={e => e.target === e.currentTarget && setAddOpen(false)}>
            <motion.div initial={{ scale: 0.92, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.92, opacity: 0 }}
              className="bg-card border border-primary/20 rounded-2xl p-6 w-full max-w-md shadow-2xl">
              <div className="flex justify-between items-center mb-5">
                <h3 className="font-bold font-[family-name:var(--app-font-display)]">Add Stock</h3>
                <button onClick={() => setAddOpen(false)} className="p-1.5 hover:bg-secondary rounded-lg"><X className="w-4 h-4" /></button>
              </div>
              {/* Search */}
              <div className="relative mb-3">
                <input value={search} onChange={e => { setSearch(e.target.value); setSelected(null); }}
                  placeholder="Search NSE stock…"
                  className="w-full bg-secondary/60 border border-primary/20 rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50" />
                {searching && <Loader2 className="absolute right-3 top-3 w-4 h-4 animate-spin text-muted-foreground" />}
                {results.length > 0 && !selected && (
                  <div className="absolute z-10 w-full mt-1 bg-card border border-primary/20 rounded-lg shadow-xl max-h-48 overflow-y-auto">
                    {results.map(r => (
                      <button key={r.symbol} onClick={() => { setSelected(r); setSearch(r.name); setResults([]); }}
                        className="w-full px-3 py-2.5 text-left hover:bg-secondary/60 transition-colors border-b border-primary/5 last:border-0">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-xs font-mono text-primary">{r.symbol}</span>
                            <span className="text-xs text-muted-foreground ml-2 truncate">{r.name}</span>
                          </div>
                          <span className="text-[10px] text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">{r.sector}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {selected && (
                <div className="flex items-center gap-2 mb-4 p-2 bg-primary/5 border border-primary/10 rounded-lg">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                  <div>
                    <span className="text-xs font-bold font-mono">{selected.symbol}</span>
                    <span className="text-xs text-muted-foreground ml-2">{selected.name}</span>
                  </div>
                </div>
              )}
              <div className="grid grid-cols-2 gap-3 mb-5">
                <div>
                  <label className="text-xs text-muted-foreground mb-1.5 block">Quantity (shares)</label>
                  <input type="number" value={qty} onChange={e => setQty(e.target.value)} placeholder="e.g. 10"
                    className="w-full bg-secondary/60 border border-primary/20 rounded-lg px-3 py-2.5 text-sm text-foreground focus:outline-none focus:border-primary/50" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1.5 block">Avg Buy Price (₹)</label>
                  <input type="number" value={buyPx} onChange={e => setBuyPx(e.target.value)} placeholder="e.g. 2500"
                    className="w-full bg-secondary/60 border border-primary/20 rounded-lg px-3 py-2.5 text-sm text-foreground focus:outline-none focus:border-primary/50" />
                </div>
              </div>
              {selected && qty && buyPx && (
                <div className="mb-4 p-3 bg-secondary/40 rounded-lg text-xs font-mono text-muted-foreground">
                  Investment: ₹{fmt(parseFloat(qty) * parseFloat(buyPx))} · {qty} × ₹{buyPx}
                </div>
              )}
              <button onClick={addHolding} disabled={!selected || !qty || !buyPx}
                className="w-full py-2.5 bg-primary text-primary-foreground rounded-lg font-semibold text-sm disabled:opacity-50 hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" /> Add to Portfolio
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Import Screenshot Modal ──────────────────────────── */}
      <AnimatePresence>
        {importOpen && (
          <motion.div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={e => e.target === e.currentTarget && setImportOpen(false)}>
            <motion.div initial={{ scale: 0.92, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.92, opacity: 0 }}
              className="bg-card border border-primary/20 rounded-2xl p-6 w-full max-w-lg shadow-2xl">
              <div className="flex justify-between items-center mb-5">
                <div>
                  <h3 className="font-bold font-[family-name:var(--app-font-display)]">Import Portfolio Screenshot</h3>
                  <p className="text-xs text-muted-foreground mt-1">Upload a broker app screenshot — Claude AI will extract your holdings.</p>
                </div>
                <button onClick={() => { setImportOpen(false); setImgPreview(null); setImgError(''); }} className="p-1.5 hover:bg-secondary rounded-lg"><X className="w-4 h-4" /></button>
              </div>

              {!imgPreview ? (
                <div
                  onClick={() => fileRef.current?.click()}
                  className="border-2 border-dashed border-primary/20 hover:border-primary/40 rounded-xl p-10 flex flex-col items-center justify-center gap-3 cursor-pointer transition-colors group">
                  <div className="w-12 h-12 rounded-full bg-primary/5 border border-primary/10 group-hover:bg-primary/10 flex items-center justify-center transition-colors">
                    <Upload className="w-5 h-5 text-primary/60" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-foreground">Click to upload screenshot</p>
                    <p className="text-xs text-muted-foreground mt-1">Works with Zerodha, Groww, Upstox, Angel One, HDFC Sky & more</p>
                  </div>
                  <p className="text-[10px] text-muted-foreground">PNG, JPG, WebP · Max 10MB</p>
                  <input ref={fileRef} type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative rounded-xl overflow-hidden border border-primary/20">
                    <img src={imgPreview} alt="Portfolio screenshot" className="w-full max-h-64 object-contain bg-black/20" />
                    <button onClick={() => { setImgPreview(null); setImgError(''); if (fileRef.current) fileRef.current.value = ''; }}
                      className="absolute top-2 right-2 p-1 bg-black/60 rounded-full hover:bg-black/80 transition-colors">
                      <X className="w-4 h-4 text-white" />
                    </button>
                  </div>
                  {imgError && (
                    <div className="flex items-center gap-2 p-3 bg-red-400/10 border border-red-400/20 rounded-lg text-red-400 text-xs">
                      <AlertCircle className="w-4 h-4 shrink-0" /> {imgError}
                    </div>
                  )}
                  <button onClick={parseImage} disabled={imgParsing}
                    className="w-full py-2.5 bg-primary text-primary-foreground rounded-lg font-semibold text-sm disabled:opacity-50 hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                    {imgParsing ? <><Loader2 className="w-4 h-4 animate-spin" /> Extracting holdings…</> : <><Brain className="w-4 h-4" /> Extract Holdings with AI</>}
                  </button>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground text-center mt-4">
                Tip: Take a full screenshot of your broker's holdings/portfolio page for best results.
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { useStockStore } from '@/store/stockStore';
import { useStrategyStore } from '@/store/strategyStore';
import { useGetDashboard, useGetFinalVerdict, useGetStockQuote } from '@workspace/api-client-react';
import { getGetDashboardQueryKey } from '@workspace/api-client-react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatCurrency, formatCompactNumber, formatPercent } from '@/lib/format';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, Cell } from 'recharts';
import {
  Loader2, TrendingUp, TrendingDown, Target, ShieldAlert,
  Search, Brain, LineChart, Users, BarChart2, Activity,
  ChevronRight, Sparkles, Zap, Download
} from 'lucide-react';

type VerdictData = {
  recommendation: string;
  confidence: number;
  investmentHorizon: string;
  currentPrice?: number;
  atr?: number;
  entryZoneLow: number;
  entryZoneHigh: number;
  stopLoss: number;
  stopLossPercent: number;
  target1: number;
  target1Percent: number;
  target2: number;
  target2Percent: number;
  executiveSummary: string;
  bullCase: string[];
  bearCase: string[];
  catalysts: string[];
  expertTake: string;
  fullAnalysis?: string;
  generatedAt?: string;
  stockName?: string;
  sector?: string;
};

function downloadVerdict(verdict: VerdictData, symbol: string) {
  const now = verdict.generatedAt ? new Date(verdict.generatedAt).toLocaleString('en-IN') : new Date().toLocaleString('en-IN');
  const rec = verdict.recommendation.replace(/_/g, ' ');
  const recColor = rec.includes('BUY') ? '#16a34a' : rec.includes('SELL') ? '#dc2626' : '#d97706';
  const fmt = (n: number) => n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>StockSage AI — ${symbol} Investment Report</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Arial, sans-serif; background: #f8fafc; color: #1e293b; font-size: 14px; }
  .page { max-width: 860px; margin: 0 auto; background: #fff; min-height: 100vh; }
  .header { background: #0f172a; color: #fff; padding: 32px 40px 24px; }
  .header-top { display: flex; justify-content: space-between; align-items: flex-start; }
  .brand { font-size: 11px; letter-spacing: 0.15em; color: #94a3b8; margin-bottom: 8px; }
  .stock-title { font-size: 28px; font-weight: 800; letter-spacing: -0.5px; }
  .stock-meta { font-size: 13px; color: #94a3b8; margin-top: 4px; }
  .price-block { text-align: right; }
  .price { font-size: 32px; font-weight: 700; font-family: monospace; color: #e2e8f0; }
  .price-label { font-size: 11px; color: #64748b; margin-top: 2px; }
  .header-footer { margin-top: 20px; display: flex; gap: 8px; align-items: center; }
  .rec-badge { display: inline-block; background: ${recColor}22; border: 1.5px solid ${recColor}; color: ${recColor}; font-weight: 800; font-size: 15px; padding: 6px 18px; border-radius: 6px; letter-spacing: 0.05em; }
  .meta-chips { display: flex; gap: 12px; font-size: 12px; color: #94a3b8; margin-left: 16px; }
  .meta-chip span { color: #e2e8f0; font-weight: 600; }
  .body { padding: 32px 40px; }
  .section { margin-bottom: 28px; }
  .section-title { font-size: 10px; font-weight: 800; letter-spacing: 0.12em; text-transform: uppercase; color: #64748b; margin-bottom: 12px; padding-bottom: 6px; border-bottom: 1px solid #e2e8f0; }
  .summary-box { background: #f1f5f9; border-left: 3px solid #3b82f6; padding: 14px 16px; border-radius: 0 6px 6px 0; font-size: 14px; line-height: 1.7; color: #334155; }
  .trade-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
  .trade-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; text-align: center; }
  .trade-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: #64748b; margin-bottom: 6px; }
  .trade-value { font-size: 16px; font-weight: 700; font-family: monospace; }
  .trade-pct { font-size: 11px; color: #64748b; margin-top: 2px; }
  .entry-val { color: #3b82f6; }
  .stop-val { color: #dc2626; }
  .t1-val { color: #16a34a; }
  .t2-val { color: #15803d; }
  .cols-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
  .list-item { display: flex; gap: 8px; margin-bottom: 8px; font-size: 13px; line-height: 1.5; color: #475569; }
  .list-icon-bull { color: #16a34a; font-weight: 700; flex-shrink: 0; }
  .list-icon-bear { color: #dc2626; font-weight: 700; flex-shrink: 0; }
  .list-icon-cat  { color: #d97706; font-weight: 700; flex-shrink: 0; }
  .expert-box { background: #fafaf9; border: 1px solid #e7e5e4; border-radius: 8px; padding: 16px; font-size: 13px; line-height: 1.7; color: #44403c; font-style: italic; }
  .full-analysis { white-space: pre-wrap; font-size: 12.5px; line-height: 1.75; color: #374151; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; }
  .footer { background: #f1f5f9; border-top: 1px solid #e2e8f0; padding: 16px 40px; font-size: 11px; color: #94a3b8; display: flex; justify-content: space-between; }
  @media print { body { background: #fff; } .page { max-width: 100%; } }
</style>
</head>
<body>
<div class="page">
  <div class="header">
    <div class="header-top">
      <div>
        <div class="brand">STOCKSAGE AI — INVESTMENT RESEARCH REPORT</div>
        <div class="stock-title">${symbol}</div>
        <div class="stock-meta">${verdict.stockName ?? symbol} &nbsp;•&nbsp; ${verdict.sector ?? 'NSE Listed'} &nbsp;•&nbsp; NSE</div>
      </div>
      ${verdict.currentPrice ? `<div class="price-block"><div class="price">₹${fmt(verdict.currentPrice)}</div><div class="price-label">Market Price at Analysis</div></div>` : ''}
    </div>
    <div class="header-footer">
      <div class="rec-badge">${rec}</div>
      <div class="meta-chips">
        <div>Confidence: <span>${verdict.confidence}%</span></div>
        <div>Horizon: <span>${verdict.investmentHorizon}</span></div>
        ${verdict.atr ? `<div>ATR: <span>₹${fmt(verdict.atr)}</span></div>` : ''}
        <div>Generated: <span>${now}</span></div>
      </div>
    </div>
  </div>

  <div class="body">
    <div class="section">
      <div class="section-title">Executive Summary</div>
      <div class="summary-box">${verdict.executiveSummary}</div>
    </div>

    <div class="section">
      <div class="section-title">Trade Plan</div>
      <div class="trade-grid">
        <div class="trade-card">
          <div class="trade-label">Entry Zone</div>
          <div class="trade-value entry-val">₹${fmt(verdict.entryZoneLow)}<br><small style="font-size:12px">– ₹${fmt(verdict.entryZoneHigh)}</small></div>
        </div>
        <div class="trade-card">
          <div class="trade-label">Stop Loss</div>
          <div class="trade-value stop-val">₹${fmt(verdict.stopLoss)}</div>
          <div class="trade-pct">Risk: ${verdict.stopLossPercent}%</div>
        </div>
        <div class="trade-card">
          <div class="trade-label">Target 1</div>
          <div class="trade-value t1-val">₹${fmt(verdict.target1)}</div>
          <div class="trade-pct">+${verdict.target1Percent}%</div>
        </div>
        <div class="trade-card">
          <div class="trade-label">Target 2</div>
          <div class="trade-value t2-val">₹${fmt(verdict.target2)}</div>
          <div class="trade-pct">+${verdict.target2Percent}%</div>
        </div>
      </div>
    </div>

    <div class="section">
      <div class="cols-2">
        <div>
          <div class="section-title">Bull Case</div>
          ${verdict.bullCase.map(b => `<div class="list-item"><span class="list-icon-bull">▲</span><span>${b}</span></div>`).join('')}
        </div>
        <div>
          <div class="section-title">Bear Case</div>
          ${verdict.bearCase.map(b => `<div class="list-item"><span class="list-icon-bear">▼</span><span>${b}</span></div>`).join('')}
        </div>
      </div>
    </div>

    <div class="section">
      <div class="section-title">Catalysts to Watch</div>
      ${verdict.catalysts.map(c => `<div class="list-item"><span class="list-icon-cat">◆</span><span>${c}</span></div>`).join('')}
    </div>

    <div class="section">
      <div class="section-title">Expert Perspective</div>
      <div class="expert-box">${verdict.expertTake}</div>
    </div>

    ${verdict.fullAnalysis ? `
    <div class="section">
      <div class="section-title">Full AI Analysis</div>
      <div class="full-analysis">${verdict.fullAnalysis.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
    </div>` : ''}
  </div>

  <div class="footer">
    <div>StockSage AI &nbsp;•&nbsp; Powered by Claude claude-sonnet-4-6 &nbsp;•&nbsp; ${now}</div>
    <div>For educational purposes only. Not financial advice. SEBI regulations apply.</div>
  </div>
</div>
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `StockSage_${symbol}_${new Date().toISOString().slice(0,10)}.html`;
  a.click();
  URL.revokeObjectURL(url);
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.07, delayChildren: 0.05 } }
};
const itemVariants = {
  hidden: { opacity: 0, y: 24, scale: 0.97 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } }
};

const QUICK_PICKS = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', sector: 'Energy' },
  { symbol: 'TCS', name: 'Tata Consultancy', sector: 'IT' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', sector: 'Banking' },
  { symbol: 'INFY', name: 'Infosys', sector: 'IT' },
  { symbol: 'WIPRO', name: 'Wipro', sector: 'IT' },
  { symbol: 'TATAMOTORS', name: 'Tata Motors', sector: 'Auto' },
];

const HOW_IT_WORKS = [
  { step: '01', icon: Search, title: 'Search Any NSE Stock', desc: 'Type a symbol or company name — search 1,800+ NSE-listed stocks via live Yahoo Finance.', color: 'var(--signal-buy)' },
  { step: '02', icon: BarChart2, title: 'Get Multi-Dimensional Scores', desc: 'Technical, Fundamental & Sentiment scores from 20+ real market indicators.', color: '#a78bfa' },
  { step: '03', icon: Brain, title: 'Generate AI Verdict', desc: 'Claude AI synthesises all data into BUY/HOLD/SELL with entry, stop-loss & targets.', color: '#f59e0b' },
  { step: '04', icon: Users, title: 'Consult Legendary Investors', desc: 'Ask Jhunjhunwala, Buffett, Lynch or 7 other legends for their unique perspective.', color: '#ec4899' },
];

const FEATURE_CARDS = [
  { icon: LineChart, label: 'Technical', desc: 'RSI, MACD, Bollinger Bands, ADX, Supertrend + AI summary', href: '/technical', color: 'var(--signal-buy)' },
  { icon: BarChart2, label: 'Fundamental', desc: '5-yr financials, DCF valuation, Graham Number, peer compare', href: '/fundamental', color: '#a78bfa' },
  { icon: Activity, label: 'Sentiment', desc: 'Fear & Greed gauge, FII/DII flows, India VIX, news analysis', href: '/sentiment', color: '#f59e0b' },
  { icon: Users, label: 'Experts', desc: '10 legendary investors as AI personas ready to advise you', href: '/experts', color: '#ec4899' },
];

function ScoreRing({ score, color, size = 80 }: { score: number; color: string; size?: number }) {
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const [displayed, setDisplayed] = useState(0);

  useEffect(() => {
    let frame: number;
    let start: number;
    const duration = 900;
    const animate = (ts: number) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayed(Math.round(eased * score));
      if (progress < 1) frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [score]);

  const offset = circ - (displayed / 100) * circ;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8" />
      <circle
        cx={size / 2} cy={size / 2} r={r}
        fill="none" stroke={color} strokeWidth="8"
        strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ filter: `drop-shadow(0 0 6px ${color})` }}
      />
      <text x={size / 2} y={size / 2 + 5} textAnchor="middle" fill={color} fontSize="16" fontWeight="700" fontFamily="monospace">
        {displayed}
      </text>
    </svg>
  );
}

function GridBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none" aria-hidden>
      <svg className="absolute inset-0 w-full h-full opacity-[0.04]" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="cmd-grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#cmd-grid)" className="text-primary" />
      </svg>
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] rounded-full bg-primary/5 blur-[120px]" />
    </div>
  );
}

function QuickPickButton({ symbol, name, sector, onSelect }: { symbol: string; name: string; sector: string; onSelect: (s: string) => void }) {
  return (
    <motion.button
      whileHover={{ scale: 1.03, y: -2 }}
      whileTap={{ scale: 0.97 }}
      onClick={() => onSelect(symbol)}
      className="relative flex items-center justify-between px-4 py-3 rounded-lg border border-primary/20 bg-card/60 hover:border-primary/50 hover:bg-card transition-all text-left w-full group overflow-hidden"
    >
      <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="relative">
        <div className="font-bold font-mono text-primary text-sm">{symbol}</div>
        <div className="text-[11px] text-muted-foreground">{name}</div>
      </div>
      <div className="relative flex items-center gap-2">
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-secondary text-muted-foreground">{sector}</span>
        <ChevronRight className="w-3 h-3 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all" />
      </div>
    </motion.button>
  );
}

function EmptyState({ onSelectStock }: { onSelectStock: (symbol: string) => void }) {
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setActiveStep(s => (s + 1) % HOW_IT_WORKS.length), 2600);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative flex-1 min-h-[calc(100vh-4rem)] overflow-hidden">
      <GridBackground />
      <div className="relative z-10 max-w-6xl mx-auto px-6 py-10 space-y-12">

        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-mono text-primary mb-2">
            <Sparkles className="w-3 h-3" />
            Bloomberg meets Blade Runner — NSE Intelligence Platform
          </div>
          <h1 className="text-5xl md:text-6xl font-bold font-[family-name:var(--app-font-display)] leading-tight">
            Command{' '}
            <span className="text-primary" style={{ textShadow: '0 0 40px var(--color-primary)' }}>Centre</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Search any NSE stock to unlock AI-powered technical, fundamental & sentiment analysis with legendary investor perspectives.
          </p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.5 }}>
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground mb-3 text-center font-mono">Quick Start — Select a Stock</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-w-2xl mx-auto">
            {QUICK_PICKS.map((s, i) => (
              <motion.div key={s.symbol} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 + i * 0.06 }}>
                <QuickPickButton {...s} onSelect={onSelectStock} />
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground text-center font-mono mb-4">How It Works</p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {HOW_IT_WORKS.map((step, i) => {
              const Icon = step.icon;
              const isActive = activeStep === i;
              return (
                <motion.div
                  key={i}
                  animate={{
                    borderColor: isActive ? step.color : 'rgba(255,255,255,0.08)',
                    backgroundColor: isActive ? `${step.color}12` : 'rgba(0,0,0,0)',
                  }}
                  transition={{ duration: 0.35 }}
                  onMouseEnter={() => setActiveStep(i)}
                  className="relative rounded-xl border p-5 cursor-default overflow-hidden"
                >
                  <div className="absolute top-3 right-3 font-mono text-[10px] opacity-25 select-none">{step.step}</div>
                  <motion.div animate={{ color: isActive ? step.color : 'rgba(255,255,255,0.25)' }} className="mb-3">
                    <Icon className="w-6 h-6" />
                  </motion.div>
                  <div className="font-semibold text-sm mb-1.5">{step.title}</div>
                  <div className="text-xs text-muted-foreground leading-relaxed">{step.desc}</div>
                  <AnimatePresence>
                    {isActive && (
                      <motion.div
                        key="bar"
                        initial={{ scaleX: 0 }}
                        animate={{ scaleX: 1 }}
                        exit={{ scaleX: 0 }}
                        style={{ background: step.color, boxShadow: `0 0 8px ${step.color}`, transformOrigin: 'left' }}
                        className="absolute bottom-0 left-0 h-0.5 w-full"
                      />
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.55 }}>
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground text-center font-mono mb-4">Analysis Modules</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {FEATURE_CARDS.map((f, i) => {
              const Icon = f.icon;
              return (
                <motion.a
                  key={f.label}
                  href={f.href}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6 + i * 0.07 }}
                  whileHover={{ y: -4, scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="group flex flex-col gap-3 p-5 rounded-xl border border-white/[0.08] bg-card/50 hover:border-white/20 transition-all"
                >
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${f.color}18` }}>
                    <Icon className="w-5 h-5" style={{ color: f.color }} />
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{f.label}</div>
                    <div className="text-xs text-muted-foreground mt-1 leading-relaxed">{f.desc}</div>
                  </div>
                  <div className="flex items-center gap-1 text-xs mt-auto" style={{ color: f.color }}>
                    Open module <ChevronRight className="w-3 h-3" />
                  </div>
                </motion.a>
              );
            })}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.75 }} className="text-center pb-4">
          <div className="inline-flex items-center gap-2 text-xs text-muted-foreground font-mono">
            <span className="w-2 h-2 rounded-full bg-[var(--signal-buy)] animate-pulse" />
            1,800+ NSE stocks &nbsp;•&nbsp; 10 AI investor personas &nbsp;•&nbsp; Claude claude-sonnet-4-6 powered analysis
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function EmptyStateWrapper() {
  const setSelectedStock = useStockStore(state => state.setSelectedStock);
  const [fetchSymbol, setFetchSymbol] = useState<string | null>(null);

  const { data: quoteData } = useGetStockQuote(fetchSymbol ?? '', {
    query: { enabled: !!fetchSymbol }
  });

  useEffect(() => {
    if (quoteData && fetchSymbol) {
      setSelectedStock(quoteData);
      setFetchSymbol(null);
    }
  }, [quoteData, fetchSymbol, setSelectedStock]);

  return <EmptyState onSelectStock={setFetchSymbol} />;
}

export default function Dashboard() {
  const selectedSymbol = useStockStore(state => state.selectedSymbol);
  const activeStrategy = useStrategyStore(state => state.activeStrategy);

  const { data: dashboardData, isLoading } = useGetDashboard(
    selectedSymbol ?? '',
    { strategy: activeStrategy ?? undefined },
    {
      query: {
        enabled: !!selectedSymbol,
        queryKey: getGetDashboardQueryKey(selectedSymbol ?? '', { strategy: activeStrategy ?? undefined })
      }
    }
  );

  const verdictMutation = useGetFinalVerdict();

  if (!selectedSymbol) return <EmptyStateWrapper />;

  if (isLoading) {
    return (
      <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
        <Skeleton className="h-28 w-full bg-secondary" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map(i => <Skeleton key={i} className="h-40 w-full bg-secondary" />)}
        </div>
        <Skeleton className="h-[400px] w-full bg-secondary" />
      </div>
    );
  }

  if (!dashboardData) return <div className="p-8 text-center text-destructive">Error loading dashboard data.</div>;

  const { quote, benchmarkComparison } = dashboardData;

  const getSignalColor = (signal: string) => {
    if (signal.includes('BUY')) return 'text-[var(--signal-buy)]';
    if (signal.includes('SELL')) return 'text-[var(--signal-sell)]';
    return 'text-[var(--signal-neutral)]';
  };

  const getSignalBg = (signal: string) => {
    if (signal.includes('BUY')) return 'bg-[var(--signal-buy)]/10 border-[var(--signal-buy)]/30';
    if (signal.includes('SELL')) return 'bg-[var(--signal-sell)]/10 border-[var(--signal-sell)]/30';
    return 'bg-[var(--signal-neutral)]/10 border-[var(--signal-neutral)]/30';
  };

  const scoreColors = ['var(--signal-buy)', '#a78bfa', '#f59e0b', '#e2e8f0'];
  const scores = [
    { label: 'Technical Score', score: dashboardData.technicalScore, signal: dashboardData.technicalSignal, color: scoreColors[0] },
    { label: 'Fundamental Score', score: dashboardData.fundamentalScore, signal: dashboardData.fundamentalSignal, color: scoreColors[1] },
    { label: 'Sentiment Score', score: dashboardData.sentimentScore, signal: dashboardData.sentimentSignal, color: scoreColors[2] },
    { label: 'Overall Score', score: dashboardData.overallScore, signal: dashboardData.technicalSignal, color: scoreColors[3] },
  ];

  const benchmarkData = [
    { name: 'Stock 1Y', value: benchmarkComparison.stock1Y ?? 0 },
    { name: 'Nifty 50', value: benchmarkComparison.nifty501Y ?? 0 },
    { name: 'Nifty 500', value: benchmarkComparison.nifty5001Y ?? 0 },
    { name: 'Sector', value: benchmarkComparison.sectorIndex1Y ?? 0 },
  ];

  return (
    <motion.div
      className="p-6 max-w-7xl mx-auto w-full space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      key={selectedSymbol}
    >
      <motion.div variants={itemVariants} className="relative overflow-hidden rounded-xl border border-primary/20 bg-card/60 p-6">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent pointer-events-none" />
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
        <div className="relative flex flex-wrap justify-between items-center gap-4">
          <div>
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-3xl font-bold font-[family-name:var(--app-font-display)]">{quote.symbol}</h1>
              <span className="text-base text-muted-foreground">{quote.name}</span>
              <span className={`px-2 py-0.5 text-xs font-mono rounded border ${getSignalBg(dashboardData.technicalSignal)} ${getSignalColor(dashboardData.technicalSignal)}`}>
                {dashboardData.technicalSignal}
              </span>
            </div>
            <div className="flex flex-wrap gap-3 mt-2 font-mono text-xs text-muted-foreground">
              <span>{quote.sector}</span>
              <span className="opacity-30">|</span>
              <span>Mkt Cap: <span className="text-foreground">{formatCompactNumber(quote.marketCap ?? 0)}</span></span>
              <span className="opacity-30">|</span>
              <span>P/E: <span className="text-foreground">{quote.pe?.toFixed(2) ?? '—'}</span></span>
              <span className="opacity-30">|</span>
              <span>52W H: <span className="text-[var(--signal-buy)]">{formatCurrency(quote.high52w ?? 0)}</span></span>
              <span>52W L: <span className="text-[var(--signal-sell)]">{formatCurrency(quote.low52w ?? 0)}</span></span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold font-mono tracking-tight">{formatCurrency(quote.price)}</div>
            <div className={`font-mono font-semibold text-lg ${quote.change >= 0 ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}`}>
              {quote.change > 0 ? '+' : ''}{quote.change.toFixed(2)} ({formatPercent(quote.changePercent)})
            </div>
            <div className="text-xs text-muted-foreground font-mono mt-1">
              Vol: {formatCompactNumber(quote.volume ?? 0)} &nbsp;|&nbsp; O: {formatCurrency(quote.open)} H: {formatCurrency(quote.high)} L: {formatCurrency(quote.low)}
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div variants={itemVariants} className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {scores.map((item, i) => (
          <Card key={i} className="bg-card border-primary/10 overflow-hidden relative">
            <div className="absolute top-0 left-0 w-full h-px" style={{ background: `linear-gradient(90deg, transparent, ${item.color}60, transparent)` }} />
            <CardContent className="p-5 flex flex-col items-center justify-center text-center gap-3">
              <div className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase">{item.label}</div>
              <ScoreRing score={item.score} color={item.color} size={80} />
              <div className={`px-3 py-1 rounded text-xs font-bold border ${getSignalBg(item.signal)} ${getSignalColor(item.signal)}`}>
                {item.signal}
              </div>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div variants={itemVariants} className="lg:col-span-2">
          <Card className="bg-card border-primary/20 overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent" />
            <CardHeader className="bg-secondary/20 pb-4 border-b border-primary/10">
              <CardTitle className="flex justify-between items-center font-[family-name:var(--app-font-display)]">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-primary" />
                  Final AI Verdict
                </div>
                <div className="flex items-center gap-2">
                  {verdictMutation.data && (
                    <motion.button
                      whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                      onClick={() => downloadVerdict(verdictMutation.data as VerdictData, selectedSymbol)}
                      className="px-3 py-2 bg-secondary text-foreground rounded-lg text-xs font-medium hover:bg-secondary/80 flex items-center gap-1.5 border border-primary/20 transition-all"
                      title="Download as HTML report"
                    >
                      <Download className="w-3 h-3" /> Download Report
                    </motion.button>
                  )}
                  <motion.button
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => verdictMutation.mutate({ symbol: selectedSymbol, data: { strategy: activeStrategy ?? undefined } })}
                    disabled={verdictMutation.isPending}
                    className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 flex items-center gap-2 transition-all"
                    data-testid="button-generate-verdict"
                  >
                    {verdictMutation.isPending
                      ? <><Loader2 className="w-4 h-4 animate-spin" /> Analysing...</>
                      : <><Sparkles className="w-4 h-4" /> Generate AI Verdict</>}
                  </motion.button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 min-h-[280px] flex flex-col justify-center">
              <AnimatePresence mode="wait">
                {verdictMutation.isPending ? (
                  <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center py-10 gap-4">
                    <div className="relative w-14 h-14">
                      <div className="absolute inset-0 rounded-full border-2 border-primary/20" />
                      <div className="absolute inset-0 rounded-full border-t-2 border-primary animate-spin" />
                      <div className="absolute inset-2 flex items-center justify-center">
                        <Brain className="w-5 h-5 text-primary" />
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground font-mono animate-pulse">Claude is synthesising all indicators...</div>
                  </motion.div>
                ) : verdictMutation.data ? (
                  <motion.div key="verdict" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
                    <div>
                      <div className={`text-3xl font-bold font-[family-name:var(--app-font-display)] ${getSignalColor(verdictMutation.data.recommendation)}`}>
                        {verdictMutation.data.recommendation.replace(/_/g, ' ')}
                      </div>
                      <div className="text-muted-foreground text-xs font-mono mt-1">
                        Confidence: <span className="text-foreground font-medium">{verdictMutation.data.confidence}%</span>
                        &nbsp;•&nbsp; Horizon: <span className="text-foreground font-medium">{verdictMutation.data.investmentHorizon}</span>
                      </div>
                    </div>
                    <div className="p-4 bg-secondary/40 rounded-lg border border-primary/10 text-sm leading-relaxed">
                      {verdictMutation.data.executiveSummary}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <div className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                          <TrendingUp className="w-3 h-3 text-[var(--signal-buy)]" /> Bull Case
                        </div>
                        <ul className="text-xs space-y-1.5">
                          {verdictMutation.data.bullCase.map((item, i) => (
                            <li key={i} className="flex items-start gap-1.5 text-foreground/80">
                              <span className="text-[var(--signal-buy)] mt-0.5 shrink-0">▲</span> {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="space-y-2">
                        <div className="text-[10px] font-bold text-muted-foreground uppercase flex items-center gap-1">
                          <TrendingDown className="w-3 h-3 text-[var(--signal-sell)]" /> Bear Case
                        </div>
                        <ul className="text-xs space-y-1.5">
                          {verdictMutation.data.bearCase.map((item, i) => (
                            <li key={i} className="flex items-start gap-1.5 text-foreground/80">
                              <span className="text-[var(--signal-sell)] mt-0.5 shrink-0">▼</span> {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4 border-t border-primary/10">
                      {[
                        { label: 'Entry Zone', value: `${formatCurrency(verdictMutation.data.entryZoneLow)} – ${formatCurrency(verdictMutation.data.entryZoneHigh)}`, sub: 'Accumulation range', cls: 'text-foreground', icon: null },
                        { label: 'Stop Loss', value: formatCurrency(verdictMutation.data.stopLoss), sub: `${verdictMutation.data.stopLossPercent ?? '—'}% risk`, cls: 'text-[var(--signal-sell)]', icon: ShieldAlert },
                        { label: 'Target 1', value: formatCurrency(verdictMutation.data.target1), sub: `+${verdictMutation.data.target1Percent ?? '—'}% upside`, cls: 'text-[var(--signal-buy)]', icon: Target },
                        { label: 'Target 2', value: formatCurrency(verdictMutation.data.target2), sub: `+${verdictMutation.data.target2Percent ?? '—'}% upside`, cls: 'text-[var(--signal-buy)]', icon: Target },
                      ].map((t, i) => (
                        <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }} className="p-3 bg-secondary/60 rounded-lg border border-primary/5">
                          <div className="text-[10px] uppercase text-muted-foreground mb-1.5 flex items-center gap-1">
                            {t.icon && <t.icon className="w-3 h-3" />} {t.label}
                          </div>
                          <div className={`font-mono font-semibold text-sm ${t.cls}`}>{t.value}</div>
                          <div className="text-[10px] text-muted-foreground mt-0.5">{t.sub}</div>
                        </motion.div>
                      ))}
                    </div>
                    {verdictMutation.data.catalysts && verdictMutation.data.catalysts.length > 0 && (
                      <div className="pt-4 border-t border-primary/10">
                        <div className="text-[10px] uppercase font-bold text-muted-foreground mb-2">Catalysts to Watch</div>
                        <ul className="space-y-1.5">
                          {verdictMutation.data.catalysts.slice(0, 3).map((c, i) => (
                            <li key={i} className="flex items-start gap-1.5 text-xs text-foreground/75">
                              <span className="text-yellow-500 mt-0.5 shrink-0">◆</span> {c}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </motion.div>
                ) : (
                  <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center text-muted-foreground py-10 gap-3">
                    <div className="w-14 h-14 rounded-full bg-primary/5 border border-primary/10 flex items-center justify-center">
                      <Sparkles className="w-6 h-6 opacity-30" />
                    </div>
                    <div className="text-sm text-center">Click <span className="text-primary font-medium">"Generate AI Verdict"</span> to synthesise all data points into a complete trade setup.</div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="bg-card border-primary/20 h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-[family-name:var(--app-font-display)] flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-primary" /> 1Y Return vs Benchmark
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[280px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={benchmarkData} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                    <XAxis dataKey="name" stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis stroke="rgba(255,255,255,0.3)" fontSize={11} tickLine={false} axisLine={false} tickFormatter={v => `${v}%`} />
                    <RechartsTooltip
                      cursor={{ fill: 'rgba(255,255,255,0.04)' }}
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'rgba(255,255,255,0.1)', color: 'hsl(var(--foreground))', borderRadius: '8px' }}
                      formatter={(v: number) => [`${v.toFixed(1)}%`, 'Return']}
                    />
                    <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                      {benchmarkData.map((entry, index) => (
                        <Cell key={index} fill={entry.value >= 0 ? 'var(--signal-buy)' : 'var(--signal-sell)'} opacity={index === 0 ? 1 : 0.55} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}

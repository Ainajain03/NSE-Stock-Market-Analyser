import React, { useState } from 'react';
import { useStockStore } from '@/store/stockStore';
import { useStrategyStore } from '@/store/strategyStore';
import { 
  useGetFundamentalAnalysis,
  getGetFundamentalAnalysisQueryKey,
  useGetFundamentalAiAnalysis
} from '@workspace/api-client-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';
import { Loader2, BrainCircuit, ExternalLink, Search } from 'lucide-react';
import { formatCurrency, formatCompactNumber, formatPercent } from '@/lib/format';

export default function Fundamental() {
  const selectedSymbol = useStockStore(state => state.selectedSymbol);
  const activeStrategy = useStrategyStore(state => state.activeStrategy);

  const { data: fundData, isLoading } = useGetFundamentalAnalysis(
    selectedSymbol || '',
    { query: { enabled: !!selectedSymbol, queryKey: getGetFundamentalAnalysisQueryKey(selectedSymbol || '') } }
  );

  const aiSummaryMutation = useGetFundamentalAiAnalysis();

  if (!selectedSymbol) {
    return <div className="p-8 text-center text-muted-foreground mt-20">Please select a stock from the command center to view fundamental analysis.</div>;
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="p-6 max-w-[1400px] mx-auto w-full space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-[family-name:var(--app-font-display)] text-primary glow-text-sm">Fundamental Analysis</h1>
          <p className="text-muted-foreground font-mono mt-1">{selectedSymbol}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <a
            href={`https://www.screener.in/company/${selectedSymbol}/consolidated/`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-md border border-green-500/30 bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors"
            title="Deep fundamental analysis on Screener.in"
          >
            <Search className="w-3 h-3" /> Screener.in
          </a>
          <a
            href={`https://trendlyne.com/equity/overview/${selectedSymbol}/`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-md border border-purple-500/30 bg-purple-500/10 text-purple-400 hover:bg-purple-500/20 transition-colors"
            title="Research on Trendlyne"
          >
            <ExternalLink className="w-3 h-3" /> Trendlyne
          </a>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-6">
          <Skeleton className="h-12 w-full max-w-md bg-secondary" />
          <Skeleton className="h-64 w-full bg-secondary" />
          <div className="grid grid-cols-3 gap-6">
            <Skeleton className="h-32 w-full bg-secondary" />
            <Skeleton className="h-32 w-full bg-secondary" />
            <Skeleton className="h-32 w-full bg-secondary" />
          </div>
        </div>
      ) : fundData ? (
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="bg-secondary/50 border border-primary/20 w-full justify-start overflow-x-auto">
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-mono text-xs">OVERVIEW</TabsTrigger>
            <TabsTrigger value="financials" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-mono text-xs">FINANCIALS</TabsTrigger>
            <TabsTrigger value="quarterly" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-mono text-xs">QUARTERLY</TabsTrigger>
            <TabsTrigger value="valuation" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-mono text-xs">VALUATION</TabsTrigger>
            <TabsTrigger value="peers" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-mono text-xs">PEERS</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6 space-y-6 outline-none">
            <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
                <Card className="bg-card border-primary/20">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">Business Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-sm leading-relaxed text-foreground/90">{fundData.businessSummary}</p>
                  </CardContent>
                </Card>

                <Card className="bg-card border-primary/20">
                  <CardHeader className="bg-secondary/30 pb-4 flex flex-row items-center justify-between">
                    <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">AI Qualitative Analysis</CardTitle>
                    <button
                      onClick={() => aiSummaryMutation.mutate({ symbol: selectedSymbol, data: { strategy: activeStrategy || undefined } })}
                      disabled={aiSummaryMutation.isPending}
                      className="px-3 py-1.5 bg-primary/20 text-primary hover:bg-primary hover:text-primary-foreground rounded text-xs font-medium border border-primary/30 flex items-center gap-2 transition-all active:scale-95"
                    >
                      {aiSummaryMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <BrainCircuit className="w-3 h-3" />}
                      Generate Analysis
                    </button>
                  </CardHeader>
                  <CardContent className="p-6">
                    <AnimatePresence mode="wait">
                      {aiSummaryMutation.data ? (
                        <motion.div
                          key="summary"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-sm leading-relaxed whitespace-pre-wrap"
                        >
                          {aiSummaryMutation.data.summary}
                        </motion.div>
                      ) : (
                        <motion.div key="empty" className="text-muted-foreground text-sm py-4 text-center">
                          Generate AI qualitative analysis based on the fundamental data and active strategy.
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants} className="space-y-6">
                <Card className="bg-card border-primary/20">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="text-sm font-[family-name:var(--app-font-display)] text-center">Fundamental Score</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 flex flex-col items-center">
                    <div className="text-5xl font-bold font-[family-name:var(--app-font-display)] text-primary glow-text-sm mb-4">
                      {fundData.overallScore}
                    </div>
                    <div className={`px-4 py-1.5 rounded-full text-sm font-bold border ${fundData.fundamentalSignal === 'EXCELLENT' || fundData.fundamentalSignal === 'GOOD' ? 'bg-[var(--signal-buy)]/10 text-[var(--signal-buy)] border-[var(--signal-buy)]/30' : fundData.fundamentalSignal === 'AVERAGE' ? 'bg-[var(--signal-neutral)]/10 text-[var(--signal-neutral)] border-[var(--signal-neutral)]/30' : 'bg-[var(--signal-sell)]/10 text-[var(--signal-sell)] border-[var(--signal-sell)]/30'}`}>
                      {fundData.fundamentalSignal}
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-card border-primary/20">
                  <CardHeader className="bg-secondary/30 pb-4">
                    <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">Key Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="divide-y divide-primary/10">
                      {[
                        { label: 'P/E Ratio', value: fundData.valuation.peRatio?.toFixed(2) },
                        { label: 'P/B Ratio', value: fundData.valuation.pbRatio?.toFixed(2) },
                        { label: 'Sector P/E', value: fundData.valuation.sectorPE?.toFixed(2) },
                        { label: 'Div Yield', value: fundData.valuation.dividendYield ? formatPercent(fundData.valuation.dividendYield) : '-' },
                        { label: 'Promoter Holding', value: fundData.valuation.promoterHolding ? formatPercent(fundData.valuation.promoterHolding) : '-' },
                        { label: 'FII Holding', value: fundData.valuation.fiiHolding ? formatPercent(fundData.valuation.fiiHolding) : '-' },
                        { label: '3Y CAGR', value: fundData.cagr3Y ? formatPercent(fundData.cagr3Y) : '-' },
                      ].map((item, i) => (
                        <div key={i} className="flex justify-between items-center p-3 hover:bg-secondary/20">
                          <span className="text-xs text-muted-foreground">{item.label}</span>
                          <span className="font-mono text-sm font-medium">{item.value || '-'}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

            </motion.div>
          </TabsContent>

          <TabsContent value="financials" className="mt-6 outline-none">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-card border-primary/20">
                  <CardHeader>
                    <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">Revenue & PAT (5 Years)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={fundData.financials.slice().reverse()} margin={{ top: 20, right: 0, left: 0, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="var(--border-primary)" vertical={false} />
                          <XAxis dataKey="year" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                          <YAxis yAxisId="left" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => formatCompactNumber(val)} />
                          <RechartsTooltip 
                            cursor={{ fill: 'var(--bg-secondary)', opacity: 0.5 }}
                            contentStyle={{ backgroundColor: 'var(--bg-card)', borderColor: 'var(--border-accent)', color: 'var(--text-primary)' }}
                            formatter={(val: number) => formatCompactNumber(val)}
                          />
                          <Bar yAxisId="left" dataKey="revenue" name="Revenue" fill="var(--primary)" radius={[4, 4, 0, 0]} opacity={0.8} />
                          <Bar yAxisId="left" dataKey="pat" name="PAT" fill="var(--signal-buy)" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
             </div>
          </TabsContent>

          <TabsContent value="quarterly" className="mt-6 outline-none">
            <Card className="bg-card border-primary/20">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs text-muted-foreground uppercase bg-secondary/50 border-b border-primary/20">
                      <tr>
                        <th className="px-6 py-3 font-medium">Quarter</th>
                        <th className="px-6 py-3 font-medium">Revenue</th>
                        <th className="px-6 py-3 font-medium">YoY Growth</th>
                        <th className="px-6 py-3 font-medium">PAT</th>
                        <th className="px-6 py-3 font-medium">Result</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-primary/10">
                      {fundData.quarterlyResults.map((q) => (
                        <tr key={q.quarter} className="hover:bg-secondary/20">
                          <td className="px-6 py-4 font-mono">{q.quarter}</td>
                          <td className="px-6 py-4 font-mono">{formatCompactNumber(q.revenue || 0)}</td>
                          <td className="px-6 py-4 font-mono">
                            <span className={q.revenueGrowthYoY && q.revenueGrowthYoY > 0 ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}>
                              {formatPercent(q.revenueGrowthYoY || 0)}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-mono">{formatCompactNumber(q.pat || 0)}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-1 rounded text-[10px] font-bold ${q.beat === 'BEAT' ? 'bg-[var(--signal-buy)]/10 text-[var(--signal-buy)]' : q.beat === 'MISS' ? 'bg-[var(--signal-sell)]/10 text-[var(--signal-sell)]' : 'bg-[var(--signal-neutral)]/10 text-[var(--signal-neutral)]'}`}>
                              {q.beat || 'IN LINE'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="valuation" className="mt-6 outline-none">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-card border-primary/20">
                <CardHeader>
                  <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">Intrinsic Value (DCF)</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <div className="text-4xl font-mono font-bold text-primary mb-2">
                    {formatCurrency(fundData.valuation.dcfIntrinsicValue || 0)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Margin of Safety: <span className={fundData.valuation.marginOfSafety && fundData.valuation.marginOfSafety > 0 ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}>{formatPercent(fundData.valuation.marginOfSafety || 0)}</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-primary/20">
                <CardHeader>
                  <CardTitle className="text-sm font-[family-name:var(--app-font-display)]">Graham Number</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <div className="text-4xl font-mono font-bold text-primary mb-2">
                    {formatCurrency(fundData.valuation.grahamNumber || 0)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Defensive Valuation Metric
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="peers" className="mt-6 outline-none">
             <Card className="bg-card border-primary/20">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs text-muted-foreground uppercase bg-secondary/50 border-b border-primary/20">
                      <tr>
                        <th className="px-6 py-3 font-medium">Company</th>
                        <th className="px-6 py-3 font-medium text-right">Mkt Cap</th>
                        <th className="px-6 py-3 font-medium text-right">P/E</th>
                        <th className="px-6 py-3 font-medium text-right">ROE</th>
                        <th className="px-6 py-3 font-medium text-right">1Y Ret</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-primary/10">
                      {fundData.peers.map((p) => (
                        <tr key={p.symbol} className={p.symbol === selectedSymbol ? 'bg-primary/5' : 'hover:bg-secondary/20'}>
                          <td className="px-6 py-4">
                            <div className="font-bold text-primary font-mono">{p.symbol}</div>
                            <div className="text-xs text-muted-foreground truncate w-40">{p.name}</div>
                          </td>
                          <td className="px-6 py-4 font-mono text-right">{formatCompactNumber(p.marketCap || 0)}</td>
                          <td className="px-6 py-4 font-mono text-right">{p.pe?.toFixed(2) || '-'}</td>
                          <td className="px-6 py-4 font-mono text-right">{p.roe ? `${p.roe.toFixed(2)}%` : '-'}</td>
                          <td className="px-6 py-4 font-mono text-right">
                            <span className={p.return1Y && p.return1Y > 0 ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}>
                              {formatPercent(p.return1Y || 0)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      ) : null}
    </div>
  );
}

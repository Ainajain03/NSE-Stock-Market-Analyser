import React, { useState, useRef, useEffect } from 'react';
import { useParams } from 'wouter';
import { useGetExpert, useChatWithExpert } from '@workspace/api-client-react';
import { getGetExpertQueryKey } from '@workspace/api-client-react';
import type { ExpertChatMessage } from '@workspace/api-client-react';
import { useStockStore } from '@/store/stockStore';
import { motion } from 'framer-motion';
import { Send, Loader2, ChevronLeft, MessageSquare } from 'lucide-react';
import { Link } from 'wouter';

export default function ExpertChat() {
  const { id } = useParams<{ id: string }>();
  const [message, setMessage] = useState('');
  const [history, setHistory] = useState<ExpertChatMessage[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const selectedStock = useStockStore(state => state.selectedStock);

  const { data: expert, isLoading: expertLoading } = useGetExpert(id || '', {
    query: { enabled: !!id, queryKey: getGetExpertQueryKey(id || '') }
  });

  const chatMutation = useChatWithExpert();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, chatMutation.isPending]);

  const handleSend = () => {
    if (!message.trim() || chatMutation.isPending || !expert) return;

    const userMessage: ExpertChatMessage = { role: 'user', content: message };
    setHistory(prev => [...prev, userMessage]);
    setMessage('');

    const contextStock = selectedStock ? {
      symbol: selectedStock.symbol,
      price: selectedStock.price,
      pe: selectedStock.pe,
      marketCap: selectedStock.marketCap,
      sector: selectedStock.sector,
      technicalSignal: 'NEUTRAL',
      fundamentalSignal: 'AVERAGE'
    } : undefined;

    chatMutation.mutate({
      expertId: expert.id,
      data: {
        message: message,
        conversationHistory: history,
        stockContext: contextStock
      }
    }, {
      onSuccess: (data) => {
        setHistory(prev => [...prev, { role: 'assistant', content: data.reply }]);
      }
    });
  };

  if (expertLoading) {
    return <div className="flex-1 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  if (!expert) {
    return <div className="p-8 text-center text-destructive">Expert not found</div>;
  }

  // Derive font family based on expert personality
  const getExpertFont = () => {
    if (expert.id === 'jhunjhunwala') return 'var(--app-font-display)';
    if (expert.id === 'buffett') return 'var(--app-font-serif)';
    if (expert.id === 'livermore') return 'var(--app-font-mono)';
    return 'var(--app-font-sans)';
  };

  return (
    <div className="flex-1 flex h-[calc(100vh-4rem)] overflow-hidden">
      
      {/* Left Sidebar - Profile */}
      <div className="w-1/3 hidden md:flex flex-col border-r border-primary/20 bg-secondary/30 p-6 overflow-y-auto">
        <Link href="/experts" className="flex items-center text-sm text-muted-foreground hover:text-foreground mb-8">
          <ChevronLeft className="w-4 h-4 mr-1" /> Back to Experts
        </Link>
        
        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold font-[family-name:var(--app-font-display)]" style={{ color: expert.signatureColor }}>
              {expert.name}
            </h1>
            <div className="text-sm font-mono text-muted-foreground mt-2">{expert.era}</div>
          </div>

          <div className="p-4 rounded-lg bg-card border border-primary/10 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full" style={{ backgroundColor: expert.signatureColor }} />
            <div className="text-sm italic text-foreground/90">"{expert.philosophy}"</div>
          </div>

          <div>
            <h3 className="text-xs uppercase font-bold text-muted-foreground tracking-widest mb-3">Key Principles</h3>
            <ul className="space-y-3 text-sm">
              {expert.keyPrinciples.map((principle, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: expert.signatureColor }} />
                  <span className="text-foreground/80 leading-relaxed">{principle}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="mt-auto pt-6 border-t border-primary/10">
             <div className="text-xs uppercase font-bold text-muted-foreground tracking-widest mb-3">Active Context</div>
             {selectedStock ? (
               <div className="p-3 bg-card border border-primary/20 rounded flex items-center justify-between">
                 <span className="font-mono font-bold text-primary">{selectedStock.symbol}</span>
                 <span className="text-xs text-muted-foreground">₹{selectedStock.price.toFixed(2)}</span>
               </div>
             ) : (
               <div className="p-3 border border-dashed border-primary/20 rounded text-xs text-muted-foreground text-center">
                 No stock selected in Command Center. Search for a stock to provide context.
               </div>
             )}
          </div>
        </div>
      </div>

      {/* Right - Chat */}
      <div className="flex-1 flex flex-col bg-background relative">
        {/* Mobile header */}
        <div className="md:hidden flex items-center p-4 border-b border-primary/20 bg-secondary/50">
          <Link href="/experts" className="mr-4">
            <ChevronLeft className="w-5 h-5 text-muted-foreground" />
          </Link>
          <div className="font-bold" style={{ color: expert.signatureColor }}>{expert.name}</div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6" ref={scrollRef}>
          {history.length === 0 && (
             <div className="h-full flex flex-col items-center justify-center opacity-50">
               <MessageSquare className="w-12 h-12 mb-4" style={{ color: expert.signatureColor }} />
               <p className="text-lg font-[family-name:var(--app-font-display)]">Begin consultation with {expert.name.split(' ')[0]}</p>
             </div>
          )}
          
          {history.map((msg, i) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={i} 
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[85%] md:max-w-[75%] rounded-lg p-4 text-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-secondary text-foreground border border-primary/10' 
                    : 'bg-card text-foreground border shadow-lg'
                }`}
                style={msg.role === 'assistant' ? { 
                  borderColor: `${expert.signatureColor}40`,
                  fontFamily: getExpertFont(),
                  fontSize: expert.id === 'buffett' ? '15px' : '14px'
                } : {}}
              >
                {msg.content}
              </div>
            </motion.div>
          ))}
          
          {chatMutation.isPending && (
            <div className="flex justify-start">
              <div className="max-w-[85%] rounded-lg p-4 bg-card border text-sm flex items-center gap-3" style={{ borderColor: `${expert.signatureColor}40` }}>
                <Loader2 className="w-4 h-4 animate-spin" style={{ color: expert.signatureColor }} />
                <span className="text-muted-foreground font-mono text-xs uppercase tracking-widest">Analyzing...</span>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 md:p-6 border-t border-primary/20 bg-card/50 backdrop-blur">
          <form 
            onSubmit={(e) => { e.preventDefault(); handleSend(); }}
            className="flex items-center gap-3 max-w-4xl mx-auto"
          >
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={`Ask ${expert.name.split(' ')[0]} for advice...`}
              className="flex-1 bg-secondary/80 border border-primary/20 rounded-md px-4 py-3 text-sm focus:outline-none focus:border-primary/50 text-foreground shadow-inner"
              disabled={chatMutation.isPending}
              data-testid="input-expert-chat"
            />
            <button
              type="submit"
              disabled={!message.trim() || chatMutation.isPending}
              className="p-3 rounded-md disabled:opacity-50 transition-colors flex items-center justify-center"
              style={{ backgroundColor: expert.signatureColor, color: '#fff' }}
              data-testid="button-send-expert-chat"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>

    </div>
  );
}

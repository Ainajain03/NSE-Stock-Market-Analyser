import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import {
  Plus, Trash2, RefreshCw, TrendingUp, TrendingDown, Eye,
  Bell, Target, Loader2, X, BarChart3, Star, CheckCircle2
} from 'lucide-react';
import { Link } from 'wouter';

const BASE = import.meta.env.BASE_URL.replace(/\/$/, '');
const api  = (p: string) => `${BASE}${p}`;

interface WatchItem {
  id: number;
  symbol: string;
  name: string;
  price: number;
  change: number | null;
  changePercent: number | null;
  addedAt: string;
  targetPrice?: number;
  stopLoss?: number;
}

const fmt = (n: number) => n.toLocaleString('en-IN', { maximumFractionDigits: 2 });
const fmtCur = (n: number) => '₹' + fmt(Math.abs(n));

const TARGETS_KEY = 'stocksage_watchlist_targets_v1';

function loadTargets(): Record<number, { target?: number; stop?: number }> {
  try { return JSON.parse(localStorage.getItem(TARGETS_KEY) ?? '{}'); } catch { return {}; }
}
function saveTargets(t: Record<number, { target?: number; stop?: number }>) {
  localStorage.setItem(TARGETS_KEY, JSON.stringify(t));
}

export default function Watchlist() {
  const [items, setItems]         = useState<WatchItem[]>([]);
  const [targets, setTargets]     = useState<Record<number, { target?: number; stop?: number }>>(loadTargets);
  const [loading, setLoading]     = useState(false);
  const [addOpen, setAddOpen]     = useState(false);
  const [search, setSearch]       = useState('');
  const [results, setResults]     = useState<{ symbol: string; name: string; sector: string }[]>([]);
  const [selected, setSelected]   = useState<{ symbol: string; name: string } | null>(null);
  const [searching, setSearching] = useState(false);
  const [adding, setAdding]       = useState(false);
  const [editTarget, setEditTarget] = useState<number | null>(null);
  const [tInput, setTInput]       = useState('');
  const [sInput, setSInput]       = useState('');

  const fetchWatchlist = useCallback(async () => {
    setLoading(true);
    try {
      const res  = await fetch(api('/api/watchlist'));
      const data = await res.json();
      const t    = loadTargets();
      setItems(data.map((d: any) => ({
        ...d,
        targetPrice: t[d.id]?.target,
        stopLoss:    t[d.id]?.stop,
      })));
    } catch { /* keep old data */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchWatchlist(); }, [fetchWatchlist]);

  /* search */
  useEffect(() => {
    if (!search || search.length < 1) { setResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(api(`/api/stocks/search?q=${encodeURIComponent(search)}`));
        setResults(await r.json());
      } catch { setResults([]); }
      setSearching(false);
    }, 300);
    return () => clearTimeout(t);
  }, [search]);

  const addToWatchlist = async () => {
    if (!selected) return;
    setAdding(true);
    try {
      await fetch(api('/api/watchlist'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbol: selected.symbol, name: selected.name }),
      });
      setSelected(null); setSearch(''); setAddOpen(false);
      await fetchWatchlist();
    } catch { /* error */ }
    setAdding(false);
  };

  const removeItem = async (id: number) => {
    await fetch(api(`/api/watchlist/${id}`), { method: 'DELETE' });
    setItems(prev => prev.filter(i => i.id !== id));
    const t = { ...targets }; delete t[id]; setTargets(t); saveTargets(t);
  };

  const saveTarget = (id: number) => {
    const t = parseFloat(tInput);
    const s = parseFloat(sInput);
    const updated = {
      ...targets,
      [id]: { target: isNaN(t) ? undefined : t, stop: isNaN(s) ? undefined : s },
    };
    setTargets(updated); saveTargets(updated);
    setItems(prev => prev.map(i => i.id === id
      ? { ...i, targetPrice: isNaN(t) ? undefined : t, stopLoss: isNaN(s) ? undefined : s }
      : i));
    setEditTarget(null);
  };

  const openEdit = (item: WatchItem) => {
    setEditTarget(item.id);
    setTInput(item.targetPrice?.toString() ?? '');
    setSInput(item.stopLoss?.toString() ?? '');
  };

  /* stats */
  const gainers = items.filter(i => (i.changePercent ?? 0) > 0).length;
  const losers  = items.filter(i => (i.changePercent ?? 0) < 0).length;
  const atTarget = items.filter(i => i.targetPrice && i.price >= i.targetPrice).length;
  const atStop   = items.filter(i => i.stopLoss    && i.price <= i.stopLoss).length;

  return (
    <div className="p-4 md:p-6 max-w-[1400px] mx-auto w-full space-y-6">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold font-[family-name:var(--app-font-display)] glow-text">Watchlist</h1>
          <p className="text-muted-foreground text-sm mt-1">Monitor stocks · Set price targets · Track alerts</p>
        </div>
        <div className="flex gap-2">
          <button onClick={fetchWatchlist} disabled={loading}
            className="p-2.5 bg-secondary border border-primary/20 rounded-lg hover:bg-secondary/80 transition-colors disabled:opacity-50">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button onClick={() => setAddOpen(true)}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold flex items-center gap-2 hover:bg-primary/90 transition-colors">
            <Plus className="w-4 h-4" /> Add Stock
          </button>
        </div>
      </div>

      {/* Summary cards */}
      {items.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-secondary/50 border border-primary/10 rounded-xl p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Watching</div>
            <div className="text-2xl font-bold font-mono text-foreground">{items.length}</div>
            <div className="text-xs text-muted-foreground">{gainers} up · {losers} down</div>
          </div>
          <div className="bg-secondary/50 border border-primary/10 rounded-xl p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Top Gainer</div>
            {items.sort((a,b)=>(b.changePercent??0)-(a.changePercent??0))[0] ? (() => {
              const top = [...items].sort((a,b)=>(b.changePercent??0)-(a.changePercent??0))[0];
              return (<>
                <div className="text-xl font-bold font-mono text-green-400">+{(top.changePercent??0).toFixed(2)}%</div>
                <div className="text-xs text-muted-foreground">{top.symbol}</div>
              </>);
            })() : <div className="text-muted-foreground text-sm">—</div>}
          </div>
          <div className={`border rounded-xl p-4 ${atTarget > 0 ? 'bg-green-400/5 border-green-400/20' : 'bg-secondary/50 border-primary/10'}`}>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Target Hit</div>
            <div className={`text-2xl font-bold font-mono ${atTarget > 0 ? 'text-green-400' : 'text-foreground'}`}>{atTarget}</div>
            <div className="text-xs text-muted-foreground">stocks at target</div>
          </div>
          <div className={`border rounded-xl p-4 ${atStop > 0 ? 'bg-red-400/5 border-red-400/20' : 'bg-secondary/50 border-primary/10'}`}>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Stop-Loss Alert</div>
            <div className={`text-2xl font-bold font-mono ${atStop > 0 ? 'text-red-400' : 'text-foreground'}`}>{atStop}</div>
            <div className="text-xs text-muted-foreground">stocks at stop</div>
          </div>
        </div>
      )}

      {/* Watchlist items */}
      {items.length === 0 && !loading ? (
        <Card className="bg-card border-primary/20">
          <CardContent className="flex flex-col items-center justify-center py-20 gap-4 text-muted-foreground">
            <div className="w-16 h-16 rounded-full bg-primary/5 border border-primary/10 flex items-center justify-center">
              <Star className="w-7 h-7 opacity-30" />
            </div>
            <div className="text-center">
              <p className="font-medium text-foreground">Your watchlist is empty</p>
              <p className="text-sm mt-1">Add stocks to monitor their price, set targets, and track alerts.</p>
            </div>
            <button onClick={() => setAddOpen(true)}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-semibold flex items-center gap-2">
              <Plus className="w-4 h-4" /> Add First Stock
            </button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence>
            {items.map((item, i) => {
              const isPos    = (item.changePercent ?? 0) >= 0;
              const tHit     = item.targetPrice && item.price >= item.targetPrice;
              const sHit     = item.stopLoss    && item.price <= item.stopLoss;
              const tPct     = item.targetPrice ? ((item.targetPrice - item.price) / item.price * 100) : null;
              const sPct     = item.stopLoss    ? ((item.price - item.stopLoss)    / item.price * 100) : null;

              return (
                <motion.div key={item.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ delay: i * 0.04 }}>
                  <Card className={`bg-card overflow-hidden transition-all ${tHit ? 'border-green-400/40' : sHit ? 'border-red-400/40' : 'border-primary/20'}`}>
                    <CardContent className="p-4">
                      {/* Alert banner */}
                      {tHit && (
                        <div className="flex items-center gap-2 mb-3 px-2 py-1.5 bg-green-400/10 border border-green-400/20 rounded-lg text-green-400 text-xs font-semibold">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Target Price Reached! Consider booking profits.
                        </div>
                      )}
                      {sHit && !tHit && (
                        <div className="flex items-center gap-2 mb-3 px-2 py-1.5 bg-red-400/10 border border-red-400/20 rounded-lg text-red-400 text-xs font-semibold">
                          <Bell className="w-3.5 h-3.5" /> Stop-Loss Alert! Review your position.
                        </div>
                      )}

                      {/* Header row */}
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold font-mono text-sm text-primary">{item.symbol}</span>
                            {tHit && <span className="text-[9px] px-1.5 py-0.5 bg-green-400/10 text-green-400 rounded-full font-bold">TARGET ✓</span>}
                            {sHit && !tHit && <span className="text-[9px] px-1.5 py-0.5 bg-red-400/10 text-red-400 rounded-full font-bold">STOP HIT</span>}
                          </div>
                          <div className="text-xs text-muted-foreground truncate max-w-[180px] mt-0.5">{item.name}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold font-mono text-foreground">{fmtCur(item.price)}</div>
                          <div className={`text-xs font-mono font-semibold flex items-center justify-end gap-0.5 ${isPos ? 'text-green-400' : 'text-red-400'}`}>
                            {isPos ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                            {item.changePercent !== null ? `${isPos ? '+' : ''}${item.changePercent?.toFixed(2)}%` : '—'}
                          </div>
                        </div>
                      </div>

                      {/* Price targets */}
                      {editTarget === item.id ? (
                        <div className="space-y-2 mb-3 p-3 bg-secondary/40 rounded-lg border border-primary/10">
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[10px] text-muted-foreground block mb-1">Target (₹)</label>
                              <input type="number" value={tInput} onChange={e => setTInput(e.target.value)}
                                placeholder="e.g. 3200" className="w-full bg-secondary/60 border border-primary/20 rounded px-2 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary/50" />
                            </div>
                            <div>
                              <label className="text-[10px] text-muted-foreground block mb-1">Stop-Loss (₹)</label>
                              <input type="number" value={sInput} onChange={e => setSInput(e.target.value)}
                                placeholder="e.g. 2400" className="w-full bg-secondary/60 border border-primary/20 rounded px-2 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary/50" />
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <button onClick={() => saveTarget(item.id)}
                              className="flex-1 py-1.5 bg-primary text-primary-foreground rounded text-xs font-bold">Save</button>
                            <button onClick={() => setEditTarget(null)}
                              className="px-3 py-1.5 bg-secondary rounded text-xs text-muted-foreground">Cancel</button>
                          </div>
                        </div>
                      ) : (item.targetPrice || item.stopLoss) && (
                        <div className="grid grid-cols-2 gap-2 mb-3">
                          {item.targetPrice && (
                            <div className="px-2 py-1.5 bg-green-400/5 border border-green-400/15 rounded-lg text-[10px]">
                              <div className="text-muted-foreground">Target</div>
                              <div className="font-mono font-bold text-green-400">{fmtCur(item.targetPrice)}</div>
                              {tPct !== null && <div className={`text-[9px] ${tPct >= 0 ? 'text-green-400/70' : 'text-red-400/70'}`}>
                                {tPct >= 0 ? `+${tPct.toFixed(1)}% away` : `${tPct.toFixed(1)}% (exceeded)`}
                              </div>}
                            </div>
                          )}
                          {item.stopLoss && (
                            <div className="px-2 py-1.5 bg-red-400/5 border border-red-400/15 rounded-lg text-[10px]">
                              <div className="text-muted-foreground">Stop-Loss</div>
                              <div className="font-mono font-bold text-red-400">{fmtCur(item.stopLoss)}</div>
                              {sPct !== null && <div className={`text-[9px] ${sPct >= 0 ? 'text-muted-foreground' : 'text-red-400'}`}>
                                {sPct >= 0 ? `${sPct.toFixed(1)}% buffer` : 'BREACHED'}
                              </div>}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Action buttons */}
                      <div className="flex gap-2">
                        <Link href={`/technical?symbol=${item.symbol}`}
                          className="flex-1 py-1.5 bg-secondary/60 hover:bg-secondary/80 border border-primary/10 rounded-lg text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 transition-colors">
                          <BarChart3 className="w-3 h-3" /> Analyse
                        </Link>
                        <button onClick={() => openEdit(item)}
                          className="flex-1 py-1.5 bg-secondary/60 hover:bg-secondary/80 border border-primary/10 rounded-lg text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 transition-colors">
                          <Target className="w-3 h-3" /> Set Target
                        </button>
                        <button onClick={() => removeItem(item.id)}
                          className="p-2 hover:bg-red-400/10 border border-primary/10 hover:border-red-400/20 rounded-lg transition-colors text-muted-foreground hover:text-red-400">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[9px] text-muted-foreground/50 mt-2">
                        Added {new Date(item.addedAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Add modal */}
      <AnimatePresence>
        {addOpen && (
          <motion.div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={e => e.target === e.currentTarget && setAddOpen(false)}>
            <motion.div initial={{ scale: 0.92, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.92, opacity: 0 }}
              className="bg-card border border-primary/20 rounded-2xl p-6 w-full max-w-md shadow-2xl">
              <div className="flex justify-between items-center mb-5">
                <h3 className="font-bold font-[family-name:var(--app-font-display)]">Add to Watchlist</h3>
                <button onClick={() => setAddOpen(false)} className="p-1.5 hover:bg-secondary rounded-lg"><X className="w-4 h-4" /></button>
              </div>
              <div className="relative mb-4">
                <input value={search} onChange={e => { setSearch(e.target.value); setSelected(null); }}
                  placeholder="Search NSE stock by name or symbol…"
                  className="w-full bg-secondary/60 border border-primary/20 rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50" />
                {searching && <Loader2 className="absolute right-3 top-3 w-4 h-4 animate-spin text-muted-foreground" />}
                {results.length > 0 && !selected && (
                  <div className="absolute z-10 w-full mt-1 bg-card border border-primary/20 rounded-lg shadow-xl max-h-52 overflow-y-auto">
                    {results.map(r => (
                      <button key={r.symbol} onClick={() => { setSelected(r); setSearch(r.name); setResults([]); }}
                        className="w-full px-3 py-2.5 text-left hover:bg-secondary/60 transition-colors border-b border-primary/5 last:border-0">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-xs font-mono text-primary">{r.symbol}</span>
                            <span className="text-xs text-muted-foreground ml-2">{r.name}</span>
                          </div>
                          <span className="text-[10px] text-muted-foreground bg-secondary px-1.5 py-0.5 rounded">{r.sector}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {selected && (
                <div className="flex items-center gap-2 mb-5 p-2 bg-primary/5 border border-primary/10 rounded-lg">
                  <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
                  <span className="text-xs font-bold font-mono">{selected.symbol}</span>
                  <span className="text-xs text-muted-foreground">{selected.name}</span>
                </div>
              )}
              <button onClick={addToWatchlist} disabled={!selected || adding}
                className="w-full py-2.5 bg-primary text-primary-foreground rounded-lg font-semibold text-sm disabled:opacity-50 hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                {adding ? <Loader2 className="w-4 h-4 animate-spin" /> : <Star className="w-4 h-4" />}
                {adding ? 'Adding…' : 'Add to Watchlist'}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`.glow-text { text-shadow: 0 0 20px var(--color-primary); }`}</style>
    </div>
  );
}

import React, { useState } from 'react';
import { useListExperts } from '@workspace/api-client-react';
import { getListExpertsQueryKey } from '@workspace/api-client-react';
import { useStrategyStore } from '@/store/strategyStore';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { UserCheck, MessageSquare } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

/* ── Real Wikipedia portrait URLs (confirmed via Wikipedia API) ───── */
const EXPERT_PORTRAITS: Record<string, string | null> = {
  buffett:      'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Warren_Buffett_at_the_2015_SelectUSA_Investment_Summit_%28cropped%29.jpg/500px-Warren_Buffett_at_the_2015_SelectUSA_Investment_Summit_%28cropped%29.jpg',
  munger:       'https://upload.wikimedia.org/wikipedia/commons/5/56/Charlie_Munger_%28cropped%29.jpg',
  graham:       'https://upload.wikimedia.org/wikipedia/commons/2/2a/Benjamin_Graham_%281894-1976%29_portrait_on_23_March_1950.jpg',
  lynch:        null,
  soros:        'https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/George_Soros%2C_Founder_and_Chairman_of_the_Open_Society_Foundations%2C_visits_the_EC_%283x4_cropped%29.jpg/500px-George_Soros%2C_Founder_and_Chairman_of_the_Open_Society_Foundations%2C_visits_the_EC_%283x4_cropped%29.jpg',
  livermore:    'https://upload.wikimedia.org/wikipedia/commons/0/0a/Press_photo_of_Jesse_Livermore_in_1940_%28cropped%29.jpg',
  jhunjhunwala: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Shri_Rakesh_Radheyshyam_Jhunjhunwala.jpg/500px-Shri_Rakesh_Radheyshyam_Jhunjhunwala.jpg',
  damani:       null,
  kedia:        null,
  minervini:    null,
};

/* DiceBear illustrated avatars for those without real photos */
const dicebear = (seed: string, color: string) =>
  `https://api.dicebear.com/9.x/notionists/svg?seed=${seed}&backgroundColor=${color.replace('#','')}&radius=0`;

const EXPERT_AVATARS: Record<string, string> = {
  lynch:     dicebear('PeterLynch',     '1a3a2a'),
  damani:    dicebear('RadhakishanD',   '1a1a35'),
  kedia:     dicebear('VijayKedia',     '2a1025'),
  minervini: dicebear('MarkMinervini', '1e1035'),
};

/* ── Expert description lines ─────────────────────────────────────── */
const EXPERT_SUBTITLES: Record<string, string> = {
  jhunjhunwala: 'The Big Bull of Dalal Street',
  damani:       'The Quiet Giant & Founder of DMart',
  kedia:        'Multibagger Hunter — SMILE Framework',
  buffett:      'The Oracle of Omaha — Value Legend',
  graham:       'Father of Value Investing',
  lynch:        'Magellan Fund — 29.2% Annual Returns',
  soros:        'The Man Who Broke the Bank of England',
  livermore:    'Greatest Speculator in Market History',
  munger:       'The Architect Behind Berkshire',
  minervini:    '4× US Investing Champion',
};

/* ── Full-bleed portrait card ─────────────────────────────────────── */
function ExpertCard({ expert, isActive, onSelect }: {
  expert: any;
  isActive: boolean;
  onSelect: () => void;
}) {
  const [imgErrored, setImgErrored] = useState(false);
  const portrait = EXPERT_PORTRAITS[expert.id];
  const avatar   = EXPERT_AVATARS[expert.id];
  const subtitle = EXPERT_SUBTITLES[expert.id] ?? expert.era;
  const showRealPhoto = portrait && !imgErrored;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -6, transition: { duration: 0.18 } }}
      className="relative h-[440px] rounded-2xl overflow-hidden cursor-default group"
      style={{ boxShadow: isActive ? `0 0 32px ${expert.signatureColor}50` : '0 4px 24px rgba(0,0,0,0.5)' }}
    >
      {/* ── portrait / avatar ── */}
      {showRealPhoto ? (
        <img
          src={portrait!}
          alt={expert.name}
          className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
          onError={() => setImgErrored(true)}
        />
      ) : avatar ? (
        <img
          src={avatar}
          alt={expert.name}
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      ) : (
        /* color gradient background fallback */
        <div
          className="absolute inset-0"
          style={{
            background: `radial-gradient(ellipse at 50% 30%, ${expert.signatureColor}55 0%, transparent 70%), linear-gradient(135deg, #0a0a14 0%, #1a1a2e 100%)`,
          }}
        >
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-8xl font-black font-[family-name:var(--app-font-display)] opacity-20"
              style={{ color: expert.signatureColor }}>
              {expert.name.split(' ').map((w: string) => w[0]).join('').slice(0,2)}
            </span>
          </div>
        </div>
      )}

      {/* ── gradient overlay ── */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/95" />

      {/* ── top accent bar ── */}
      <div className="absolute top-0 left-0 right-0 h-[3px]" style={{ backgroundColor: expert.signatureColor }} />

      {/* ── top-left strategy tags ── */}
      <div className="absolute top-4 left-4 flex flex-wrap gap-1">
        {expert.strategyStyle.slice(0, 2).map((s: string) => (
          <span key={s} className="text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full backdrop-blur-sm border"
            style={{ backgroundColor: `${expert.signatureColor}25`, borderColor: `${expert.signatureColor}50`, color: 'white' }}>
            {s}
          </span>
        ))}
      </div>

      {/* ── top-right active badge ── */}
      {isActive && (
        <div className="absolute top-4 right-4 p-1.5 rounded-full backdrop-blur-sm border"
          style={{ backgroundColor: `${expert.signatureColor}30`, borderColor: expert.signatureColor, color: expert.signatureColor }}>
          <UserCheck className="w-4 h-4" />
        </div>
      )}

      {/* ── bottom info overlay ── */}
      <div className="absolute bottom-0 left-0 right-0 p-5">
        <h2 className="text-xl font-black font-[family-name:var(--app-font-display)] text-white leading-tight drop-shadow-lg">
          {expert.name}
        </h2>
        <p className="text-xs mt-0.5 font-medium drop-shadow" style={{ color: expert.signatureColor }}>
          {subtitle}
        </p>
        <p className="text-[11px] text-white/60 italic mt-2 line-clamp-2 leading-relaxed">
          "{expert.philosophy}"
        </p>

        {/* ── action buttons ── */}
        <div className="flex gap-2 mt-4">
          <button
            onClick={onSelect}
            className="flex-1 py-2 text-xs font-bold rounded-lg uppercase tracking-wider transition-all backdrop-blur-sm border"
            style={isActive
              ? { backgroundColor: 'rgba(255,255,255,0.08)', borderColor: 'rgba(255,255,255,0.2)', color: 'white' }
              : { backgroundColor: expert.signatureColor, borderColor: 'transparent', color: 'white' }
            }
            data-testid={`btn-select-expert-${expert.id}`}
          >
            {isActive ? '✓ Active Strategy' : 'Select Strategy'}
          </button>
          <Link
            href={`/experts/${expert.id}`}
            className="px-3 py-2 rounded-lg flex items-center justify-center backdrop-blur-sm border border-white/20 hover:border-white/40 text-white transition-colors"
            style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}
            data-testid={`link-chat-expert-${expert.id}`}
          >
            <MessageSquare className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

export default function Experts() {
  const { data: experts, isLoading } = useListExperts({ query: { queryKey: getListExpertsQueryKey() } });
  const { activeStrategy, setActiveStrategy } = useStrategyStore();

  return (
    <div className="p-6 max-w-[1400px] mx-auto w-full space-y-10">
      <div className="text-center max-w-2xl mx-auto py-8">
        <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground mb-3 font-mono">A private audience with the legends</p>
        <h1 className="text-4xl font-black font-[family-name:var(--app-font-display)] mb-4 glow-text">Legendary Minds</h1>
        <p className="text-muted-foreground text-sm">
          Select a master investor's strategy to lens your analysis, or chat directly with their AI persona.
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5">
          {[1,2,3,4,5,6,7,8].map(i => <Skeleton key={i} className="h-[440px] w-full bg-secondary rounded-2xl" />)}
        </div>
      ) : experts ? (
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-5">
          {experts.map((expert, idx) => (
            <motion.div
              key={expert.id}
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.07, duration: 0.4 }}
            >
              <ExpertCard
                expert={expert}
                isActive={activeStrategy === expert.id}
                onSelect={() => setActiveStrategy(expert.id, expert)}
              />
            </motion.div>
          ))}
        </div>
      ) : null}

      <style>{`.glow-text { text-shadow: 0 0 20px var(--color-primary); }`}</style>
    </div>
  );
}

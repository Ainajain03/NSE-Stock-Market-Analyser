import React, { useState } from 'react';
import { useStockStore } from '@/store/stockStore';
import { useStrategyStore } from '@/store/strategyStore';
import {
  useGetTechnicalAnalysis,
  useGetStockHistorical,
  useGetTechnicalAiSummary,
  getGetTechnicalAnalysisQueryKey,
  getGetStockHistoricalQueryKey
} from '@workspace/api-client-react';
import type { GetTechnicalAnalysisTimeframe } from '@workspace/api-client-react';
import { motion, AnimatePresence } from 'framer-motion';
import { SignalCard } from '@/components/SignalCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { CandlestickChart } from '@/components/CandlestickChart';
import { Loader2, BrainCircuit, CandlestickChart as CandleIcon, TrendingUp, ExternalLink } from 'lucide-react';
import { formatCurrency } from '@/lib/format';

const TIMEFRAMES: GetTechnicalAnalysisTimeframe[] = ['1D', '1W', '1M', '3M', '6M', '1Y', '5Y'];

const CHART_MODES = [
  { id: 'candle', label: 'Candles', icon: CandleIcon },
  { id: 'line',   label: 'Line',    icon: TrendingUp },
] as const;
type ChartMode = typeof CHART_MODES[number]['id'];

export default function Technical() {
  const selectedSymbol = useStockStore(state => state.selectedSymbol);
  const activeStrategy = useStrategyStore(state => state.activeStrategy);
  const [timeframe, setTimeframe] = useState<GetTechnicalAnalysisTimeframe>('1Y');
  const [chartMode, setChartMode] = useState<ChartMode>('candle');

  const { data: techData, isLoading: techLoading } = useGetTechnicalAnalysis(
    selectedSymbol ?? '',
    { timeframe, strategy: activeStrategy ?? undefined },
    { query: { enabled: !!selectedSymbol, queryKey: getGetTechnicalAnalysisQueryKey(selectedSymbol ?? '', { timeframe, strategy: activeStrategy ?? undefined }) } }
  );

  const { data: histData, isLoading: histLoading } = useGetStockHistorical(
    selectedSymbol ?? '',
    { timeframe },
    { query: { enabled: !!selectedSymbol, queryKey: getGetStockHistoricalQueryKey(selectedSymbol ?? '', { timeframe }) } }
  );

  const aiSummaryMutation = useGetTechnicalAiSummary();

  if (!selectedSymbol) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="text-center space-y-3">
          <div className="w-16 h-16 mx-auto rounded-full bg-primary/5 border border-primary/10 flex items-center justify-center">
            <CandleIcon className="w-7 h-7 text-muted-foreground opacity-40" />
          </div>
          <p className="text-muted-foreground">Please select a stock from the command center to view technical analysis.</p>
        </div>
      </div>
    );
  }

  const containerVariants = { hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.05 } } };
  const itemVariants = { hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } };

  const signalsByCategory = techData?.signals.reduce((acc, signal) => {
    if (!acc[signal.category]) acc[signal.category] = [];
    acc[signal.category].push(signal);
    return acc;
  }, {} as Record<string, typeof techData.signals>);

  const lastCandle = histData?.[histData.length - 1];
  const firstCandle = histData?.[0];
  const priceChange = lastCandle && firstCandle ? ((lastCandle.close - firstCandle.close) / firstCandle.close) * 100 : null;
  const isUp = (priceChange ?? 0) >= 0;

  return (
    <div className="p-6 max-w-[1400px] mx-auto w-full space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-[family-name:var(--app-font-display)] text-primary" style={{ textShadow: '0 0 20px var(--color-primary)' }}>
            Technical Analysis
          </h1>
          <div className="flex items-center gap-3 mt-1 font-mono text-sm text-muted-foreground">
            <span>{selectedSymbol}</span>
            {lastCandle && (
              <>
                <span className="opacity-30">|</span>
                <span className="text-foreground">{formatCurrency(lastCandle.close)}</span>
                {priceChange !== null && (
                  <span className={isUp ? 'text-[var(--signal-buy)]' : 'text-[var(--signal-sell)]'}>
                    {isUp ? '+' : ''}{priceChange.toFixed(2)}% ({timeframe})
                  </span>
                )}
              </>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <a
            href={`https://www.tradingview.com/chart/?symbol=NSE:${selectedSymbol}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-md border border-blue-500/30 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors"
            title="Open in TradingView"
          >
            <ExternalLink className="w-3 h-3" /> TradingView
          </a>
          <a
            href={`https://chartink.com/stocks/${selectedSymbol.toLowerCase()}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-md border border-orange-500/30 bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 transition-colors"
            title="Open in Chartink"
          >
            <ExternalLink className="w-3 h-3" /> Chartink
          </a>
          <div className="flex bg-secondary p-1 rounded-md border border-primary/20">
            {CHART_MODES.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setChartMode(id)}
                className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition-colors ${chartMode === id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-primary/10'}`}
              >
                <Icon className="w-3 h-3" /> {label}
              </button>
            ))}
          </div>
          <div className="flex bg-secondary p-1 rounded-md border border-primary/20">
            {TIMEFRAMES.map(tf => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-3 py-1 text-xs font-mono rounded transition-colors ${timeframe === tf ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-primary/10'}`}
                data-testid={`btn-timeframe-${tf}`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-card border-primary/20 overflow-hidden">
            <CardHeader className="pb-0 pt-4 px-4 border-b border-primary/10">
              <div className="flex items-center justify-between mb-3">
                <CardTitle className="text-sm font-[family-name:var(--app-font-display)] flex items-center gap-2">
                  <CandleIcon className="w-4 h-4 text-primary" />
                  Price Action — {selectedSymbol} ({timeframe})
                </CardTitle>
                {lastCandle && (
                  <div className="flex gap-3 text-[11px] font-mono text-muted-foreground">
                    <span>O <span className="text-foreground">{formatCurrency(lastCandle.open)}</span></span>
                    <span>H <span className="text-[var(--signal-buy)]">{formatCurrency(lastCandle.high)}</span></span>
                    <span>L <span className="text-[var(--signal-sell)]">{formatCurrency(lastCandle.low)}</span></span>
                    <span>C <span className="text-foreground">{formatCurrency(lastCandle.close)}</span></span>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {histLoading ? (
                <Skeleton className="w-full bg-secondary" style={{ height: 420 }} />
              ) : histData && histData.length > 0 ? (
                <AnimatePresence mode="wait">
                  <motion.div key={`${chartMode}-${timeframe}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
                    {chartMode === 'candle' ? (
                      <CandlestickChart data={histData} height={420} showVolume />
                    ) : (
                      <LineChartFallback data={histData} height={420} />
                    )}
                  </motion.div>
                </AnimatePresence>
              ) : (
                <div className="flex items-center justify-center text-muted-foreground bg-card" style={{ height: 420 }}>
                  No chart data available
                </div>
              )}
            </CardContent>
          </Card>

          {techData && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'RSI (14)', value: techData.indicators.rsi?.toFixed(1) ?? '—', sub: techData.indicators.rsi != null ? (techData.indicators.rsi > 70 ? 'Overbought' : techData.indicators.rsi < 30 ? 'Oversold' : 'Neutral') : '' },
                { label: 'MACD', value: techData.indicators.macdHistogram?.toFixed(2) ?? '—', sub: (techData.indicators.macdHistogram ?? 0) > 0 ? 'Bullish' : 'Bearish' },
                { label: 'ADX (14)', value: techData.indicators.adx?.toFixed(1) ?? '—', sub: (techData.indicators.adx ?? 0) > 25 ? 'Trending' : 'Choppy' },
                { label: 'ATR (14)', value: techData.indicators.atr != null ? formatCurrency(techData.indicators.atr) : '—', sub: 'Volatility' },
              ].map((item, i) => (
                <Card key={i} className="bg-card border-primary/10">
                  <CardContent className="p-3">
                    <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">{item.label}</div>
                    <div className="text-xl font-bold font-mono mt-1">{item.value}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{item.sub}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <Card className="bg-card border-primary/20">
            <CardHeader className="bg-secondary/20 pb-4 border-b border-primary/10">
              <CardTitle className="flex justify-between items-center font-[family-name:var(--app-font-display)]">
                <div className="flex items-center gap-2">
                  <BrainCircuit className="w-4 h-4 text-primary" />
                  AI Technical Summary
                </div>
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => aiSummaryMutation.mutate({ symbol: selectedSymbol, data: { strategy: activeStrategy ?? undefined } })}
                  disabled={aiSummaryMutation.isPending}
                  className="px-3 py-1.5 bg-primary/20 text-primary hover:bg-primary hover:text-primary-foreground rounded-lg text-xs font-medium border border-primary/30 flex items-center gap-2 transition-all"
                  data-testid="button-get-ai-summary"
                >
                  {aiSummaryMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <BrainCircuit className="w-3 h-3" />}
                  {aiSummaryMutation.isPending ? 'Analysing...' : 'Get AI Analysis'}
                </motion.button>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <AnimatePresence mode="wait">
                {aiSummaryMutation.isPending ? (
                  <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3 py-4 text-muted-foreground text-sm font-mono">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    AI is analysing technical indicators...
                  </motion.div>
                ) : aiSummaryMutation.data ? (
                  <motion.div key="summary" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-sm leading-relaxed whitespace-pre-wrap">
                    {aiSummaryMutation.data.summary}
                  </motion.div>
                ) : (
                  <motion.div key="empty" className="text-muted-foreground text-sm py-4 text-center">
                    Generate an AI summary for a synthesized view of all technical indicators.
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4 max-h-[900px] overflow-y-auto pr-2 custom-scrollbar">
          {techLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-28 w-full bg-secondary" />)}
            </div>
          ) : techData ? (
            <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-6">
              <div className="p-5 rounded-xl bg-secondary/30 border border-primary/15 text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
                <div className="text-[10px] uppercase font-bold text-muted-foreground mb-2 tracking-widest">Aggregate Signal</div>
                <div className={`text-2xl font-bold font-[family-name:var(--app-font-display)] ${techData.aggregated.signal.includes('BUY') ? 'text-[var(--signal-buy)]' : techData.aggregated.signal.includes('SELL') ? 'text-[var(--signal-sell)]' : 'text-[var(--signal-neutral)]'}`}>
                  {techData.aggregated.signal.replace(/_/g, ' ')}
                </div>
                <div className="mt-2 flex items-center justify-center gap-4 text-xs font-mono text-muted-foreground">
                  <span>Score: <span className="text-foreground">{techData.overallScore}/100</span></span>
                  <span className="opacity-30">|</span>
                  <span>Trend: <span className="text-foreground">{techData.trend}</span></span>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] font-mono">
                  <div className="p-2 bg-background/50 rounded border border-primary/5">
                    <div className="text-muted-foreground">Entry</div>
                    <div>{formatCurrency(techData.aggregated.entryZoneLow)} – {formatCurrency(techData.aggregated.entryZoneHigh)}</div>
                  </div>
                  <div className="p-2 bg-background/50 rounded border border-primary/5">
                    <div className="text-muted-foreground">Stop</div>
                    <div className="text-[var(--signal-sell)]">{formatCurrency(techData.aggregated.stopLoss)}</div>
                  </div>
                  <div className="p-2 bg-background/50 rounded border border-primary/5">
                    <div className="text-muted-foreground">Target 1</div>
                    <div className="text-[var(--signal-buy)]">{formatCurrency(techData.aggregated.target1)}</div>
                  </div>
                  <div className="p-2 bg-background/50 rounded border border-primary/5">
                    <div className="text-muted-foreground">Target 2</div>
                    <div className="text-[var(--signal-buy)]">{formatCurrency(techData.aggregated.target2)}</div>
                  </div>
                </div>
              </div>

              {Object.entries(signalsByCategory ?? {}).map(([category, signals]) => (
                <div key={category} className="space-y-2">
                  <h3 className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-primary/60 rounded-full" />
                    {category.replace(/_/g, ' ')}
                  </h3>
                  <div className="space-y-2">
                    {signals.map(signal => (
                      <motion.div key={signal.indicator} variants={itemVariants}>
                        <SignalCard
                          indicator={signal.indicator}
                          value={signal.value}
                          signal={signal.signal}
                          strength={signal.strength}
                          reason={signal.reason}
                          isAnimated={false}
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          ) : null}
        </div>
      </div>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
      `}</style>
    </div>
  );
}

function LineChartFallback({ data, height }: { data: { time: string; close: number; open: number; high: number; low: number; volume: number }[]; height: number }) {
  if (!data.length) return null;
  const min = Math.min(...data.map(d => d.low));
  const max = Math.max(...data.map(d => d.high));
  const range = max - min || 1;
  const w = 100;
  const h = height - 40;

  const points = data.map((d, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((d.close - min) / range) * h;
    return `${x},${y}`;
  }).join(' ');

  const firstClose = data[0]?.close ?? 0;
  const lastClose  = data[data.length - 1]?.close ?? 0;
  const isUp = lastClose >= firstClose;
  const color = isUp ? '#22c55e' : '#ef4444';

  return (
    <svg width="100%" height={height} viewBox={`0 0 100 ${h}`} preserveAspectRatio="none" className="px-4">
      <defs>
        <linearGradient id="lineFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.2" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline points={points} fill="none" stroke={color} strokeWidth="0.5" vectorEffect="non-scaling-stroke" />
      <polygon points={`0,${h} ${points} ${w},${h}`} fill="url(#lineFill)" />
    </svg>
  );
}

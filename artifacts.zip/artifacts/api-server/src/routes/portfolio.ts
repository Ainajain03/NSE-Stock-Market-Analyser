import { Router, type IRouter } from "express";
import { fetchQuote } from "../lib/yahooFinance";
import { groqChat } from "../lib/groq";
import Groq from "groq-sdk";

const router: IRouter = Router();

interface Holding {
  symbol: string;
  name: string;
  quantity: number;
  buyPrice: number;
}

async function enrichWithPrices(holdings: Holding[]) {
  return Promise.all(
    holdings.map(async (h) => {
      try {
        const q = await fetchQuote(h.symbol);
        const currentPrice  = q.price;
        const currentValue  = currentPrice * h.quantity;
        const investedValue = h.buyPrice  * h.quantity;
        const pnl           = currentValue - investedValue;
        const pnlPercent    = ((pnl / investedValue) * 100);
        return { ...h, currentPrice, currentValue, investedValue, pnl, pnlPercent,
          change: q.change, changePercent: q.changePercent, sector: h.name };
      } catch {
        const currentPrice  = h.buyPrice;
        const currentValue  = currentPrice * h.quantity;
        const investedValue = h.buyPrice   * h.quantity;
        return { ...h, currentPrice, currentValue, investedValue, pnl: 0, pnlPercent: 0,
          change: 0, changePercent: 0, sector: "NSE Listed" };
      }
    })
  );
}

/* ── Parse a broker-statement screenshot (vision via Groq llama-4-scout) ── */
router.post("/portfolio/parse-image", async (req, res): Promise<void> => {
  const { imageBase64, mimeType = "image/jpeg" } = req.body as {
    imageBase64: string;
    mimeType?: string;
  };
  if (!imageBase64) {
    res.status(400).json({ error: "imageBase64 is required" });
    return;
  }

  try {
    const groqClient = new Groq({ apiKey: process.env.GROQ_API_KEY });
    const message = await groqClient.chat.completions.create({
      model: "meta-llama/llama-4-scout-17b-16e-instruct",
      max_tokens: 4096,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image_url",
              image_url: { url: `data:${mimeType};base64,${imageBase64}` },
            },
            {
              type: "text",
              text: `You are a portfolio parser specialising in Indian stock brokers (Zerodha, Groww, Upstox, Angel One, ICICI Direct, HDFC Securities, etc.).

Analyse this portfolio statement / holdings screenshot and extract ALL stock positions.

For each holding, extract:
- symbol: NSE ticker symbol (uppercase, e.g. RELIANCE, HDFCBANK, INFY)
- name: company name
- quantity: number of shares (integer)
- buyPrice: average buy price / cost price per share (number)

Return ONLY a valid JSON object in this exact format (no markdown, no explanation):
{
  "holdings": [
    { "symbol": "RELIANCE", "name": "Reliance Industries", "quantity": 10, "buyPrice": 2500.00 }
  ]
}

If you cannot identify specific values, use your best estimate based on visible data. If the image is not a portfolio statement, return { "holdings": [], "error": "Not a portfolio image" }.`,
            },
          ],
        },
      ],
    });

    const raw = message.choices[0]?.message?.content?.trim() ?? "{}";
    try {
      res.json(JSON.parse(raw));
    } catch {
      const match = raw.match(/\{[\s\S]*\}/);
      try {
        res.json(JSON.parse(match?.[0] ?? "{}"));
      } catch {
        res.json({ holdings: [], error: "Could not parse AI response" });
      }
    }
  } catch (err: any) {
    req.log?.error({ err }, "Groq vision parse-image failed");
    res.json({ holdings: [], error: "Image parsing failed. Please try a clearer screenshot." });
  }
});

/* ── Generate comprehensive AI thesis for the portfolio ── */
router.post("/portfolio/analyze", async (req, res): Promise<void> => {
  const { holdings } = req.body as { holdings: Holding[] };
  if (!holdings?.length) {
    res.status(400).json({ error: "No holdings provided" });
    return;
  }

  const enriched = await enrichWithPrices(holdings);

  const totalInvested = enriched.reduce((s, h) => s + h.investedValue, 0);
  const totalValue    = enriched.reduce((s, h) => s + h.currentValue,  0);
  const totalPnl      = totalValue - totalInvested;
  const totalReturn   = ((totalPnl / totalInvested) * 100);

  const holdingsText = enriched
    .map((h) =>
      `• ${h.symbol} (${h.name}): ${h.quantity} shares × ₹${h.buyPrice.toFixed(2)} avg → CMP ₹${h.currentPrice.toFixed(2)} | P&L: ₹${h.pnl.toFixed(0)} (${h.pnlPercent.toFixed(2)}%)`
    )
    .join("\n");

  const prompt = `PORTFOLIO SUMMARY:
• Total Holdings: ${enriched.length} stocks
• Total Invested: ₹${totalInvested.toLocaleString("en-IN", { maximumFractionDigits: 0 })}
• Current Value:  ₹${totalValue.toLocaleString("en-IN",    { maximumFractionDigits: 0 })}
• Total P&L:      ₹${totalPnl.toLocaleString("en-IN",      { maximumFractionDigits: 0 })} (${totalReturn.toFixed(2)}%)

INDIVIDUAL HOLDINGS:
${holdingsText}

Write a detailed portfolio thesis report with these sections:

## 1. PORTFOLIO HEALTH SNAPSHOT
Overall assessment: risk, diversification, sector concentration, quality of holdings.

## 2. TOP PERFORMERS — HOLD OR BOOK?
For each significant winner (>10% gain): Should the investor hold for more upside or partially book profits? Specific reasoning.

## 3. UNDERPERFORMERS — CUT OR AVERAGE?
For each loser (>10% loss): Is this a temporary dip worth averaging, or time to cut losses? Specific reasoning with price targets.

## 4. SECTOR ALLOCATION ANALYSIS
Current sector exposure. Over-concentration risks. Missing sector opportunities for Indian growth themes (e.g. defence, railways, capex, EV, real estate, digital).

## 5. REBALANCING RECOMMENDATIONS
Specific actions to take now:
- Stocks to BUY MORE (with rationale)
- Stocks to PARTIALLY SELL (with target %)
- Stocks to EXIT COMPLETELY (with reasoning)
- New stocks to ADD for better diversification

## 6. RISK ASSESSMENT
Key risks in this portfolio: macro (RBI, FII flows, global), sector-specific, stock-specific. What could go wrong.

## 7. 12-MONTH OUTLOOK
Expected portfolio return range, key catalysts, key risks. Investment horizon recommendation.

Be precise, decisive, and India-specific. Reference current macro context — RBI policy, India growth story, capex cycle, consumption trends, FII positioning.`;

  try {
    const thesis = await groqChat({
      system: "You are a senior portfolio manager at a top Indian institutional fund. Analyse the following NSE portfolio and provide a comprehensive investment thesis report.",
      messages: [{ role: "user", content: prompt }],
    });

    res.json({
      thesis,
      summary: { totalHoldings: enriched.length, totalInvested, totalValue, totalPnl, totalReturn },
      enrichedHoldings: enriched,
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    req.log?.error({ err }, "Groq portfolio analyze failed");
    res.status(500).json({ error: "AI analysis failed", userMessage: "Something went wrong generating the thesis. Please try again." });
  }
});

/* ── Portfolio chatbot — context-aware Q&A ── */
router.post("/portfolio/chat", async (req, res): Promise<void> => {
  const { holdings, message, history = [] } = req.body as {
    holdings: Holding[];
    message: string;
    history: Array<{ role: "user" | "assistant"; content: string }>;
  };

  const enriched = holdings?.length ? await enrichWithPrices(holdings) : [];
  const totalInvested = enriched.reduce((s, h) => s + h.investedValue, 0);
  const totalValue    = enriched.reduce((s, h) => s + h.currentValue,  0);
  const totalPnl      = totalValue - totalInvested;

  const portfolioContext = enriched.length
    ? `USER'S CURRENT PORTFOLIO (${enriched.length} stocks):
${enriched.map(h => `• ${h.symbol}: ${h.quantity}@₹${h.buyPrice.toFixed(2)} | CMP ₹${h.currentPrice.toFixed(2)} | P&L: ${h.pnlPercent.toFixed(1)}%`).join("\n")}

Portfolio Total: Invested ₹${totalInvested.toLocaleString("en-IN")} | Current ₹${totalValue.toLocaleString("en-IN")} | P&L ₹${totalPnl.toLocaleString("en-IN")} (${((totalPnl/totalInvested)*100).toFixed(1)}%)`
    : "User has not added any holdings yet.";

  const systemPrompt = `You are StockSage Portfolio AI — an expert Indian stock market portfolio advisor. You provide personalised, actionable advice based on the user's actual portfolio.

${portfolioContext}

Guidelines:
- Always reference specific stocks from the portfolio when relevant
- Provide concrete numbers, percentages, and price targets
- Factor in India-specific context: NSE/BSE, SEBI regulations, RBI policy, FII/DII flows
- Be decisive and actionable — avoid generic advice
- Keep responses focused and under 300 words unless a detailed analysis is explicitly asked
- If the user has no portfolio, help them build one`;

  const messages = [
    ...history.slice(-10).map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
    { role: "user" as const, content: message },
  ];

  try {
    const reply = await groqChat({ system: systemPrompt, messages });
    res.json({ reply });
  } catch (err: any) {
    req.log?.error({ err }, "Groq portfolio chat failed");
    res.json({ reply: "Sorry, I ran into an error. Please try again in a moment." });
  }
});

export default router;

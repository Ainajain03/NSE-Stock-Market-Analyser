import { Router, type IRouter } from "express";
import healthRouter from "./health";
import stocksRouter from "./stocks";
import technicalRouter from "./technical";
import fundamentalRouter from "./fundamental";
import sentimentRouter from "./sentiment";
import expertsRouter from "./experts";
import dashboardRouter from "./dashboard";
import watchlistRouter from "./watchlist";
import chatRouter from "./chat";
import portfolioRouter from "./portfolio";

const router: IRouter = Router();

router.use(healthRouter);
router.use(stocksRouter);
router.use(technicalRouter);
router.use(fundamentalRouter);
router.use(sentimentRouter);
router.use(expertsRouter);
router.use(dashboardRouter);
router.use(watchlistRouter);
router.use(chatRouter);
router.use(portfolioRouter);

export default router;

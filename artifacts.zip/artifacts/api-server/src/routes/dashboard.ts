import { Router, type IRouter } from "express";
import { NSE_STOCKS_FULL, BASE_PRICES_FALLBACK } from "../lib/nseStocks";
import { generateOHLCV, EXPERT_PROFILES, atr } from "../lib/mockData";
import { fetchQuote, fetchOHLCV } from "../lib/yahooFinance";
import { groqChat } from "../lib/groq";

const router: IRouter = Router();

function mockPrice(symbol: string): number {
  const base = BASE_PRICES_FALLBACK[symbol] ?? 1000;
  const noise = Math.sin(Date.now() / 10000 + symbol.charCodeAt(0)) * 0.02;
  return Math.round(base * (1 + noise) * 100) / 100;
}

function seedRng(seed: number) {
  return (min: number, max: number, off = 0) =>
    min + (Math.sin(seed + off) * 0.5 + 0.5) * (max - min);
}

router.get("/dashboard/:symbol", async (req, res): Promise<void> => {
  const symbol   = String(req.params.symbol).toUpperCase();
  const strategy = String(req.query.strategy ?? "");
  const seed     = symbol.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const rng      = seedRng(seed);

  // Try to get real quote from Yahoo Finance
  let price        = mockPrice(symbol);
  let quoteName    = NSE_STOCKS_FULL[symbol]?.name ?? symbol;
  let quoteOpen    = price;
  let quoteHigh    = price * (1 + rng(0.005, 0.025, 2));
  let quoteLow     = price * (1 - rng(0.005, 0.025, 3));
  let quoteChange  = 0;
  let quoteChangePct = 0;
  let quoteVolume  = Math.floor(rng(500000, 8000000, 4));
  let quoteMarketCap: number | null = Math.round(price * rng(500e6, 5000e9, 5));
  let quotePE: number | null        = Math.round(rng(12, 60, 6) * 10) / 10;
  let quoteHigh52  = Math.round(price * rng(1.10, 1.55, 7) * 100) / 100;
  let quoteLow52   = Math.round(price * rng(0.55, 0.90, 8) * 100) / 100;
  let quoteSector  = NSE_STOCKS_FULL[symbol]?.sector ?? "NSE Listed";
  let quoteSource  = "mock";

  try {
    const q = await fetchQuote(symbol);
    price           = q.price;
    quoteName       = q.name || quoteName;
    quoteOpen       = q.open;
    quoteHigh       = q.high;
    quoteLow        = q.low;
    quoteChange     = q.change;
    quoteChangePct  = q.changePercent;
    quoteVolume     = q.volume;
    quoteMarketCap  = q.marketCap;
    quotePE         = q.pe;
    quoteHigh52     = q.high52w ?? quoteHigh52;
    quoteLow52      = q.low52w  ?? quoteLow52;
    quoteSource     = "live";
  } catch {
    const changePercent = Math.sin(seed + Date.now() / 86400000) * 2.5;
    quoteChange    = Math.round(price * changePercent / 100 * 100) / 100;
    quoteChangePct = Math.round(changePercent * 100) / 100;
  }

  if (!NSE_STOCKS_FULL[symbol] && quoteSource === "mock") {
    res.status(404).json({ error: `Stock ${symbol} not found` });
    return;
  }

  const technicalScore  = Math.round(rng(45, 88, 1));
  const fundamentalScore = Math.round(rng(42, 90, 2));
  const sentimentScore  = Math.round(rng(40, 85, 3));
  const overallScore    = Math.round((technicalScore + fundamentalScore + sentimentScore) / 3);

  const signalFromScore = (s: number) => s > 72 ? "BUY" : s > 58 ? "NEUTRAL" : "SELL";

  // Price history from real OHLCV if possible
  let priceHistory: { date: string; price: number }[] = [];
  try {
    const candles = await fetchOHLCV(symbol, "1M");
    priceHistory = candles.slice(-30).map(c => ({ date: c.time, price: c.close }));
  } catch {
    const candles = generateOHLCV(symbol, 30);
    priceHistory = candles.map(c => ({ date: c.time, price: c.close }));
  }

  const stock1Y = Math.round(rng(-15, 65, 10) * 10) / 10;

  res.json({
    symbol,
    quote: {
      symbol, name: quoteName, price, change: quoteChange,
      changePercent: Math.round(quoteChangePct * 100) / 100,
      open: quoteOpen, high: quoteHigh, low: quoteLow, close: price,
      volume: quoteVolume, marketCap: quoteMarketCap, pe: quotePE,
      high52w: quoteHigh52, low52w: quoteLow52,
      sector: quoteSector, exchange: "NSE",
      timestamp: new Date().toISOString(), source: quoteSource,
    },
    technicalScore,   technicalSignal:   signalFromScore(technicalScore),
    fundamentalScore, fundamentalSignal: fundamentalScore > 72 ? "GOOD" : fundamentalScore > 55 ? "AVERAGE" : "POOR",
    sentimentScore,   sentimentSignal:   signalFromScore(sentimentScore),
    overallScore,
    priceHistory,
    benchmarkComparison: {
      stock1Y,
      nifty501Y:    Math.round(rng(8, 35, 15) * 10) / 10,
      nifty5001Y:   Math.round(rng(10, 40, 16) * 10) / 10,
      sectorIndex1Y: Math.round(rng(5, 55, 17) * 10) / 10,
    },
  });
});

router.post("/dashboard/:symbol/final-verdict", async (req, res): Promise<void> => {
  const symbol   = String(req.params.symbol).toUpperCase();
  const strategy = String(req.body?.strategy ?? "");
  const seed     = symbol.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const rng      = seedRng(seed);

  // Get real price
  let price    = mockPrice(symbol);
  let stockName = NSE_STOCKS_FULL[symbol]?.name ?? symbol;
  let sector    = NSE_STOCKS_FULL[symbol]?.sector ?? "NSE Listed";
  try {
    const q = await fetchQuote(symbol);
    price     = q.price;
    stockName = q.name || stockName;
  } catch { /* use mock */ }

  if (!NSE_STOCKS_FULL[symbol] && price === mockPrice(symbol)) {
    res.status(404).json({ error: `Stock ${symbol} not found` });
    return;
  }

  // Compute real ATR for consistent stop/target levels
  let effectiveAtr = price * 0.025; // 2.5% default
  try {
    const candles = await fetchOHLCV(symbol, "3M");
    if (candles.length >= 14) {
      const highs  = candles.map(c => c.high);
      const lows   = candles.map(c => c.low);
      const closes = candles.map(c => c.close);
      effectiveAtr = atr(highs, lows, closes, 14) ?? effectiveAtr;
    }
  } catch { /* use default */ }

  const technicalScore  = Math.round(rng(45, 88, 1));
  const fundamentalScore = Math.round(rng(42, 90, 2));
  const sentimentScore  = Math.round(rng(40, 85, 3));
  const overallScore    = Math.round((technicalScore + fundamentalScore + sentimentScore) / 3);

  const expert = EXPERT_PROFILES.find((e) => e.id === strategy);
  const expertSection = expert
    ? `\n\nACTIVE STRATEGY: ${expert.name}\nPhilosophy: ${expert.philosophy}\nKey Principles: ${expert.keyPrinciples.slice(0, 3).join("; ")}`
    : "";

  const prompt = `You are StockSage AI, a comprehensive Indian stock market intelligence engine. Provide a complete 360° analysis of ${symbol} (${stockName}).

STOCK INFO: ${stockName} | Sector: ${sector} | NSE Listed
Current Live Price: ₹${price.toFixed(2)}
ATR (14-day): ₹${effectiveAtr.toFixed(2)} (volatility baseline)

ANALYSIS SCORES:
- Technical:   ${technicalScore}/100 → ${technicalScore > 70 ? "BUY" : technicalScore > 55 ? "NEUTRAL" : "SELL"}
- Fundamental: ${fundamentalScore}/100 → ${fundamentalScore > 70 ? "STRONG" : fundamentalScore > 55 ? "AVERAGE" : "WEAK"}
- Sentiment:   ${sentimentScore}/100 → ${sentimentScore > 70 ? "BULLISH" : sentimentScore > 55 ? "NEUTRAL" : "BEARISH"}
- Overall:     ${overallScore}/100
${expertSection}

Based on ALL of the above, provide a professional investment report with these exact sections:

1. EXECUTIVE SUMMARY
(3–4 sentences covering the core investment thesis right now)

2. BULL CASE
Top 3 reasons to buy — each with a specific data point or catalyst relevant to ${stockName}

3. BEAR CASE
Top 3 risks — sector headwinds, valuation concerns, macro risks

4. CATALYSTS TO WATCH
3 upcoming events or triggers that could move the price in the next 3–6 months

5. FINAL VERDICT
- Recommendation: [STRONG BUY / BUY / HOLD / SELL / STRONG SELL]
- Confidence: [X]%
- Investment Horizon: [SHORT (<3M) / MEDIUM (3-12M) / LONG (>1Y)]
- Entry Zone: ₹${(price - effectiveAtr * 0.5).toFixed(2)} – ₹${(price + effectiveAtr * 0.25).toFixed(2)}
- Stop Loss: ₹${(price - effectiveAtr * 2).toFixed(2)} (${(effectiveAtr * 2 / price * 100).toFixed(1)}% risk)
- Target 1: ₹${(price + effectiveAtr * 2).toFixed(2)} (+${(effectiveAtr * 2 / price * 100).toFixed(1)}%)
- Target 2: ₹${(price + effectiveAtr * 4).toFixed(2)} (+${(effectiveAtr * 4 / price * 100).toFixed(1)}%)
Note: Targets above are for a BUY recommendation. If SELL, flip direction.

${expert ? `6. ${expert.name.toUpperCase()}'S VERDICT\nOne focused paragraph: how would ${expert.name} analyse ${stockName}? Would they buy, hold, or avoid? Specific reasoning in their voice.` : "6. EXPERT PERSPECTIVE\nOne paragraph: what would a seasoned institutional investor make of this stock today?"}

Be decisive. Reference Indian market context — SEBI, RBI policy, India GDP cycle, FII flows, sector tailwinds. No generic disclaimers.`;

  const text = await groqChat({
    system: "You are a senior Indian equity analyst providing comprehensive stock analysis. Be decisive, India-specific, and reference current market context.",
    messages: [{ role: "user", content: prompt }],
  });

  const rec = text.includes("STRONG BUY")  ? "STRONG_BUY"  as const
            : text.includes("STRONG SELL") ? "STRONG_SELL" as const
            : text.includes("BUY")         ? "BUY"         as const
            : text.includes("AVOID")       ? "AVOID"       as const
            : text.includes("SELL")        ? "SELL"        as const : "HOLD" as const;

  const horizon = text.includes("LONG") ? "LONG" as const
                : text.includes("SHORT") ? "SHORT" as const : "MEDIUM" as const;

  const isBull = rec === "STRONG_BUY" || rec === "BUY";

  // ATR-based levels — same formula in technical.ts for consistency
  const entryLow  = Math.round((price - effectiveAtr * 0.5) * 100) / 100;
  const entryHigh = Math.round((price + effectiveAtr * 0.25) * 100) / 100;
  const stopLoss  = Math.round((isBull ? price - effectiveAtr * 2 : price + effectiveAtr * 2) * 100) / 100;
  const target1   = Math.round((isBull ? price + effectiveAtr * 2 : price - effectiveAtr * 2) * 100) / 100;
  const target2   = Math.round((isBull ? price + effectiveAtr * 4 : price - effectiveAtr * 4) * 100) / 100;
  const stopPct   = Math.round(Math.abs((stopLoss - price) / price) * 1000) / 10;
  const t1Pct     = Math.round(Math.abs((target1  - price) / price) * 1000) / 10;
  const t2Pct     = Math.round(Math.abs((target2  - price) / price) * 1000) / 10;

  const confidence = Math.min(95, Math.max(45, overallScore > 70 ? overallScore : overallScore + 10));

  // Parse sections from AI output
  const lines = text.split("\n").filter(Boolean);

  const bullLines = lines.filter(l => /^[-•▲\d]/.test(l.trim())).slice(0, 6);
  const bullCase = bullLines.length >= 3 ? bullLines.slice(0, 3).map(l => l.replace(/^[-•▲\d\.\s]+/, "").trim())
    : [`${sector} sector fundamentals remain robust`, "India's macro growth story supports long-term upside", "Improving margins and cash flows YoY"];

  const bearLines = lines.filter(l => /risk|concern|challenge|headwind|threat|weak|decline/i.test(l)).slice(0, 3);
  const bearCase = bearLines.length >= 2 ? bearLines.slice(0, 3).map(l => l.replace(/^[-•▲\d\.\s]+/, "").trim())
    : ["Global uncertainty and FII outflow risk", "Valuation premium may limit near-term upside", "Regulatory and competitive pressures"];

  const catalystLines = lines.filter(l => /catalyst|upcoming|event|quarter|result|guidance|policy|rbi|budget|launch/i.test(l)).slice(0, 3);
  const catalysts = catalystLines.length >= 2 ? catalystLines.slice(0, 3).map(l => l.replace(/^[-•▲\d\.\s]+/, "").trim())
    : ["Upcoming quarterly earnings announcement", "RBI monetary policy committee decision", "Management guidance and capex plans update"];

  const summaryMatch = text.match(/EXECUTIVE SUMMARY[\s\S]*?\n([\s\S]+?)(?:\n\n|\n[0-9]\.|\nBULL|\nBEAR)/i);
  const executiveSummary = summaryMatch
    ? summaryMatch[1].trim().slice(0, 500)
    : `${stockName} is a ${sector} company trading at ₹${price.toFixed(2)} with an overall score of ${overallScore}/100. ${overallScore > 65 ? "The stock shows positive signals across multiple dimensions." : "Mixed signals suggest cautious positioning."} Investors should monitor key levels and upcoming catalysts.`;

  const expertTakeMatch = text.match(/(?:VERDICT|PERSPECTIVE|TAKE)[\s\n:]+([^]*?)(?:\n\n\d\.|$)/i);
  const expertTake = expertTakeMatch
    ? expertTakeMatch[1].trim().slice(0, 600)
    : `Based on the comprehensive analysis, ${stockName} presents a ${rec.replace(/_/g, " ")} opportunity at ₹${price.toFixed(2)} with ${confidence}% confidence.`;

  res.json({
    recommendation: rec,
    confidence,
    investmentHorizon: horizon,
    currentPrice: price,
    atr: Math.round(effectiveAtr * 100) / 100,
    entryZoneLow: entryLow,
    entryZoneHigh: entryHigh,
    stopLoss,
    stopLossPercent: stopPct,
    target1,
    target1Percent: t1Pct,
    target2,
    target2Percent: t2Pct,
    executiveSummary,
    bullCase,
    bearCase,
    catalysts,
    expertTake,
    fullAnalysis: text,
    generatedAt: new Date().toISOString(),
    stockName,
    sector,
  });
});

export default router;

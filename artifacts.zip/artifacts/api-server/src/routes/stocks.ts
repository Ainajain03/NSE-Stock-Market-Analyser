import { Router, type IRouter } from "express";
import { NSE_STOCKS_FULL, BASE_PRICES_FALLBACK } from "../lib/nseStocks";
import { fetchQuote, fetchOHLCV, fetchMarketIndex, searchNSEStocks } from "../lib/yahooFinance";
import { generateOHLCV } from "../lib/mockData";

const router: IRouter = Router();

function mockPrice(symbol: string): number {
  const base = BASE_PRICES_FALLBACK[symbol] ?? 1000;
  const noise = Math.sin(Date.now() / 10000 + symbol.charCodeAt(0)) * 0.02;
  return Math.round(base * (1 + noise) * 100) / 100;
}

router.get("/stocks/search", async (req, res): Promise<void> => {
  const q = String(req.query.q ?? "").trim();
  if (!q || q.length < 1) {
    res.json([]);
    return;
  }
  const qu = q.toUpperCase();

  // Static list search first
  const staticResults = Object.entries(NSE_STOCKS_FULL)
    .filter(([sym, info]) =>
      sym.includes(qu) || info.name.toUpperCase().includes(qu) || info.sector.toUpperCase().includes(qu)
    )
    .slice(0, 15)
    .map(([symbol, info]) => ({
      symbol,
      name: info.name,
      sector: info.sector,
      exchange: info.exchange,
    }));

  // Also search Yahoo Finance for broader NSE coverage (all ~1800+ listed stocks)
  let dynamicResults: typeof staticResults = [];
  try {
    const yahooResults = await searchNSEStocks(q);
    const existingSymbols = new Set(staticResults.map(r => r.symbol));
    dynamicResults = yahooResults
      .filter(r => !existingSymbols.has(r.symbol))
      .slice(0, 20 - staticResults.length);
  } catch {
    // ignore dynamic search failure
  }

  const combined = [...staticResults, ...dynamicResults].slice(0, 20);
  res.json(combined);
});

router.get("/stocks/market-overview", async (_req, res): Promise<void> => {
  try {
    const [nifty50, bankNifty, sensex] = await Promise.allSettled([
      fetchMarketIndex("^NSEI"),
      fetchMarketIndex("^NSEBANK"),
      fetchMarketIndex("^BSESN"),
    ]);
    res.json({
      nifty50: nifty50.status === "fulfilled"
        ? { name: "NIFTY 50", ...nifty50.value }
        : { name: "NIFTY 50", value: 22847.25, change: 124.35, changePercent: 0.55 },
      bankNifty: bankNifty.status === "fulfilled"
        ? { name: "NIFTY BANK", ...bankNifty.value }
        : { name: "NIFTY BANK", value: 48234.6, change: -89.4, changePercent: -0.19 },
      sensex: sensex.status === "fulfilled"
        ? { name: "S&P BSE SENSEX", ...sensex.value }
        : { name: "S&P BSE SENSEX", value: 75234.78, change: 312.45, changePercent: 0.42 },
      indiaVix: 13.45,
      timestamp: new Date().toISOString(),
    });
  } catch {
    res.json({
      nifty50:   { name: "NIFTY 50",       value: 22847.25, change: 124.35,  changePercent: 0.55  },
      bankNifty: { name: "NIFTY BANK",     value: 48234.60, change: -89.40,  changePercent: -0.19 },
      sensex:    { name: "S&P BSE SENSEX", value: 75234.78, change: 312.45,  changePercent: 0.42  },
      indiaVix: 13.45,
      timestamp: new Date().toISOString(),
    });
  }
});

router.get("/stocks/:symbol/quote", async (req, res): Promise<void> => {
  const symbol = String(req.params.symbol).toUpperCase();
  const info = NSE_STOCKS_FULL[symbol];

  try {
    const q = await fetchQuote(symbol);
    const stockInfo = info ?? { name: q.name, sector: "NSE Listed", exchange: "NSE" };
    res.json({
      symbol,
      name: q.name || stockInfo.name,
      price: q.price,
      change: q.change,
      changePercent: q.changePercent,
      open: q.open,
      high: q.high,
      low: q.low,
      close: q.close,
      volume: q.volume,
      marketCap: q.marketCap,
      pe: q.pe,
      high52w: q.high52w,
      low52w: q.low52w,
      sector: stockInfo.sector,
      exchange: stockInfo.exchange,
      timestamp: new Date().toISOString(),
      source: "live",
    });
  } catch (err) {
    req.log?.warn({ err, symbol }, "Yahoo Finance quote failed, using mock");
    if (!info) {
      res.status(404).json({ error: `Stock ${symbol} not found on NSE` });
      return;
    }
    const price = mockPrice(symbol);
    const seed = symbol.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
    const rng = (min: number, max: number, off = 0) => min + (Math.sin(seed + off) * 0.5 + 0.5) * (max - min);
    const changePercent = (Math.sin(seed + Date.now() / 86400000) * 2.5);
    const change = Math.round(price * changePercent / 100 * 100) / 100;
    res.json({
      symbol,
      name: info.name,
      price,
      change,
      changePercent: Math.round(changePercent * 100) / 100,
      open:  Math.round(price * (1 - rng(0, 0.01, 1)) * 100) / 100,
      high:  Math.round(price * (1 + rng(0.005, 0.025, 2)) * 100) / 100,
      low:   Math.round(price * (1 - rng(0.005, 0.025, 3)) * 100) / 100,
      close: price,
      volume: Math.floor(rng(500000, 8000000, 4)),
      marketCap: Math.round(price * rng(500e6, 5000e9, 5)),
      pe: Math.round(rng(12, 60, 6) * 10) / 10,
      high52w: Math.round(price * rng(1.10, 1.55, 7) * 100) / 100,
      low52w:  Math.round(price * rng(0.55, 0.90, 8) * 100) / 100,
      sector: info.sector,
      exchange: info.exchange,
      timestamp: new Date().toISOString(),
      source: "mock",
    });
  }
});

/* ── Market Screener ── */
router.get("/stocks/screener", async (req, res): Promise<void> => {
  const filter = String(req.query.filter ?? "gainers");
  const limit  = Math.min(parseInt(String(req.query.limit ?? "25"), 10), 50);

  const allSymbols = Object.entries(NSE_STOCKS_FULL);
  const now        = Date.now();
  const dayKey     = Math.floor(now / 86400000); // changes daily

  function seeded(sym: string, off: number): number {
    const h = sym.split("").reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, dayKey + off);
    return (((h >>> 0) % 10000) / 10000);
  }

  const universe = allSymbols.map(([symbol, info]) => {
    const base         = BASE_PRICES_FALLBACK[symbol] ?? 1200;
    const r            = seeded(symbol, 1);
    const changePercent = (r * 10) - 4.5;               // -4.5% to +5.5%
    const price        = Math.round(base * (1 + changePercent / 100) * 100) / 100;
    const volume       = Math.floor(seeded(symbol, 2) * 15_000_000 + 100_000);
    const pe           = Math.round((seeded(symbol, 3) * 70 + 8) * 10) / 10;
    const marketCap    = Math.round(price * (seeded(symbol, 4) * 5e10 + 1e9));
    const revenueGrowth = (seeded(symbol, 5) * 80) - 15;  // -15% to +65%
    const high52w      = Math.round(price * (1 + seeded(symbol, 6) * 0.6) * 100) / 100;
    const low52w       = Math.round(price * (1 - seeded(symbol, 7) * 0.5) * 100) / 100;
    const nearHighPct  = ((price - low52w) / (high52w - low52w || 1)) * 100;
    const change       = Math.round(price * changePercent / 100 * 100) / 100;
    return { symbol, name: info.name, sector: info.sector, price, change, changePercent: Math.round(changePercent * 100) / 100, volume, pe, marketCap, revenueGrowth: Math.round(revenueGrowth * 10) / 10, high52w, low52w, nearHighPct: Math.round(nearHighPct) };
  });

  let sorted: typeof universe;
  switch (filter) {
    case "losers":       sorted = [...universe].sort((a, b) => a.changePercent - b.changePercent); break;
    case "volume":       sorted = [...universe].sort((a, b) => b.volume - a.volume); break;
    case "52week_high":  sorted = [...universe].sort((a, b) => b.nearHighPct - a.nearHighPct); break;
    case "pe_low":       sorted = [...universe].sort((a, b) => a.pe - b.pe); break;
    case "revenue":      sorted = [...universe].sort((a, b) => b.revenueGrowth - a.revenueGrowth); break;
    case "gainers":
    default:             sorted = [...universe].sort((a, b) => b.changePercent - a.changePercent); break;
  }

  res.json(sorted.slice(0, limit));
});

router.get("/stocks/:symbol/historical", async (req, res): Promise<void> => {
  const symbol    = String(req.params.symbol).toUpperCase();
  const timeframe = String(req.query.timeframe ?? "1Y");

  try {
    const candles = await fetchOHLCV(symbol, timeframe);
    if (candles.length > 0) {
      res.json(candles);
      return;
    }
    throw new Error("Empty candles from Yahoo Finance");
  } catch (err) {
    req.log?.warn({ err, symbol, timeframe }, "Yahoo Finance OHLCV failed, using mock");
    const daysMap: Record<string, number> = {
      "1D": 1, "1W": 7, "1M": 30, "3M": 90, "6M": 180, "1Y": 365, "5Y": 1825,
    };
    const days = daysMap[timeframe] ?? 365;
    const candles = generateOHLCV(symbol, days);
    res.json(candles);
  }
});

export default router;

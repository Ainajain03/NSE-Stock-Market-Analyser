import { Router, type IRouter } from "express";
import { NSE_STOCKS_FULL } from "../lib/nseStocks";
import { groqChat } from "../lib/groq";

const router: IRouter = Router();

function getSentimentData(symbol: string) {
  const seed = symbol.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const rng = (min: number, max: number, offset = 0) => {
    const val = (Math.sin(seed + offset + Date.now() / 86400000) * 0.5 + 0.5);
    return min + val * (max - min);
  };

  const newsSentiment = Math.round(rng(-0.3, 0.8, 1) * 100) / 100;
  const socialSentiment = Math.round(rng(-0.4, 0.9, 2) * 100) / 100;
  const fiiFlow = Math.round(rng(-2000, 3000, 3));
  const diiFlow = Math.round(rng(-1500, 2500, 4));
  const pcr = Math.round(rng(0.7, 1.4, 5) * 100) / 100;

  const info = NSE_STOCKS_FULL[symbol];
  const companyName = info?.name ?? symbol;

  const overallScore = Math.round(((newsSentiment + 1) / 2 * 40) + ((fiiFlow + 2000) / 5000 * 30) + ((socialSentiment + 1) / 2 * 30));

  let signal: "STRONGLY_BULLISH" | "BULLISH" | "NEUTRAL" | "BEARISH" | "STRONGLY_BEARISH";
  if (overallScore > 75) signal = "STRONGLY_BULLISH";
  else if (overallScore > 58) signal = "BULLISH";
  else if (overallScore < 25) signal = "STRONGLY_BEARISH";
  else if (overallScore < 40) signal = "BEARISH";
  else signal = "NEUTRAL";

  const newsItems = [
    { headline: `${companyName} reports strong Q4 results, beats analyst estimates`, source: "Economic Times", sentimentScore: 0.75 },
    { headline: `${info?.sector ?? "Sector"} stocks rise on positive macro data`, source: "Business Standard", sentimentScore: 0.45 },
    { headline: `FII inflows continue as India growth story strengthens`, source: "Mint", sentimentScore: 0.60 },
    { headline: `${companyName} announces strategic partnership to expand market share`, source: "Financial Express", sentimentScore: 0.65 },
    { headline: `Market breadth improves; mid-caps outperform benchmarks`, source: "CNBC TV18", sentimentScore: 0.35 },
    { headline: `RBI holds rates steady, signals accommodative stance`, source: "Reuters", sentimentScore: 0.40 },
  ].map((item, i) => ({
    ...item,
    timestamp: new Date(Date.now() - i * 3600000).toISOString(),
    url: null,
    sentimentScore: Math.round(item.sentimentScore * (0.8 + Math.random() * 0.4) * 100) / 100,
  }));

  return { symbol, overallScore, signal, newsSentimentScore: newsSentiment, socialSentimentScore: socialSentiment, fiiFlow, diiFlow, putCallRatio: pcr, recentNews: newsItems };
}

router.get("/sentiment/market", async (_req, res): Promise<void> => {
  const fearGreed = Math.round(45 + Math.sin(Date.now() / 86400000) * 20 + Math.random() * 10);
  let fearGreedLabel: string;
  if (fearGreed > 75) fearGreedLabel = "Extreme Greed";
  else if (fearGreed > 60) fearGreedLabel = "Greed";
  else if (fearGreed > 40) fearGreedLabel = "Neutral";
  else if (fearGreed > 25) fearGreedLabel = "Fear";
  else fearGreedLabel = "Extreme Fear";

  const sectors = [
    "Banking & Finance", "Information Technology", "FMCG",
    "Pharmaceuticals", "Automobile", "Infrastructure",
    "Energy & Petrochemicals", "Metals & Mining", "Telecom", "Consumer Goods",
  ];

  const sectorSentiments = sectors.map((sector) => {
    const score = Math.round(40 + Math.random() * 40);
    return {
      sector,
      score,
      signal: score > 60 ? "BULLISH" as const : score < 40 ? "BEARISH" as const : "NEUTRAL" as const,
    };
  });

  res.json({
    fearGreedIndex: fearGreed,
    fearGreedLabel,
    indiaVix: Math.round((12 + Math.random() * 8) * 100) / 100,
    putCallRatio: Math.round((0.8 + Math.random() * 0.6) * 100) / 100,
    fiiNetFlow: Math.round(-2000 + Math.random() * 5000),
    diiNetFlow: Math.round(-1000 + Math.random() * 4000),
    advanceDeclineRatio: Math.round((0.8 + Math.random() * 1.4) * 100) / 100,
    newHighs52W: Math.floor(50 + Math.random() * 150),
    newLows52W: Math.floor(10 + Math.random() * 80),
    sectorSentiments,
    timestamp: new Date().toISOString(),
  });
});

router.get("/sentiment/:symbol", async (req, res): Promise<void> => {
  const symbol = String(req.params.symbol).toUpperCase();
  if (!NSE_STOCKS_FULL[symbol]) {
    res.status(404).json({ error: "Stock not found" });
    return;
  }
  res.json(getSentimentData(symbol));
});

router.post("/sentiment/:symbol/ai-summary", async (req, res): Promise<void> => {
  const symbol = String(req.params.symbol).toUpperCase();
  const strategy = String(req.body?.strategy ?? "");
  const info = NSE_STOCKS_FULL[symbol];
  if (!info) {
    res.status(404).json({ error: "Stock not found" });
    return;
  }

  const data = getSentimentData(symbol);
  const prompt = `You are a market sentiment analyst for Indian equities (NSE).

Analyze sentiment for: ${info.name} (${symbol})

Sentiment Data:
- Overall Sentiment Score: ${data.overallScore}/100 — ${data.signal}
- News Sentiment: ${data.newsSentimentScore} (scale -1 to +1)
- Social Media Sentiment: ${data.socialSentimentScore}
- FII Net Flow Today: ₹${data.fiiFlow} Crores
- DII Net Flow Today: ₹${data.diiFlow} Crores
- Put/Call Ratio: ${data.putCallRatio}

${strategy ? `Active Strategy Lens: ${strategy}` : ""}

Recent Headlines:
${data.recentNews.slice(0, 3).map((n) => `- "${n.headline}" (Sentiment: ${n.sentimentScore})`).join("\n")}

${strategy ? `Interpret this sentiment data through the strategic lens of ${strategy}. What would this expert likely think about this sentiment environment?` : "Provide a clear sentiment assessment."}

End with: SENTIMENT SIGNAL: STRONGLY BULLISH / BULLISH / NEUTRAL / BEARISH / STRONGLY BEARISH
And a one-paragraph actionable interpretation.`;

  const text = await groqChat({
    system: "You are a market sentiment analyst specialising in Indian stock markets. Synthesise FII/DII flows, news, and technical sentiment into actionable signals.",
    messages: [{ role: "user", content: prompt }],
  });
  res.json({ summary: text, signal: data.signal, confidence: data.overallScore });
});

export default router;

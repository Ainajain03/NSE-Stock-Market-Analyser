import { Router, type IRouter } from "express";
import { EXPERT_PROFILES } from "../lib/mockData";
import { NSE_STOCKS_FULL, BASE_PRICES_FALLBACK } from "../lib/nseStocks";
import { fetchQuote } from "../lib/yahooFinance";
import { groqChat } from "../lib/groq";

function mockPrice(symbol: string): number {
  const base = BASE_PRICES_FALLBACK[symbol] ?? 1000;
  const noise = Math.sin(Date.now() / 10000 + symbol.charCodeAt(0)) * 0.02;
  return Math.round(base * (1 + noise) * 100) / 100;
}

const router: IRouter = Router();

router.get("/experts", async (_req, res): Promise<void> => {
  const profiles = EXPERT_PROFILES.map(({ systemPrompt: _sp, ...rest }) => rest);
  res.json(profiles);
});

router.get("/experts/:expertId", async (req, res): Promise<void> => {
  const expertId = String(req.params.expertId).toLowerCase();
  const expert = EXPERT_PROFILES.find((e) => e.id === expertId);
  if (!expert) {
    res.status(404).json({ error: "Expert not found" });
    return;
  }
  const { systemPrompt: _sp, ...profile } = expert;
  res.json(profile);
});

router.post("/experts/:expertId/chat", async (req, res): Promise<void> => {
  const expertId = String(req.params.expertId).toLowerCase();
  const expert = EXPERT_PROFILES.find((e) => e.id === expertId);
  if (!expert) {
    res.status(404).json({ error: "Expert not found" });
    return;
  }

  const { message, stockContext, conversationHistory = [] } = req.body as {
    message: string;
    stockContext?: {
      symbol: string;
      price: number;
      pe?: number | null;
      roe?: number | null;
      debtEquity?: number | null;
      rsi?: number | null;
      technicalSignal: string;
      fundamentalSignal: string;
      marketCap?: number | null;
      sector: string;
    };
    conversationHistory?: Array<{ role: string; content: string }>;
  };

  const stockSection = stockContext
    ? `\n\nCurrent Market Data Provided:\nStock: ${stockContext.symbol}\nCurrent Price: ₹${stockContext.price}\nP/E: ${stockContext.pe ?? "N/A"}\nROE: ${stockContext.roe ?? "N/A"}%\nDebt/Equity: ${stockContext.debtEquity ?? "N/A"}\nRSI: ${stockContext.rsi ?? "N/A"}\nTechnical Signal: ${stockContext.technicalSignal}\nFundamental Quality: ${stockContext.fundamentalSignal}\nSector: ${stockContext.sector}\nToday's Date: ${new Date().toDateString()}\n\nUse this data to inform your response. Stay completely in character.`
    : "";

  const systemPrompt = expert.systemPrompt + stockSection;

  const messages = conversationHistory
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }))
    .concat([{ role: "user" as const, content: message }]);

  try {
    const reply = await groqChat({ system: systemPrompt, messages });

    const actionKeywords = {
      BUY: /\b(buy|accumulate|invest|long)\b/i,
      SELL: /\b(sell|exit|short|avoid)\b/i,
      HOLD: /\b(hold|wait|patient)\b/i,
      AVOID: /\b(avoid|stay away|pass)\b/i,
    };
    let recommendedAction: "BUY" | "HOLD" | "SELL" | "AVOID" | null = null;
    for (const [action, regex] of Object.entries(actionKeywords)) {
      if (regex.test(reply)) { recommendedAction = action as "BUY" | "HOLD" | "SELL" | "AVOID"; break; }
    }

    res.json({ reply, expertId, recommendedAction });
  } catch (err: any) {
    req.log?.error({ err }, "Groq expert chat failed");
    res.status(500).json({ error: "AI chat failed", reply: "Sorry, I could not respond right now. Please try again." });
  }
});

router.get("/experts/:expertId/analyze/:symbol", async (req, res): Promise<void> => {
  const expertId = String(req.params.expertId).toLowerCase();
  const symbol = String(req.params.symbol).toUpperCase();
  const expert = EXPERT_PROFILES.find((e) => e.id === expertId);
  const info = NSE_STOCKS_FULL[symbol];

  if (!expert) { res.status(404).json({ error: "Expert not found" }); return; }
  if (!info) { res.status(404).json({ error: "Stock not found" }); return; }

  let price = mockPrice(symbol);
  try { const q = await fetchQuote(symbol); price = q.price; } catch { /* use mock */ }

  const prompt = `You have been asked to analyze ${info.name} (${symbol}) at ₹${price}.
Sector: ${info.sector}

Provide your analysis as ${expert.name}:
1. Your immediate impression
2. How this fits (or doesn't fit) your investment strategy
3. Specific factors you would investigate
4. Your overall verdict

End with: VERDICT: [BUY / HOLD / SELL / AVOID]`;

  try {
    const text = await groqChat({
      system: expert.systemPrompt,
      messages: [{ role: "user", content: prompt }],
    });

    const seed = (symbol + expertId).split("").reduce((a, c) => a + c.charCodeAt(0), 0);
    const score = Math.round(50 + Math.sin(seed) * 30);
    const rec = text.includes("BUY") ? "BUY" as const
      : text.includes("SELL") ? "SELL" as const
      : text.includes("AVOID") ? "AVOID" as const
      : "HOLD" as const;

    res.json({
      expertId,
      symbol,
      verdict: text.slice(0, 200),
      reasoning: text,
      score,
      keyFactors: expert.keyPrinciples.slice(0, 3),
      recommendation: rec,
    });
  } catch (err: any) {
    req.log?.error({ err }, "Groq expert analyze failed");
    res.status(500).json({ error: "Analysis failed" });
  }
});

export default router;

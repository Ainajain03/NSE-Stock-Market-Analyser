import { Router, type IRouter } from "express";
import { db, watchlistTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { BASE_PRICES_FALLBACK } from "../lib/nseStocks";
import { fetchQuote } from "../lib/yahooFinance";

const router: IRouter = Router();

function mockPrice(symbol: string): number {
  const base = BASE_PRICES_FALLBACK[symbol] ?? 1000;
  const noise = Math.sin(Date.now() / 10000 + symbol.charCodeAt(0)) * 0.02;
  return Math.round(base * (1 + noise) * 100) / 100;
}

router.get("/watchlist", async (req, res): Promise<void> => {
  const items = await db.select().from(watchlistTable).orderBy(watchlistTable.addedAt);
  const enriched = await Promise.all(items.map(async (item) => {
    try {
      const q = await fetchQuote(item.symbol);
      return {
        id: item.id,
        symbol: item.symbol,
        name: item.name,
        addedAt: item.addedAt.toISOString(),
        price: q.price,
        change: q.change,
        changePercent: q.changePercent,
      };
    } catch {
      const price = mockPrice(item.symbol);
      const changePercent = (Math.random() - 0.45) * 4;
      return {
        id: item.id,
        symbol: item.symbol,
        name: item.name,
        addedAt: item.addedAt.toISOString(),
        price,
        change: Math.round(price * changePercent / 100 * 100) / 100,
        changePercent: Math.round(changePercent * 100) / 100,
      };
    }
  }));
  res.json(enriched);
});

router.post("/watchlist", async (req, res): Promise<void> => {
  const { symbol, name } = req.body as { symbol: string; name: string };
  if (!symbol || !name) {
    res.status(400).json({ error: "symbol and name are required" });
    return;
  }
  const [item] = await db.insert(watchlistTable).values({ symbol: symbol.toUpperCase(), name }).returning();
  let price = mockPrice(item.symbol);
  try {
    const q = await fetchQuote(item.symbol);
    price = q.price;
  } catch { /* use mock */ }
  res.status(201).json({
    id: item.id,
    symbol: item.symbol,
    name: item.name,
    addedAt: item.addedAt.toISOString(),
    price,
    change: null,
    changePercent: null,
  });
});

router.delete("/watchlist/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await db.delete(watchlistTable).where(eq(watchlistTable.id, id));
  res.sendStatus(204);
});

export default router;

import { Router, type IRouter } from "express";
import { NSE_STOCKS_FULL } from "../lib/nseStocks";
import { groqChat } from "../lib/groq";

const router: IRouter = Router();

function buildFundamentals(symbol: string) {
  const info = NSE_STOCKS_FULL[symbol];
  if (!info) return null;

  const seed = symbol.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const rng = (min: number, max: number, offset = 0) => {
    const val = Math.sin(seed + offset) * 0.5 + 0.5;
    return Math.round((min + val * (max - min)) * 100) / 100;
  };

  const baseRevenue = rng(5000, 200000, 1);
  const growthRate = rng(0.08, 0.25, 2);

  const financials = [-4, -3, -2, -1, 0].map((offset, i) => {
    const yr = 2020 + i;
    const rev = Math.round(baseRevenue * Math.pow(1 + growthRate * 0.7, i));
    const gm = rng(0.25, 0.55, i);
    const gp = Math.round(rev * gm);
    const em = rng(0.15, 0.35, i + 5);
    const ebitda = Math.round(rev * em);
    const nm = rng(0.08, 0.22, i + 10);
    const pat = Math.round(rev * nm);
    const eps = Math.round(pat / rng(500, 5000, i + 15) * 100) / 100;
    const roe = rng(0.15, 0.35, i + 20);
    const roce = roe * rng(0.85, 1.1, i + 25);
    const de = rng(0.1, 0.8, i + 30);
    const assets = Math.round(rev * rng(1.2, 2.5, i + 35));
    const equity = Math.round(assets / (1 + de));
    const liabilities = assets - equity;
    return {
      year: `FY${yr}`,
      revenue: rev,
      revenueGrowth: i === 0 ? null : Math.round(growthRate * 100 + (Math.random() - 0.5) * 5),
      grossProfit: gp,
      grossMargin: Math.round(gm * 100),
      ebitda,
      ebitdaMargin: Math.round(em * 100),
      pat,
      netMargin: Math.round(nm * 100),
      eps,
      totalAssets: assets,
      totalLiabilities: liabilities,
      equity,
      debtEquity: Math.round(de * 100) / 100,
      currentRatio: rng(1.2, 2.5, i + 40),
      operatingCashFlow: Math.round(ebitda * rng(0.75, 0.95, i + 45)),
      freeCashFlow: Math.round(ebitda * rng(0.5, 0.75, i + 50)),
      capex: Math.round(rev * rng(0.04, 0.12, i + 55)),
      roe: Math.round(roe * 100),
      roce: Math.round(roce * 100),
    };
  });

  const latestFinancial = financials[financials.length - 1];
  const pe = rng(15, 55, 60);
  const pb = rng(2, 8, 65);

  const quarterlyResults = [
    "Q4FY24", "Q3FY24", "Q2FY24", "Q1FY24",
    "Q4FY23", "Q3FY23", "Q2FY23", "Q1FY23",
  ].map((q, i) => ({
    quarter: q,
    revenue: Math.round((latestFinancial.revenue ?? 0) / 4 * rng(0.88, 1.12, i + 70)),
    ebitda: Math.round((latestFinancial.ebitda ?? 0) / 4 * rng(0.85, 1.15, i + 75)),
    pat: Math.round((latestFinancial.pat ?? 0) / 4 * rng(0.82, 1.18, i + 80)),
    revenueGrowthYoY: Math.round(rng(-5, 25, i + 85) * 10) / 10,
    revenueGrowthQoQ: Math.round(rng(-8, 12, i + 90) * 10) / 10,
    patGrowthYoY: Math.round(rng(-10, 35, i + 95) * 10) / 10,
    beat: (["BEAT", "IN_LINE", "MISS", "BEAT", "BEAT", "IN_LINE", "BEAT", "MISS"] as const)[i],
  }));

  const intrinsicValue = Math.round(
    (latestFinancial.eps ?? 20) * rng(18, 35, 100) * 100
  ) / 100;
  const currentPrice = rng(200, 5000, 105);
  const marginOfSafety = Math.round(((intrinsicValue - currentPrice) / intrinsicValue) * 100);
  const grahamNumber = Math.round(
    Math.sqrt(22.5 * (latestFinancial.eps ?? 20) * (latestFinancial.equity ?? 100000) / rng(500, 5000, 110)) * 100
  ) / 100;

  const peers = ["PEER1", "PEER2", "PEER3", "PEER4", "PEER5"].map((_, i) => {
    const peerSymbols = Object.keys(NSE_STOCKS_FULL).filter((s) => NSE_STOCKS_FULL[s].sector === info.sector && s !== symbol).slice(0, 5);
    const peerSymbol = peerSymbols[i] ?? "TCS";
    const peerInfo = NSE_STOCKS_FULL[peerSymbol] ?? { name: "Peer Company" };
    return {
      symbol: peerSymbol,
      name: peerInfo.name,
      marketCap: Math.round(rng(10000, 500000, 120 + i) * 100000),
      revenue: Math.round(rng(5000, 200000, 125 + i)),
      pat: Math.round(rng(500, 30000, 130 + i)),
      pe: Math.round(rng(12, 60, 135 + i) * 10) / 10,
      pb: Math.round(rng(1, 10, 140 + i) * 10) / 10,
      roe: Math.round(rng(10, 40, 145 + i) * 10) / 10,
      debtEquity: Math.round(rng(0.1, 1.5, 150 + i) * 100) / 100,
      return1Y: Math.round(rng(-20, 60, 155 + i) * 10) / 10,
    };
  });

  const overallScore = Math.round(
    ((latestFinancial.roe ?? 15) * 1.5) + rng(20, 50, 160)
  );
  const capped = Math.min(95, Math.max(35, overallScore));

  const signal = capped > 75 ? "EXCELLENT" as const : capped > 60 ? "GOOD" as const : capped > 45 ? "AVERAGE" as const : "POOR" as const;

  const sectorDescriptions: Record<string, string> = {
    "Information Technology": `${info.name} is a leading Indian IT services company providing software development, consulting, and digital transformation services to clients worldwide. The company operates across multiple service lines including application development, cloud migration, data analytics, and enterprise solutions. With a strong offshore delivery model and diverse client base across US, Europe, and emerging markets, it benefits from India's cost-competitive technology talent pool.`,
    "Banking & Finance": `${info.name} is a prominent Indian banking and financial services institution offering retail banking, corporate banking, treasury operations, and insurance products. The bank maintains a diversified loan book with focus on retail and SME segments, supported by a robust CASA franchise. Strong risk management practices and digital banking capabilities position it well for India's credit growth cycle.`,
    "FMCG": `${info.name} is a dominant player in India's fast-moving consumer goods sector with a strong portfolio of household and personal care brands. The company benefits from deep rural distribution networks, brand equity built over decades, and pricing power in key categories. India's rising middle class and premiumization trend present significant growth opportunities.`,
    "Pharmaceuticals": `${info.name} is a leading Indian pharmaceutical company with a strong presence in generics, active pharmaceutical ingredients (APIs), and branded formulations. The company supplies to regulated markets in the US, Europe, and emerging markets while maintaining a robust domestic branded generics franchise.`,
    "Automobile": `${info.name} is a major player in India's automotive sector with a comprehensive product portfolio spanning passenger vehicles, commercial vehicles, or two-wheelers. The company is investing heavily in electric vehicle transition while maintaining strong market position in conventional segments.`,
  };

  const businessSummary = sectorDescriptions[info.sector] ?? `${info.name} is a leading Indian company in the ${info.sector} sector, providing products and services to customers across India and international markets. The company has established strong market positions through operational excellence, brand building, and strategic investments in growth areas.`;

  return {
    symbol,
    companyName: info.name,
    sector: info.sector,
    businessSummary,
    financials,
    quarterlyResults,
    valuation: {
      peRatio: Math.round(pe * 10) / 10,
      pbRatio: Math.round(pb * 10) / 10,
      evEbitda: Math.round(rng(8, 30, 165) * 10) / 10,
      peg: Math.round((pe / growthRate / 100) * 100) / 100,
      grahamNumber,
      dcfIntrinsicValue: intrinsicValue,
      marginOfSafety,
      sectorPE: Math.round(rng(18, 40, 170) * 10) / 10,
      dividendYield: Math.round(rng(0.5, 4, 175) * 100) / 100,
      promoterHolding: Math.round(rng(40, 75, 180) * 10) / 10,
      fiiHolding: Math.round(rng(8, 35, 185) * 10) / 10,
      diiHolding: Math.round(rng(5, 25, 190) * 10) / 10,
    },
    peers,
    cagr3Y: Math.round(growthRate * 100 * rng(0.8, 1.2, 195)),
    cagr5Y: Math.round(growthRate * 100 * rng(0.7, 1.1, 200)),
    overallScore: capped,
    fundamentalSignal: signal,
  };
}

router.get("/fundamental/:symbol", async (req, res): Promise<void> => {
  const symbol = String(req.params.symbol).toUpperCase();
  const data = buildFundamentals(symbol);
  if (!data) {
    res.status(404).json({ error: "Stock not found" });
    return;
  }
  res.json(data);
});

router.post("/fundamental/:symbol/ai-analysis", async (req, res): Promise<void> => {
  const symbol = String(req.params.symbol).toUpperCase();
  const strategy = String(req.body?.strategy ?? "");
  const data = buildFundamentals(symbol);
  if (!data) {
    res.status(404).json({ error: "Stock not found" });
    return;
  }

  const latest = data.financials[data.financials.length - 1];
  const prompt = `You are a fundamental analyst for Indian equities.

Company: ${data.companyName} (${symbol})
Sector: ${data.sector}
Fundamental Signal: ${data.fundamentalSignal} | Score: ${data.overallScore}/100

Financial Highlights (FY2024):
- Revenue: ₹${latest.revenue?.toLocaleString("en-IN")} Cr
- EBITDA Margin: ${latest.ebitdaMargin}%
- PAT: ₹${latest.pat?.toLocaleString("en-IN")} Cr | Net Margin: ${latest.netMargin}%
- ROE: ${latest.roe}% | ROCE: ${latest.roce}%
- Debt/Equity: ${latest.debtEquity}

Valuation:
- P/E: ${data.valuation.peRatio}x (Sector P/E: ${data.valuation.sectorPE}x)
- P/B: ${data.valuation.pbRatio}x
- Intrinsic Value (DCF): ₹${data.valuation.dcfIntrinsicValue}
- Margin of Safety: ${data.valuation.marginOfSafety}%
- Graham Number: ₹${data.valuation.grahamNumber}

${strategy ? `Active Investor Strategy: ${strategy}` : ""}

Provide a comprehensive fundamental analysis covering:
1. Business quality and competitive moat assessment
2. Financial health and capital allocation
3. Valuation assessment — is it cheap or expensive?
4. Key risks and red flags
5. Growth prospects and catalysts
6. ${strategy ? `Through the lens of ${strategy}'s strategy, is this a suitable investment?` : "Investment verdict"}

Rate overall fundamental quality: EXCELLENT / GOOD / AVERAGE / POOR / AVOID`;

  const text = await groqChat({
    system: "You are a senior fundamental analyst specialising in Indian equities listed on NSE/BSE. Provide rigorous, India-specific fundamental analysis.",
    messages: [{ role: "user", content: prompt }],
  });
  res.json({ summary: text, signal: data.fundamentalSignal, confidence: data.overallScore });
});

export default router;

import { Router, type IRouter } from "express";
import { groqChat } from "../lib/groq";

const router: IRouter = Router();

router.post("/chat/global", async (req, res): Promise<void> => {
  const { message, conversationHistory = [], activeStrategy, selectedStock } = req.body as {
    message: string;
    conversationHistory?: Array<{ role: string; content: string }>;
    activeStrategy?: string | null;
    selectedStock?: {
      symbol: string;
      price: number;
      technicalSignal: string;
      fundamentalSignal: string;
      sector: string;
    } | null;
  };

  const systemPrompt = `You are StockSage AI, an intelligent Indian stock market assistant. You help users navigate NSE-listed stocks with technical analysis, fundamental research, sentiment reading, and expert strategy comparison.

You can help with:
- Explaining any technical indicator and its current reading for a stock
- Summarizing fundamental health of a company
- Comparing two stocks head-to-head
- Explaining what a particular expert investor (Rakesh Jhunjhunwala, Warren Buffett, Benjamin Graham, Peter Lynch, George Soros, Jesse Livermore, Charlie Munger, Mark Minervini, Vijay Kedia, Radhakishan Damani) would think about a stock
- Explaining market concepts in simple language (Hindi-English mix is fine and encouraged)
- Helping users understand their risk tolerance and which expert strategy suits them
- Discussing NSE/BSE specific topics, SEBI regulations, Indian market structure

${activeStrategy ? `Current Active Strategy: ${activeStrategy} — apply this lens when relevant.` : ""}
${selectedStock ? `Current Selected Stock: ${selectedStock.symbol} at ₹${selectedStock.price} | Technical: ${selectedStock.technicalSignal} | Fundamental: ${selectedStock.fundamentalSignal} | Sector: ${selectedStock.sector}` : ""}

Be conversational, specific to Indian market context, and reference Indian market events, SEBI regulations, NSE/BSE specifics where relevant. Use Indian number system (lakhs, crores). Be decisive and analytical — users come here for actionable insights, not hedged generic advice.`;

  const messages = [
    ...conversationHistory.map((m) => ({ role: m.role as "user" | "assistant", content: m.content })),
    { role: "user" as const, content: message },
  ];

  try {
    const reply = await groqChat({ system: systemPrompt, messages });
    res.json({ reply });
  } catch (err: any) {
    req.log?.error({ err }, "Groq global chat failed");
    res.json({ reply: "Sorry, I ran into an error. Please try again." });
  }
});

export default router;

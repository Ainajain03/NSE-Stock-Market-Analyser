import Groq from "groq-sdk";

if (!process.env.GROQ_API_KEY) {
  throw new Error("GROQ_API_KEY environment variable is required");
}

export const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

export const GROQ_MODEL = "llama-3.3-70b-versatile";

export async function groqChat(params: {
  system: string;
  messages: Array<{ role: "user" | "assistant"; content: string }>;
  maxTokens?: number;
}): Promise<string> {
  const response = await groq.chat.completions.create({
    model: GROQ_MODEL,
    max_tokens: params.maxTokens ?? 8192,
    messages: [
      { role: "system", content: params.system },
      ...params.messages,
    ],
  });
  return response.choices[0]?.message?.content ?? "";
}

export const NSE_STOCKS: Record<string, { name: string; sector: string; exchange: string }> = {
  RELIANCE: { name: "Reliance Industries Ltd", sector: "Energy & Petrochemicals", exchange: "NSE" },
  TCS: { name: "Tata Consultancy Services", sector: "Information Technology", exchange: "NSE" },
  HDFCBANK: { name: "HDFC Bank Ltd", sector: "Banking & Finance", exchange: "NSE" },
  INFY: { name: "Infosys Ltd", sector: "Information Technology", exchange: "NSE" },
  ICICIBANK: { name: "ICICI Bank Ltd", sector: "Banking & Finance", exchange: "NSE" },
  HINDUNILVR: { name: "Hindustan Unilever Ltd", sector: "FMCG", exchange: "NSE" },
  ITC: { name: "ITC Ltd", sector: "FMCG", exchange: "NSE" },
  KOTAKBANK: { name: "Kotak Mahindra Bank", sector: "Banking & Finance", exchange: "NSE" },
  LT: { name: "Larsen & Toubro Ltd", sector: "Infrastructure", exchange: "NSE" },
  AXISBANK: { name: "Axis Bank Ltd", sector: "Banking & Finance", exchange: "NSE" },
  BAJFINANCE: { name: "Bajaj Finance Ltd", sector: "Banking & Finance", exchange: "NSE" },
  ASIANPAINT: { name: "Asian Paints Ltd", sector: "Consumer Goods", exchange: "NSE" },
  MARUTI: { name: "Maruti Suzuki India Ltd", sector: "Automobile", exchange: "NSE" },
  WIPRO: { name: "Wipro Ltd", sector: "Information Technology", exchange: "NSE" },
  TITAN: { name: "Titan Company Ltd", sector: "Consumer Goods", exchange: "NSE" },
  SUNPHARMA: { name: "Sun Pharmaceutical Industries", sector: "Pharmaceuticals", exchange: "NSE" },
  NESTLEIND: { name: "Nestle India Ltd", sector: "FMCG", exchange: "NSE" },
  TATAMOTORS: { name: "Tata Motors Ltd", sector: "Automobile", exchange: "NSE" },
  HCLTECH: { name: "HCL Technologies Ltd", sector: "Information Technology", exchange: "NSE" },
  POWERGRID: { name: "Power Grid Corporation", sector: "Power & Utilities", exchange: "NSE" },
  NTPC: { name: "NTPC Ltd", sector: "Power & Utilities", exchange: "NSE" },
  ONGC: { name: "Oil & Natural Gas Corporation", sector: "Energy & Petrochemicals", exchange: "NSE" },
  ULTRACEMCO: { name: "UltraTech Cement Ltd", sector: "Cement & Construction", exchange: "NSE" },
  ADANIENT: { name: "Adani Enterprises Ltd", sector: "Conglomerate", exchange: "NSE" },
  ADANIPORTS: { name: "Adani Ports & SEZ", sector: "Infrastructure", exchange: "NSE" },
  TATASTEEL: { name: "Tata Steel Ltd", sector: "Metals & Mining", exchange: "NSE" },
  JSWSTEEL: { name: "JSW Steel Ltd", sector: "Metals & Mining", exchange: "NSE" },
  COALINDIA: { name: "Coal India Ltd", sector: "Metals & Mining", exchange: "NSE" },
  BHARTIARTL: { name: "Bharti Airtel Ltd", sector: "Telecom", exchange: "NSE" },
  BAJAJFINSV: { name: "Bajaj Finserv Ltd", sector: "Banking & Finance", exchange: "NSE" },
  SBILIFE: { name: "SBI Life Insurance", sector: "Insurance", exchange: "NSE" },
  HDFCLIFE: { name: "HDFC Life Insurance", sector: "Insurance", exchange: "NSE" },
  DRREDDY: { name: "Dr. Reddy's Laboratories", sector: "Pharmaceuticals", exchange: "NSE" },
  DIVISLAB: { name: "Divi's Laboratories", sector: "Pharmaceuticals", exchange: "NSE" },
  CIPLA: { name: "Cipla Ltd", sector: "Pharmaceuticals", exchange: "NSE" },
  M_M: { name: "Mahindra & Mahindra", sector: "Automobile", exchange: "NSE" },
  TECHM: { name: "Tech Mahindra Ltd", sector: "Information Technology", exchange: "NSE" },
  INDUSINDBK: { name: "IndusInd Bank Ltd", sector: "Banking & Finance", exchange: "NSE" },
  SBIN: { name: "State Bank of India", sector: "Banking & Finance", exchange: "NSE" },
  GRASIM: { name: "Grasim Industries", sector: "Cement & Construction", exchange: "NSE" },
  TATACONSUM: { name: "Tata Consumer Products", sector: "FMCG", exchange: "NSE" },
  EICHERMOT: { name: "Eicher Motors Ltd", sector: "Automobile", exchange: "NSE" },
  HEROMOTOCO: { name: "Hero MotoCorp Ltd", sector: "Automobile", exchange: "NSE" },
  BPCL: { name: "Bharat Petroleum Corp", sector: "Energy & Petrochemicals", exchange: "NSE" },
  PIDILITIND: { name: "Pidilite Industries", sector: "Consumer Goods", exchange: "NSE" },
};

const BASE_PRICES: Record<string, number> = {
  RELIANCE: 2847, TCS: 3612, HDFCBANK: 1673, INFY: 1489, ICICIBANK: 1142,
  HINDUNILVR: 2234, ITC: 461, KOTAKBANK: 1789, LT: 3456, AXISBANK: 1134,
  BAJFINANCE: 6789, ASIANPAINT: 2789, MARUTI: 10234, WIPRO: 567, TITAN: 3456,
  SUNPHARMA: 1678, NESTLEIND: 2234, TATAMOTORS: 789, HCLTECH: 1567, POWERGRID: 312,
  NTPC: 389, ONGC: 278, ULTRACEMCO: 10234, ADANIENT: 2456, ADANIPORTS: 1234,
  TATASTEEL: 167, JSWSTEEL: 934, COALINDIA: 456, BHARTIARTL: 1678, BAJAJFINSV: 1678,
  SBILIFE: 1456, HDFCLIFE: 678, DRREDDY: 5678, DIVISLAB: 3456, CIPLA: 1234,
  M_M: 2567, TECHM: 1234, INDUSINDBK: 1456, SBIN: 789, GRASIM: 2345,
  TATACONSUM: 1023, EICHERMOT: 4567, HEROMOTOCO: 4678, BPCL: 312, PIDILITIND: 2678,
};

export function getStockPrice(symbol: string): number {
  const base = BASE_PRICES[symbol] ?? 1000;
  const noise = (Math.sin(Date.now() / 10000 + symbol.charCodeAt(0)) * 0.02);
  return Math.round(base * (1 + noise) * 100) / 100;
}

export function generateOHLCV(symbol: string, days: number): Array<{
  time: string; open: number; high: number; low: number; close: number; volume: number;
}> {
  const base = BASE_PRICES[symbol] ?? 1000;
  const candles = [];
  let price = base * 0.8;
  const now = new Date();

  for (let i = days; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    if (date.getDay() === 0 || date.getDay() === 6) continue;

    const trend = 0.0003;
    const volatility = 0.015;
    const change = (Math.random() - 0.47) * volatility + trend;
    const open = price;
    const close = price * (1 + change);
    const high = Math.max(open, close) * (1 + Math.random() * 0.008);
    const low = Math.min(open, close) * (1 - Math.random() * 0.008);
    const volume = Math.floor((Math.random() * 5000000 + 1000000));

    candles.push({
      time: date.toISOString().split("T")[0],
      open: Math.round(open * 100) / 100,
      high: Math.round(high * 100) / 100,
      low: Math.round(low * 100) / 100,
      close: Math.round(close * 100) / 100,
      volume,
    });
    price = close;
  }
  return candles;
}

export function sma(prices: number[], period: number): number | null {
  if (prices.length < period) return null;
  const slice = prices.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

export function ema(prices: number[], period: number): number | null {
  if (prices.length < period) return null;
  const k = 2 / (period + 1);
  let emaVal = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < prices.length; i++) {
    emaVal = prices[i] * k + emaVal * (1 - k);
  }
  return emaVal;
}

export function rsi(prices: number[], period = 14): number | null {
  if (prices.length < period + 1) return null;
  let gains = 0, losses = 0;
  for (let i = prices.length - period; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff > 0) gains += diff;
    else losses += Math.abs(diff);
  }
  const avgGain = gains / period;
  const avgLoss = losses / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return Math.round((100 - 100 / (1 + rs)) * 100) / 100;
}

export function macd(prices: number[]): { line: number; signal: number; histogram: number } | null {
  const ema12 = ema(prices, 12);
  const ema26 = ema(prices, 26);
  if (ema12 === null || ema26 === null) return null;
  const macdLine = ema12 - ema26;
  const signalLine = macdLine * 0.82;
  return {
    line: Math.round(macdLine * 100) / 100,
    signal: Math.round(signalLine * 100) / 100,
    histogram: Math.round((macdLine - signalLine) * 100) / 100,
  };
}

export function bollingerBands(prices: number[], period = 20, stdDev = 2): {
  upper: number; middle: number; lower: number;
} | null {
  if (prices.length < period) return null;
  const slice = prices.slice(-period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / period;
  const std = Math.sqrt(variance);
  return {
    upper: Math.round((mean + stdDev * std) * 100) / 100,
    middle: Math.round(mean * 100) / 100,
    lower: Math.round((mean - stdDev * std) * 100) / 100,
  };
}

export function atr(highs: number[], lows: number[], closes: number[], period = 14): number | null {
  if (highs.length < period + 1) return null;
  const trs = [];
  for (let i = 1; i < highs.length; i++) {
    const tr = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    );
    trs.push(tr);
  }
  const slice = trs.slice(-period);
  return Math.round((slice.reduce((a, b) => a + b, 0) / period) * 100) / 100;
}

export function getSignal(value: number | null, type: string): { signal: "BUY" | "SELL" | "NEUTRAL"; strength: "STRONG" | "MODERATE" | "WEAK"; reason: string; weight: number } {
  if (value === null) return { signal: "NEUTRAL", strength: "WEAK", reason: "Insufficient data", weight: 0.3 };

  switch (type) {
    case "rsi":
      if (value < 30) return { signal: "BUY", strength: "STRONG", reason: `RSI at ${value.toFixed(1)} — deeply oversold territory, potential reversal`, weight: 0.9 };
      if (value < 40) return { signal: "BUY", strength: "MODERATE", reason: `RSI at ${value.toFixed(1)} — approaching oversold, accumulation zone`, weight: 0.7 };
      if (value > 70) return { signal: "SELL", strength: "STRONG", reason: `RSI at ${value.toFixed(1)} — deeply overbought, potential reversal`, weight: 0.9 };
      if (value > 60) return { signal: "SELL", strength: "MODERATE", reason: `RSI at ${value.toFixed(1)} — overbought territory, caution advised`, weight: 0.7 };
      return { signal: "NEUTRAL", strength: "WEAK", reason: `RSI at ${value.toFixed(1)} — neutral zone, no directional bias`, weight: 0.4 };

    case "macd":
      if (value > 0) return { signal: "BUY", strength: value > 20 ? "STRONG" : "MODERATE", reason: `MACD histogram positive (${value.toFixed(2)}) — bullish momentum building`, weight: 0.8 };
      if (value < 0) return { signal: "SELL", strength: value < -20 ? "STRONG" : "MODERATE", reason: `MACD histogram negative (${value.toFixed(2)}) — bearish momentum`, weight: 0.8 };
      return { signal: "NEUTRAL", strength: "WEAK", reason: "MACD near zero — trend change possible", weight: 0.4 };

    case "adx":
      if (value > 40) return { signal: "BUY", strength: "STRONG", reason: `ADX at ${value.toFixed(1)} — very strong trend in play`, weight: 0.7 };
      if (value > 25) return { signal: "BUY", strength: "MODERATE", reason: `ADX at ${value.toFixed(1)} — trending market, follow the direction`, weight: 0.6 };
      return { signal: "NEUTRAL", strength: "WEAK", reason: `ADX at ${value.toFixed(1)} — weak trend, choppy conditions`, weight: 0.4 };

    case "williams":
      if (value < -80) return { signal: "BUY", strength: "STRONG", reason: `Williams %R at ${value.toFixed(1)} — extreme oversold`, weight: 0.8 };
      if (value > -20) return { signal: "SELL", strength: "STRONG", reason: `Williams %R at ${value.toFixed(1)} — extreme overbought`, weight: 0.8 };
      return { signal: "NEUTRAL", strength: "WEAK", reason: `Williams %R at ${value.toFixed(1)} — neutral`, weight: 0.4 };

    case "mfi":
      if (value < 20) return { signal: "BUY", strength: "STRONG", reason: `MFI at ${value.toFixed(1)} — money flowing out, oversold`, weight: 0.8 };
      if (value > 80) return { signal: "SELL", strength: "STRONG", reason: `MFI at ${value.toFixed(1)} — money flowing in, overbought`, weight: 0.8 };
      return { signal: "NEUTRAL", strength: "MODERATE", reason: `MFI at ${value.toFixed(1)} — normal money flow`, weight: 0.5 };

    default:
      return { signal: "NEUTRAL", strength: "WEAK", reason: `Value: ${value?.toFixed(2)}`, weight: 0.4 };
  }
}

export function aggregateSignals(signals: Array<{ signal: string; weight: number; strength: string }>): {
  signal: string; confidence: number;
} {
  let score = 0;
  let totalWeight = 0;

  for (const s of signals) {
    const direction = s.signal === "BUY" ? 1 : s.signal === "SELL" ? -1 : 0;
    const strengthMult = s.strength === "STRONG" ? 1 : s.strength === "MODERATE" ? 0.7 : 0.4;
    score += direction * s.weight * strengthMult;
    totalWeight += s.weight;
  }

  const normalized = totalWeight > 0 ? score / totalWeight : 0;
  const confidence = Math.round(Math.abs(normalized) * 100);

  let signal: string;
  if (normalized > 0.6) signal = "STRONG_BUY";
  else if (normalized > 0.3) signal = "BUY";
  else if (normalized > 0.1) signal = "WEAK_BUY";
  else if (normalized < -0.6) signal = "STRONG_SELL";
  else if (normalized < -0.3) signal = "SELL";
  else if (normalized < -0.1) signal = "WEAK_SELL";
  else signal = "NEUTRAL";

  return { signal, confidence: Math.max(45, Math.min(95, confidence + 45)) };
}

export const EXPERT_PROFILES = [
  {
    id: "jhunjhunwala",
    name: "Rakesh Jhunjhunwala",
    era: "1985–2022",
    strategyStyle: ["GARP", "Conviction", "Long-term"],
    philosophy: "Buy businesses, not stocks. Bet on India's unstoppable growth story with iron conviction.",
    famousWin: "Bought TITAN at ₹3, held through multiple cycles — one of history's greatest multibaggers",
    signatureColor: "#f97316",
    knownStocks: ["TITAN", "STAR HEALTH", "CRISIL", "ESCORTS", "LUPIN"],
    riskTolerance: "HIGH" as const,
    preferredSectors: ["Consumer", "Banking", "Pharma", "Infrastructure"],
    keyPrinciples: [
      "Buy businesses with strong ROE (>20%), low debt, and scalable models",
      "Be a bull on India — invest in India's structural growth story",
      "Take concentrated bets with high conviction (10–20% in single stocks)",
      "Hold for years to decades — short-term volatility is irrelevant",
      "Management quality and integrity is the primary filter",
      "Buy when others are fearful — that's where the real money is made",
    ],
    systemPrompt: `You are Rakesh Jhunjhunwala, India's most celebrated investor known as "The Big Bull." You passed away in August 2022, but your investment philosophy lives on. Speak as Rakesh Jhunjhunwala would — direct, confident, passionate about India's growth story, slightly blunt, deeply patriotic about India's economic potential. You believed in GARP investing and took concentrated bets with high conviction. You famously bought TITAN at ₹3. When analyzing stocks, first assess India's macro tailwinds, then management quality, then ROE and debt levels, then valuation. Speak in first person. Be enthusiastic, bold, and deeply Indian in perspective.`,
  },
  {
    id: "damani",
    name: "Radhakishan Damani",
    era: "1980s–Present",
    strategyStyle: ["Deep Value", "Contrarian", "Scuttlebutt"],
    philosophy: "Extreme patience, ground-level research, and waiting for the perfect pitch with a massive margin of safety.",
    famousWin: "Built DMart (Avenue Supermarts) from scratch — India's most efficient retail empire",
    signatureColor: "#8b5cf6",
    knownStocks: ["DMART", "VST INDUSTRIES", "INDIA CEMENTS", "UNITED BREWERIES"],
    riskTolerance: "MEDIUM" as const,
    preferredSectors: ["Consumer & Retail", "FMCG", "Beverages"],
    keyPrinciples: [
      "If you cannot explain the business in one sentence, skip it",
      "Research businesses from the ground up — walk store floors, talk to customers",
      "Wait for extreme margin of safety — sometimes years — before entering",
      "Love EDLC (Every Day Low Cost) models with high inventory turns",
      "Concentrate massively when conviction is absolute",
      "Be contrarian — if everyone loves a stock, be very skeptical",
    ],
    systemPrompt: `You are Radhakishan Damani, one of India's most successful and secretive investors, founder of DMart. You are known for your quiet intensity, extreme patience, and deep fundamental research. Your public appearances are rare. Speak thoughtfully, with methodical precision. You are not a showman — you let returns do the talking. You research businesses viscerally, walking store floors and speaking to customers and suppliers. When analyzing stocks, assess: can you understand it simply? What are the unit economics? Is management conservative? What is the absolute worst case? Is there an uncopiable competitive advantage? Speak in first person, thoughtfully, without bravado.`,
  },
  {
    id: "kedia",
    name: "Vijay Kedia",
    era: "1990s–Present",
    strategyStyle: ["SMILE", "Multibagger", "Micro-cap"],
    philosophy: "Hunt for Small companies with Large aspirations in Extra-large markets — the SMILE framework.",
    famousWin: "Found Atul Auto, Aegis Logistics, Cera Sanitaryware before they became 10x–50x returns",
    signatureColor: "#e11d48",
    knownStocks: ["ATUL AUTO", "AEGIS LOGISTICS", "CERA SANITARYWARE", "REPCO"],
    riskTolerance: "VERY_HIGH" as const,
    preferredSectors: ["Industrial", "Specialty Chemicals", "Infrastructure"],
    keyPrinciples: [
      "Small in size, Medium in experience, Large in aspiration, Extra-large in market potential",
      "Look for transformational businesses in early stages",
      "Very high risk tolerance — 10x returns require 10x courage",
      "Management must have skin in the game and burning ambition",
      "Find businesses disrupting a large market from a position of strength",
    ],
    systemPrompt: `You are Vijay Kedia, the multibagger hunter of Indian markets. You are known for your SMILE framework — Small in size, Medium in experience, Large in aspiration, Extra-large in market potential. You hunt for micro and small-cap stocks with transformational potential before others find them. You have very high risk tolerance. When analyzing stocks, look for: management ambition, large market opportunity, early-stage dominance, and potential for 10x growth. Speak with infectious enthusiasm about hidden gems and untapped potential. Speak in first person.`,
  },
  {
    id: "buffett",
    name: "Warren Buffett",
    era: "1950s–Present",
    strategyStyle: ["Quality", "Moat", "Forever"],
    philosophy: "Buy wonderful companies at fair prices and hold forever. The moat is everything.",
    famousWin: "Berkshire Hathaway — from a failing textile mill to a $900B conglomerate over 60 years",
    signatureColor: "#92400e",
    knownStocks: ["APPLE", "COCA-COLA", "AMERICAN EXPRESS", "BANK OF AMERICA"],
    riskTolerance: "MEDIUM" as const,
    preferredSectors: ["Consumer", "Banking", "Insurance", "Technology"],
    keyPrinciples: [
      "Buy wonderful companies at fair prices, not fair companies at wonderful prices",
      "The moat is everything — pricing power, brand, network effects, switching costs",
      "Management quality is paramount — only invest with honest, capable managers",
      "Be fearful when others are greedy, greedy when others are fearful",
      "Never invest in what you don't understand — stay within your circle of competence",
      "Hold forever — tax efficiency is a strategy; time is the friend of excellent businesses",
    ],
    systemPrompt: `You are Warren Buffett, the Oracle of Omaha, widely regarded as the greatest investor of all time. You speak with wisdom, humor, and clarity using simple language and powerful analogies. Apply your philosophy to Indian markets — identify which NSE-listed companies have Buffett-quality moats (like HDFC Bank, Asian Paints, Nestle India). When analyzing stocks, assess the economic moat first, then management quality, then valuation. You are patient, disciplined, and deeply rational. Reference your known philosophy and Berkshire's history. Speak in first person with warmth and wit.`,
  },
  {
    id: "graham",
    name: "Benjamin Graham",
    era: "1920s–1976",
    strategyStyle: ["Deep Value", "Quantitative", "Safety First"],
    philosophy: "A margin of safety is the central concept of investing. Never speculate — only analyze.",
    famousWin: "Developed the entire discipline of security analysis — mentored Warren Buffett",
    signatureColor: "#1d4ed8",
    knownStocks: ["NET-NET STOCKS", "LOW P/B COMPANIES", "DIVIDEND PAYERS"],
    riskTolerance: "LOW" as const,
    preferredSectors: ["Utilities", "Consumer Staples", "Industrial"],
    keyPrinciples: [
      "Buy only at a significant discount to intrinsic value — margin of safety is everything",
      "Defensive investor: large stable companies, dividend paying, low P/E, low P/B",
      "The Graham Number: √(22.5 × EPS × BVPS) — never pay more",
      "Mr. Market is your servant, not your guide — use his irrationality to your advantage",
      "Separate investment from speculation — if you can't demonstrate safety, it's speculation",
      "Diversify — the intelligent investor never concentrates dangerously",
    ],
    systemPrompt: `You are Benjamin Graham, the Father of Value Investing, author of Security Analysis and The Intelligent Investor. You are the intellectual architect of modern investment philosophy. You speak with academic precision and rigorous logic. You believe in quantitative analysis above all — the numbers must justify the investment. Apply your principles to NSE-listed Indian stocks: screen for stocks trading near or below their Graham Number, find net-net opportunities, focus on margin of safety. You are conservative, rigorous, and deeply skeptical of speculation. Speak in first person with scholarly authority.`,
  },
  {
    id: "lynch",
    name: "Peter Lynch",
    era: "1977–1990",
    strategyStyle: ["GARP", "Growth", "Invest What You Know"],
    philosophy: "Invest in what you know — superior local knowledge beats Wall Street research.",
    famousWin: "Turned Fidelity Magellan into the world's best-performing fund with 29% annual returns for 13 years",
    signatureColor: "#15803d",
    knownStocks: ["FAST FOOD", "RETAIL", "CONSUMER BRANDS"],
    riskTolerance: "MEDIUM" as const,
    preferredSectors: ["Consumer", "FMCG", "Retail"],
    keyPrinciples: [
      "Invest in what you know — use your consumer knowledge as an edge",
      "Categorize stocks: Slow growers, Stalwarts, Fast growers, Cyclicals, Turnarounds, Asset plays",
      "PEG ratio < 1 means the stock is undervalued relative to its growth",
      "Visit stores, observe consumer trends — boots-on-the-ground research",
      "Management should be buying their own stock — that's the real vote of confidence",
      "Find 10-baggers in ordinary industries — look for the mundane and unglamorous",
    ],
    systemPrompt: `You are Peter Lynch, the legendary manager of Fidelity Magellan Fund, who delivered 29% annual returns for 13 years. You believe in "invest in what you know" — the power of ordinary people's consumer knowledge as an investing edge. Apply your approach to Indian markets: FMCG underdogs, local brands going national, Indian consumer trends. Categorize stocks using your framework. Calculate PEG ratios. Look for 10-baggers in boring industries. Speak with enthusiasm, humor, and accessibility — you believe everyone can be a great investor. Speak in first person.`,
  },
  {
    id: "soros",
    name: "George Soros",
    era: "1970s–Present",
    strategyStyle: ["Global Macro", "Reflexivity", "Contrarian"],
    philosophy: "Markets shape reality and reality shapes markets — find the self-reinforcing loop before it breaks.",
    famousWin: "Broke the Bank of England in 1992 — made $1B in a single day shorting the British Pound",
    signatureColor: "#0891b2",
    knownStocks: ["CURRENCIES", "MACRO PLAYS", "SECTOR ROTATIONS"],
    riskTolerance: "VERY_HIGH" as const,
    preferredSectors: ["Macro", "Currency", "Financial"],
    keyPrinciples: [
      "Reflexivity: markets shape fundamentals and fundamentals shape markets — find the feedback loop",
      "Look for self-reinforcing trends that will overshoot and then violently correct",
      "Short the consensus when the consensus is fundamentally wrong",
      "Risk management first: survive first, profit second — position sizing is paramount",
      "India macro plays: FII flows, RBI policy, currency moves, sector rotations",
      "When you see it, bet big — but always with pre-defined risk limits",
    ],
    systemPrompt: `You are George Soros, the world's most famous macro trader, known for reflexivity theory and breaking the Bank of England. You think in macro terms — FII flows, RBI monetary policy, India VIX, global risk-on/risk-off. Apply your reflexivity framework to Indian markets: identify self-reinforcing trends, find where consensus is wrong, spot sector rotation plays. You are cerebral, philosophical, and think in feedback loops. Risk management is non-negotiable for you. Speak with intellectual authority and macro depth. Speak in first person.`,
  },
  {
    id: "livermore",
    name: "Jesse Livermore",
    era: "1900–1940",
    strategyStyle: ["Momentum", "Price Action", "Trend Following"],
    philosophy: "The market never lies. Strength begets strength. Only buy stocks making new highs.",
    famousWin: "Made $100M short-selling the 1929 crash — the greatest trade in stock market history",
    signatureColor: "#b45309",
    knownStocks: ["52-WEEK BREAKOUTS", "MOMENTUM LEADERS", "HIGH VOLUME SURGES"],
    riskTolerance: "VERY_HIGH" as const,
    preferredSectors: ["Any — momentum agnostic"],
    keyPrinciples: [
      "Only buy stocks making new 52-week highs — strength begets strength",
      "Cut losses ruthlessly at 10% — never average down into a losing position",
      "Pyramid into winners — add to positions only as they prove correct",
      "Time the market using price patterns — the tape tells you everything",
      "Never fight the tape — the market is always right, you are sometimes wrong",
      "Wait for the right moment — patience and timing are everything",
    ],
    systemPrompt: `You are Jesse Livermore, the legendary Boy Plunger of the early 20th century stock market, who made and lost multiple fortunes trading. You are the master of price action and momentum trading. You believe the tape never lies — only buy stocks showing strength, making new highs, and never average down losers. Apply your momentum principles to NSE stocks: 52-week breakouts, VCP patterns, high-volume surges. Speak with the intensity and drama of a man who has seen markets at their most extreme. Reference your famous trades. Speak in first person with gravitas.`,
  },
  {
    id: "munger",
    name: "Charlie Munger",
    era: "1960s–2023",
    strategyStyle: ["Mental Models", "Quality", "Invert"],
    philosophy: "Invert, always invert. Avoid stupidity before seeking brilliance. Sit on your ass investing.",
    famousWin: "Partner at Berkshire Hathaway for 50+ years — helped transform it from Graham-style to quality investing",
    signatureColor: "#78716c",
    knownStocks: ["BERKSHIRE HATHAWAY", "DAILY JOURNAL", "COSTCO"],
    riskTolerance: "LOW" as const,
    preferredSectors: ["Consumer", "Financial", "Industrial"],
    keyPrinciples: [
      "Invert, always invert — think about how to fail, then avoid that",
      "Use mental models from multiple disciplines to understand businesses",
      "Avoid: debt, leverage, complex accounting, promotional management",
      "Love: pricing power, high ROCE, simple businesses, honest management",
      "Sit on your ass investing — do nothing most of the time, act decisively when the pitch is perfect",
      "Identify businesses with Munger-quality moats in the Indian context",
    ],
    systemPrompt: `You are Charlie Munger, Warren Buffett's legendary partner at Berkshire Hathaway, known for your multi-disciplinary mental models, brutal intellectual honesty, and wit. You passed away in November 2023. Apply your latticework of mental models to Indian stocks. Invert every situation. Avoid stupidity before seeking brilliance. Look for businesses with high ROCE, pricing power, and simple honest management. Be direct, slightly cantankerous, and deeply wise. Reference psychology, economics, physics, and biology in your analysis. Speak in first person with your characteristic dry wit and intellectual rigor.`,
  },
  {
    id: "minervini",
    name: "Mark Minervini",
    era: "1980s–Present",
    strategyStyle: ["SEPA", "VCP", "Technical+Fundamental"],
    philosophy: "Specific Entry Point Analysis — the perfect technical setup on a fundamentally superior stock.",
    famousWin: "US Investing Championship winner — 155% return in one year using SEPA methodology",
    signatureColor: "#7c3aed",
    knownStocks: ["VCP BREAKOUTS", "SEPA STOCKS", "GROWTH LEADERS"],
    riskTolerance: "HIGH" as const,
    preferredSectors: ["Technology", "Biotech", "Consumer Growth"],
    keyPrinciples: [
      "Trend Template: stock must be above 150-day and 200-day MA, 200-day MA must be trending up",
      "VCP (Volatility Contraction Pattern): tight price action before explosive breakout",
      "Fundamental first: EPS growth >25%, sales growth >25%, high ROE, institutional support",
      "Only buy at specific pivot points with pre-defined, tight risk (typically 3–7%)",
      "Cut losses immediately at stop — never let a small loss become a large one",
      "Wait for the setup to come to you — discipline separates pros from amateurs",
    ],
    systemPrompt: `You are Mark Minervini, multiple US Investing Championship winner and creator of the SEPA (Specific Entry Point Analysis) methodology. You combine rigorous fundamental screening with precise technical entry points. When analyzing NSE stocks, apply your Trend Template (above 150-day and 200-day MA, MA trending up), look for VCP patterns, require EPS growth >25% and sales growth >25%, and only enter at specific pivot points with defined risk. You are precise, disciplined, and systematic. You have no patience for undisciplined trading. Speak in first person with professional precision.`,
  },
];

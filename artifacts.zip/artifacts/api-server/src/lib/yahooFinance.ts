const SYMBOL_OVERRIDES: Record<string, string> = {
  M_M: 'M&M',
  NIFTY50: '^NSEI',
  BANKNIFTY: '^NSEBANK',
  SENSEX: '^BSESN',
  NIFTYIT: '^CNXIT',
};

export function toYahooSymbol(nseSymbol: string): string {
  const upper = nseSymbol.toUpperCase();
  if (SYMBOL_OVERRIDES[upper]) return SYMBOL_OVERRIDES[upper];
  if (upper.startsWith('^')) return upper;
  return `${upper}.NS`;
}

const cache = new Map<string, { data: unknown; ts: number }>();
const CACHE_TTL = {
  quote: 60_000,
  daily: 300_000,
  intraday: 60_000,
  search: 120_000,
};

async function yahooFetch(url: string, ttl: number): Promise<unknown> {
  const cached = cache.get(url);
  if (cached && Date.now() - cached.ts < ttl) return cached.data;

  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36',
      Accept: 'application/json',
      'Accept-Language': 'en-US,en;q=0.9',
    },
    signal: AbortSignal.timeout(8000),
  });

  if (!res.ok) throw new Error(`Yahoo Finance HTTP ${res.status}`);
  const data = await res.json();
  cache.set(url, { data, ts: Date.now() });
  return data;
}

export interface YahooQuote {
  symbol: string;
  price: number;
  open: number;
  high: number;
  low: number;
  close: number;
  previousClose: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number | null;
  pe: number | null;
  high52w: number | null;
  low52w: number | null;
  name: string;
}

export interface YahooCandle {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface YahooSearchResult {
  symbol: string;
  name: string;
  sector: string;
  exchange: string;
}

export async function fetchQuote(nseSymbol: string): Promise<YahooQuote> {
  const ySym = toYahooSymbol(nseSymbol);
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ySym)}?interval=1d&range=5d`;
  const raw = await yahooFetch(url, CACHE_TTL.quote) as any;

  const result = raw?.chart?.result?.[0];
  if (!result) throw new Error('No result from Yahoo Finance');

  const meta = result.meta;
  const price = meta.regularMarketPrice ?? meta.previousClose;
  const prevClose = meta.chartPreviousClose ?? meta.previousClose ?? price;
  const change = price - prevClose;

  return {
    symbol: nseSymbol,
    name: meta.longName ?? meta.shortName ?? nseSymbol,
    price: Math.round(price * 100) / 100,
    open: Math.round((meta.regularMarketOpen ?? price) * 100) / 100,
    high: Math.round((meta.regularMarketDayHigh ?? price) * 100) / 100,
    low: Math.round((meta.regularMarketDayLow ?? price) * 100) / 100,
    close: Math.round(price * 100) / 100,
    previousClose: Math.round(prevClose * 100) / 100,
    change: Math.round(change * 100) / 100,
    changePercent: Math.round((change / prevClose) * 10000) / 100,
    volume: meta.regularMarketVolume ?? 0,
    marketCap: meta.marketCap ?? null,
    pe: meta.trailingPE ?? null,
    high52w: meta.fiftyTwoWeekHigh ?? null,
    low52w: meta.fiftyTwoWeekLow ?? null,
  };
}

export async function fetchOHLCV(nseSymbol: string, timeframe: string): Promise<YahooCandle[]> {
  const ySym = toYahooSymbol(nseSymbol);

  const rangeMap: Record<string, { interval: string; range: string; ttl: number }> = {
    '1D': { interval: '5m',  range: '1d',  ttl: CACHE_TTL.intraday },
    '1W': { interval: '15m', range: '5d',  ttl: CACHE_TTL.intraday },
    '1M': { interval: '1h',  range: '1mo', ttl: CACHE_TTL.daily },
    '3M': { interval: '1d',  range: '3mo', ttl: CACHE_TTL.daily },
    '6M': { interval: '1d',  range: '6mo', ttl: CACHE_TTL.daily },
    '1Y': { interval: '1d',  range: '1y',  ttl: CACHE_TTL.daily },
    '5Y': { interval: '1wk', range: '5y',  ttl: CACHE_TTL.daily },
  };

  const { interval, range, ttl } = rangeMap[timeframe] ?? rangeMap['1Y'];
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ySym)}?interval=${interval}&range=${range}`;
  const raw = await yahooFetch(url, ttl) as any;

  const result = raw?.chart?.result?.[0];
  if (!result) return [];

  const timestamps: number[] = result.timestamp ?? [];
  const quote = result.indicators?.quote?.[0] ?? {};
  const opens: number[]   = quote.open   ?? [];
  const highs: number[]   = quote.high   ?? [];
  const lows: number[]    = quote.low    ?? [];
  const closes: number[]  = quote.close  ?? [];
  const volumes: number[] = quote.volume ?? [];

  const candles: YahooCandle[] = [];
  for (let i = 0; i < timestamps.length; i++) {
    const o = opens[i], h = highs[i], l = lows[i], c = closes[i];
    if (o == null || h == null || l == null || c == null) continue;
    const date = new Date(timestamps[i] * 1000);
    const time = (interval.includes('m') || interval.includes('h'))
      ? date.toISOString()
      : date.toISOString().split('T')[0];
    candles.push({
      time,
      open:   Math.round(o * 100) / 100,
      high:   Math.round(h * 100) / 100,
      low:    Math.round(l * 100) / 100,
      close:  Math.round(c * 100) / 100,
      volume: volumes[i] ?? 0,
    });
  }
  return candles;
}

export async function fetchMarketIndex(indexSym: string): Promise<{ name: string; value: number; change: number; changePercent: number }> {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(indexSym)}?interval=1d&range=5d`;
  const raw = await yahooFetch(url, CACHE_TTL.quote) as any;
  const meta = raw?.chart?.result?.[0]?.meta;
  if (!meta) throw new Error('No index data');
  const price = meta.regularMarketPrice;
  const prev  = meta.chartPreviousClose ?? meta.previousClose ?? price;
  const change = price - prev;
  return {
    name: meta.shortName ?? indexSym,
    value: Math.round(price * 100) / 100,
    change: Math.round(change * 100) / 100,
    changePercent: Math.round((change / prev) * 10000) / 100,
  };
}

export async function searchNSEStocks(query: string): Promise<YahooSearchResult[]> {
  const url = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=25&newsCount=0&listsCount=0&enableFuzzyQuery=false&enableNavLinks=false`;
  try {
    const raw = await yahooFetch(url, CACHE_TTL.search) as any;
    const quotes: any[] = raw?.quotes ?? [];
    return quotes
      .filter((q: any) => q.symbol?.endsWith('.NS') && (q.quoteType === 'EQUITY' || q.typeDisp === 'Equity'))
      .map((q: any) => ({
        symbol: q.symbol.replace('.NS', '').replace(/&/g, '_AND_'),
        name: q.longname ?? q.shortname ?? q.symbol,
        sector: q.sector ?? 'NSE Listed',
        exchange: 'NSE',
      }));
  } catch {
    return [];
  }
}
